<?php
/******************************************************************
* Author : Atif Naseem
* Email : atif.naseem22@gmail.com
* Cell : +92-313-5521122
*******************************************************************/
?>

<?php

//if (session_id() == '')
//    session_start();
include(app_path().'/Metronic/lib/config.php');
?>