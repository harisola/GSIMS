<!--BEGIN PAGE LEVEL STYLES -->
<style>
 /***** BEGIN - Search Result Highlight CSS *****/
/*div#datepaginator1 {
  width: 100% !important;
  display: block !important;
  float: left;
}*/
.noShow .noUi-tooltip,
.noShow .noUi-handle {
display: none;
}
.yelow-color{
 background: #fff81e !important;
}
.red-bar{
    border:1px solid red !important;
    z-index: 0 !important;
    height: 26px !important;
    top: -10px !important;
 }
#tapSlider .green-color {
 background: #89c589 !important;
}
 .red-bar .noUi-tooltip {
  top: 34px !important;
  height: 19px !important;
 }
 .grey-color{
    background: none !important;
 }
 span.match{
 background-color:#f8dda9;
 border:1px solid #edd19b;
 margin:-1px;
 color:#390705;
 }
 .form-actions {
 text-align: center;
 padding: 25px 0 0 0;
 border-top: 1px solid #ccc;
 margin-top: 30px;
 }
 .portlet.light>.portlet-title {
 padding: 10px 20px 0;
 min-height: 48px;
 }
 .table > tbody > tr > td {
 vertical-align: middle;
 }
 .paddingLeft0 {
 padding-left:0 !important;  
 }
 /***** END - Search Result Highlight CSS *****/
 .mt-checkbox, .mt-radio {
 margin-bottom: 8px !important;
 }
 .theme-option .mt-checkbox {
 margin-right: 20px;
 }
 h4.bbottom {
 padding-bottom: 7px;
 border-bottom:1px solid #ccc;  
 }
 .dropdown-menuu {
 background: #fafafa;
 position: absolute;
 width: 270px;
 border: 1px solid #999;
 right: 0px;
 top: 33px;
 z-index: 999999;
 height: 220px;
 padding: 5px 16px;
 box-shadow: 1px 1px 4px #000;
 overflow-y: scroll;
 }
 .theme-panel>.theme-options4>.theme-option>select.form-control {
 width: 231px !important;
 }
 .theme-panel>.toggler4, .theme-panel>.toggler4-close {
 padding: 17px !important;
 -webkit-border-radius: 4px;
 -moz-border-radius: 4px;
 -ms-border-radius: 4px;
 -o-border-radius: 4px;
 top: 37px !important;
 cursor: pointer;
 }
 .theme-panel>.theme-options4 {
 top: 69px !important;
 }
 .commentType {
 right: 164px;
 position: absolute;
 }
 .inputs {
 position:relative;  
 }
 .pull-left.commentButton {
 position: absolute;
 right: 0px;
 width: 164px;
 }
 .border0 {
 border: 0 none; 
 }
 .rightpullAbsolutes {
 float: right;
 margin-top: -34px;  
 }
 .width100 {
 width:100%; 
 }
 .width78 {
 width: 93%;
 padding-right: 185px;   
 }
 .portlet-body .nav-tabs>li>a {
 padding: 10px 12px !important;
 }
 .dropdown-menu-right, .dropdown-menu.pull-right {
 left: auto;
 right: 0px;
 top: 24px;
 }
 .chat-form {
 margin-top: 15px;
 padding: 10px;
 background-color: #e9eff3;
 overflow: visible;
 clear: both;
 float: left;
 width: 100%;
 margin-bottom: 20px;
 }
 .md-radio {
 position: relative;
 margin: 11px 9px;
 }
 .md-radio label>span.inc {
 display:none;   
 }
 .theme-panel>.toggler4, .theme-panel>.toggler4-close {
 padding: 16px !important;
 -webkit-border-radius: 4px;
 -moz-border-radius: 4px;
 -ms-border-radius: 4px;
 -o-border-radius: 4px;
 top: 4px;
 cursor: pointer;
 }
 .theme-panel>.toggler4, .theme-panel>.toggler4-close {
 padding: 16px !important;
 -webkit-border-radius: 4px;
 -moz-border-radius: 4px;
 -ms-border-radius: 4px;
 -o-border-radius: 4px;
 top: 4px;
 cursor: pointer;
 }
 .theme-panel>.toggler4 {
 right: 0;
 position: absolute;
 background: url(./img/icon-color-filter.png) center no-repeat #536881 !important;
 border-radius: 4px;
 }
/*   ul.pagination {
 width:101%; 
 }*/
 .irs-disabled {
 opacity:1 !important;
 }
 .approvedBorder {
 border-left:3px solid green; 
 }
 .NoapprovedBorder {
 border-left:3px solid red;
 }
 .PendingapprovedBorder {
 border-left: 3px solid #BFCAD1;  
 }
 .bootstrap-switch-on > #approvedformShow {
 display: block !important;   
 }
 .headRightDetailsInner {
 background: #dedede;
 width: 100%;
 padding: 5px 15px;
 border-bottom: 1px solid #eef1f5;
 z-index: 999;
 margin-top: 0px;
 }
 .modal-body .portlet-body {
 padding-top:15px !important;
 }
 .irs-shadow {
 height: 12px !important;
 top: 25px !important;
 background: #27af64 !important;
 opacity: 1 !important;
 }
 .abridgedPersonalName,
 .abridgedPrimaryName {
 float: right;
 width: 57%;
 margin-top: -7px;
 }
 .noUi-handle .noUi-tooltip {
 left: -10px !important;
 }
/*   .noUi-connect.c-1-color {
 background: green;
 }
 .noUi-connect.c-3-color {
 background: green;
 }
 .noUi-connect.c-2-color {
 background: red;
 }*/

 .red-bar{
    border:1px solid red !important;
    z-index: 2 !important;
 }
 .grey-color{
    background: none !important;
 }
 .select2-container--bootstrap .select2-selection--multiple .select2-selection__choice {
    font-family: 'Conv_calibri';
 }

 #bufferTime .noUi-handle {
  border: 0 none;
  background: none;
}

 .red-color{
    background: red !important;
 }
.opardiv {
  background: #ff000003;
  width: 97%;
  height: 400px;
  position: absolute;
  z-index: 9;
}
</style>
<link href="{{ URL::to('/metronic/global/plugins/ion.rangeslider/css/ion.rangeSlider.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::to('/metronic/global/plugins/ion.rangeslider/css/ion.rangeSlider.skinFlat.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::to('/metronic/global/plugins/bootstrap-markdown/css/bootstrap-markdown.min.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::to('/metronic/global/plugins/bootstrap-summernote/summernote.css') }}" rel="stylesheet" type="text/css" />
<!-- -->
<link href="{{ URL::to('/css/staffLayout.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::to('/metronic/global/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::to('/metronic/global/plugins/bootstrap-datepaginator/bootstrap-datepaginator.min.css') }}" rel="stylesheet" type="text/css" />
<!-- -->
<link href="{{ URL::to('/metronic/global/plugins/time-range/css/flatpickr.min.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::to('/metronic/global/plugins/time-range/css/nouislider.min.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::to('/metronic/global/plugins/select2/css/select2.min.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::to('/metronic/global/plugins/select2/css/select2-bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
<!-- END PAGE LEVEL STYLES -->
<script>
 $("#change-color-switch").bootstrapSwitch();
 
 $(document).ready(function(){
     


       
 $('#change-color-switch').on('switchChange.bootstrapSwitch', function (e, data) {
   var state=$(this).bootstrapSwitch('state');//returns true or false
    if(state)
      {
         $("#approvedformShow").show();
      }
    else
      {
         $("#approvedformShow").hide();
         $('#approve_from').val('');
         $('#approve_to').val('');
         $('#paid_compensation_percentage').val('');
      }
  });
 });
 
 $("#changeSwitch").bootstrapSwitch();

 
 $(document).ready(function(){
     
       
 $('#changeSwitch').on('switchChange.bootstrapSwitch', function (e, data) {
   var state=$(this).bootstrapSwitch('state');//returns true or false
    if(state)
      {
         $("#paidField").show();
      }
    else
      {
         $("#paidField").hide();
      }
  });



 });
 
</script>
<!-- BEGIN PAGE BAR -->
<div class="page-bar">
 <ul class="page-breadcrumb">
    <li>
       <a href="index.html">Home</a>
       <i class="fa fa-circle"></i>
    </li>
    <li>
       <span>Staff List</span>
    </li>
 </ul>
 <!-- page-breadcrumb -->
</div>

<!-- BEGIN USE PROFILE -->
<div class="row marginTop20">
<div class="col-md-12 no-padding" style="width: 335px; text-align: center; position: absolute; top: 40%; left: 40%; background: rgb(241, 239, 239); border: 1px solid rgb(204, 204, 204); padding: 10px; z-index:99999;display:none" id="Generations_AjaxLoader">
                              <img src="http://10.10.10.50/gs//components/image/gsLoader.gif" width="200"><br><hr style="margin: 7px 0;border-top: 1px solid #ccc;"> Please Wait...
</div>





















<?php
/*************************************************
* Processor Part
**************************************************/
?>
<div class="col-md-12 fixed-height" id="staffView_StaffInfo">
	<div class="headRightDetails">
	   <table>
	      <tr id="staffView_ProcessorBar">
	         <td class="" style="padding-right:10px;">
	            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="12-057" src="assets/photos/hcm/150x150/staff/745.png" width="42">
	         </td>
	         <td class="staffView_StaffName">
	            <a href="javascript:;" class="primary-link tooltips" data-container="body" data-placement="top" data-original-title="745" data-staffid="295" data-staffgtid="12-057">Abdul Kalam</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="745">745</small><br>
	            <small class="shortHeight"><span class="tooltips" data-container="body" data-placement="top" data-original-title="Peon, South Campus, Operations &amp; Housekeeping">Operations &amp; Housekeeping: Peon, South Campus</span></small>
	         </td>
	      </tr>
	   </table>
	   <!-- col-md-4 -->
	</div>
	<div class="row">
	   <div class="col-md-3 col-xs-6 MobPaddingRight0">
	      <div class="profile-sidebar-portlet portlet light fixedHeight3">
	         <!-- SIDEBAR USERPIC -->
	         <div class="profile-userpic">
	            <img src="" class="img-responsive" alt=""> 
	         </div>
	         <!-- END SIDEBAR USERPIC -->
	         <!-- SIDEBAR USER TITLE -->
	         <div class="profile-usertitle">
	            <div class="profile-usertitle-name"></div>
	         </div>
	         <!-- END SIDEBAR USER TITLE -->
	      </div>
	      <!-- fixedHeight250 -->
	   </div>
	   <!-- col-md-3 -->
	   <div class="col-md-3 paddingRight0 col-xs-6">
	      <div class="portlet light fixedHeight3 paddingLeft10 paddingTop0">
	         <div class="margin-top-10 profile-desc-link ">
	            <i class="icon-credit-card tooltips" data-container="body" data-placement="bottom" data-original-title="GT ID"></i>
	            <span class="linkLookalike profile-usertitle-gtid"></span>
	         </div>
	         <!--  -->
	         <div class="margin-top-10 profile-desc-link ">
	            <i class="icon-envelope tooltips" data-container="body" data-placement="bottom" data-original-title="GU ID"></i>
	            <span class="linkLookalike profile-usertitle-email"></span>
	         </div>
	         <!--  -->
	         <div class="margin-top-10 profile-desc-link ">
	            <i class="fa fa-map-marker tooltips" data-container="body" data-placement="bottom" data-original-title="Campus"></i>
	            <span class="linkLookalike profile-usertitle-campus"> Campus</span>
	         </div>
	         <!--  -->
	         <div class="margin-top-10 profile-desc-link ">
	            <i class="fa fa-phone-square tooltips" data-container="body" data-placement="bottom" data-original-title="Mobile"></i>
	            <span class="profile-usertitle-mobilePhone linkLookalike"></span>
	         </div>
	         <!--  -->
	         <div class="margin-top-10 profile-desc-link ">
	            <i class="fa fa-file-text-o tooltips" data-container="body" data-placement="bottom" data-original-title="Leave status"></i>
	            <span class=" linkLookalike currentLeave">3 / 10</span>
	         </div>
	         <!--  -->
	      </div>
	      <!-- fixedHeight250 -->
	   </div>
	   <!-- col-md-3 -->
	   <div class="col-md-3 paddingRight0">
	      <div class="portlet light fixedHeight3 paddingRight0 paddingLeft10 paddingTop0">
	         <div class="margin-top-10 profile-desc-link pull-left width100">
	            <span class="pull-left width20"><img src="img/designationIcon.png" width="19px" class="tooltips" data-container="body" data-placement="bottom" data-original-title="Bottom Line: Top Line" /></span>
	            <span class="pull-left width80 linkLookalike profile-usertitle-bottomline"></span>
	            <span class="pull-left width20">&nbsp;</span>
	            <small  class="italicGray tooltips width80 pull-left" data-container="body" data-placement="bottom" data-original-title="Reporting to"><span class="profile-userrole-report-one"></span></small>
	         </div>
	         <div class="margin-top-10 profile-desc-link pull-left">
	            <i class="icon-user-following tooltips" data-container="body" data-placement="bottom" data-original-title="Timing Profile"></i>
	            <span class="linkLookalike profile-user-detail"></span>
	         </div>
	         <!--  -->
	         <div class="margin-top-10 profile-desc-link pull-left">
	            <span style="width:22px; text-align:center; float:left;" class="profile-user-attendance">
	            </span>
	            <span class="" style="float:left;margin-top:0px;margin-left:4px;font-size: 14px;font-weight: 600;color: #5b9bd1;">  
	            <span class=" tooltips" data-container="body" data-placement="top" data-original-title="10 day status">10</span> | <span class=" tooltips" data-container="body" data-placement="top" data-original-title="60 day status">60</span>
	            </span>
	         </div>
	      </div>
	      <!-- portlet light -->
	   </div>
	   <!-- col-md-3 -->
	   <div class="col-md-3 paddingRight0 ">
	      <div class="portlet light fixedHeight3 paddingLeft10 paddingRight0 paddingTop0">
	         <div class="margin-top-10 profile-desc-link pull-left width100">
	            <div class="flowidth100">
	               <span class="pull-left width20 profile-userrole-role-one-img" style="display:none"><img src="img/role.png" width="19px" class="tooltips" data-container="body" data-placement="bottom" data-original-title="Role 1" /></span>
	               <span class="pull-left width80 linkLookalike profile-userrole-role-one"></span><br />
	            </div>
	            <!-- flowidth100 -->
	            <div class="flowidth100">
	               <span class="pull-left width20">&nbsp;</span>
	               <small class="italicGray tooltips" data-container="body" data-placement="bottom" data-original-title="Reporting to"><span class="pull-left width80 profile-userrole-role-one-report"></span></small>
	            </div>
	            <!-- flowidth100 -->
	         </div>
	         <!--  profile-desc-link pull-left -->
	         <div class="margin-top-10 profile-desc-link pull-left width100">
	            <div class="flowidth100">
	               <span class="pull-left width20 profile-userrole-role-two-img" style="display:none"><img src="img/role.png" width="19px" class="tooltips" data-container="body" data-placement="bottom" data-original-title="Role 2" /></span>
	               <span class="pull-left width80 linkLookalike profile-userrole-role-two"></span><br />
	            </div>
	            <!-- flowidth100 -->
	            <div class="flowidth100">
	               <span class="pull-left width20">&nbsp;</span>
	               <small class="italicGray tooltips" data-container="body" data-placement="bottom" data-original-title="Reporting to"><span class="pull-left width80 profile-userrole-role-two-report"></span></small>
	            </div>
	            <!-- flowidth100 -->
	         </div>
	         <!--  profile-desc-link pull-left -->
	      </div>
	      <!-- portlet light -->
	   </div>
	   <!-- col-md-3 -->
	</div>
	<!-- row -->
	<div class="row">
	   <div class="col-md-12 paddingRight0">
	      <div class="portlet light bordered padding0 marginBottom0">
	         <div class="portlet-body padding20">
	            <ul class="nav nav-tabs fullWidthTabs" id="staffViewTabs">
	               <li class="active">
	                  <a href="#tab_1_5" data-toggle="tab"> Stories </a>
	               </li>
	               <li class="">
	                  <a href="#tab_1_1" data-toggle="tab"> TIF-B </a>
	               </li>
	               <li>
	                  <a href="#tab_1_2" data-toggle="tab"> TIF-A </a>
	               </li>
	               <li>
	                  <a href="#tab_1_3" data-toggle="tab"> Attendance </a>
	               </li>
	               <li>
	                  <a href="#tab_1_4" data-toggle="tab"> Process </a>
	               </li>
	               <li>
	                  <a href="#tab_1_6" data-toggle="tab" id="rolesRelation" class="rolesRelation"> Relationships </a>
	               </li>
	            </ul>
	            <div class="tab-content">
	               <div class="tab-pane fade" id="tab_1_1">
	                  <div class="tabbable-line">
	                     <ul class="nav nav-tabs ">
	                        <li class="active">
	                           <a href="#tab_basic" data-toggle="tab"> <span aria-hidden="true" class="icon-info"></span> Basics </a>
	                        </li>
	                        <li>
	                           <a href="#tab_education" data-toggle="tab"> <span aria-hidden="true" class="icon-graduation"></span> Education </a>
	                        </li>
	                        <li>
	                           <a href="#tab_employment" data-toggle="tab"> <span aria-hidden="true" class="icon-briefcase"></span> Employments </a>
	                        </li>
	                        <li class="">
	                           <a href="#tab_parent" data-toggle="tab"> <span aria-hidden="true" class="icon-users"></span> Parent / Spouse </a>
	                        </li>
	                        <li>
	                           <a href="#tab_children" data-toggle="tab"> <i class="fa fa-child"></i> Children </a>
	                        </li>
	                        <li>
	                           <a href="#tab_alternate" data-toggle="tab"> <i class="fa fa-phone"></i> Alternate Contacts </a>
	                        </li>
	                        <li>
	                           <a href="#tab_other" data-toggle="tab"> <span aria-hidden="true" class="icon-plus"></span> Other </a>
	                        </li>
	                     </ul>
	                     <!-- nav -->
	                     <div class="tab-content">
	                        <div class="tab-pane active" id="tab_basic">
	                           <div class="form-body">
	                              <h3 class="form-section marginTop0 headingBorderBottom">Person Info</h3>
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Full Name:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-fullName"> Afsar Ilyas </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">CNIC:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-nic"> 42501-4559651-3 </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Religion:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-religion"> Islam </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Nationality:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-nationality"> PAK </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Gender:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-gender"> Male: </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">DOB <small>(as per NIC)</small>:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-dob"> 23 Feb 1977 </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Marital Status:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-maritalStatus"> Single </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                              <h3 class="form-section headingBorderBottom">Contact Info</h3>
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Mobile: </label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-mobilePhone"> 0332-2536406 </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Landline:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-landLine"> 021-34615130 </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Email <small>(personal)</small>:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-personalEmail"> harisola@gmail.com </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                              <h3 class="form-section headingBorderBottom">Address Info</h3>
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Apartment No:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-apartmentNo"> - </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Street Name:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-streetName"> - </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Building Name:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-buildingName"> - </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Plot No:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-plotNo"> E-33/1 </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Region:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-region"> Nazimabad </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Sub Region:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-subRegion"> Block 7 </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                              <h3 class="form-section headingBorderBottom">Official Info</h3>
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Name Code:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-nameCode"> Single </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Employment Status:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tifb-basics-empStatus"> 0 </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5 text-right paddingRight0">Tap In Campus:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold tap_in_campus"></p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                           </div>
	                           <!-- form-body -->
	                        </div>
	                        <!-- tab_basic -->
	                        <div class="tab-pane" id="tab_education">
	                           <h4 class="form-section headingBorderBottom">Others</h4>
	                           <div class="row">
	                              <div class="col-md-6">
	                                 <div class="portlet light bordered lowPadding">
	                                    <div class="portlet-body">
	                                       <div class="col-md-3 padding0">
	                                          <img src="http://10.10.10.50/gsims/public/metronic/pages/img/schoolIcon.jpg" class="SchoolPlaceHolder" />
	                                       </div>
	                                       <!-- col-md-3 -->
	                                       <div class="col-md-9 paddingRight0">
	                                          <h5 class=" marginBottom0"><strong>Skill Development Council</strong></h5>
	                                          <h5 class="font-grey-cascade"><strong>Certification</strong>, HRM</h5>
	                                          <div class="col-md-6 padding0">
	                                             <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-graduation"></span>&nbsp;&nbsp;&nbsp;1st Division</h5>
	                                          </div>
	                                          <div class="col-md-6">
	                                             <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-calendar"></span>&nbsp;&nbsp;&nbsp;2010</h5>
	                                          </div>
	                                       </div>
	                                       <!-- col-md-9 -->
	                                    </div>
	                                    <!-- portlet-body -->
	                                 </div>
	                                 <!-- portlet -->
	                              </div>
	                              <!-- col-md-6 -->
	                              <div class="col-md-6">
	                                 <div class="portlet light bordered lowPadding">
	                                    <div class="portlet-body">
	                                       <div class="col-md-3 padding0">
	                                          <img src="http://10.10.10.50/gsims/public/metronic/pages/img/schoolIcon.jpg" class="SchoolPlaceHolder" />
	                                       </div>
	                                       <!-- col-md-3 -->
	                                       <div class="col-md-9 paddingRight0">
	                                          <h5 class=" marginBottom0"><strong>Skill Development Council</strong></h5>
	                                          <h5 class="font-grey-cascade"><strong>Certification</strong>, Essentials of Management</h5>
	                                          <div class="col-md-6 padding0">
	                                             <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-graduation"></span>&nbsp;&nbsp;&nbsp;1st Division</h5>
	                                          </div>
	                                          <div class="col-md-6">
	                                             <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-calendar"></span>&nbsp;&nbsp;&nbsp;2011</h5>
	                                          </div>
	                                       </div>
	                                       <!-- col-md-9 -->
	                                    </div>
	                                    <!-- portlet-body -->
	                                 </div>
	                                 <!-- portlet -->
	                              </div>
	                              <!-- col-md-6 -->
	                           </div>
	                           <!-- row -->
	                           <h4 class="form-section headingBorderBottom">Professional</h4>
	                           <h4 class="form-section headingBorderBottom">University</h4>
	                           <div class="row">
	                              <div class="col-md-6">
	                                 <div class="portlet light bordered lowPadding">
	                                    <div class="portlet-body">
	                                       <div class="col-md-3 padding0">
	                                          <img src="http://10.10.10.50/gsims/public/metronic/pages/img/uoklogo.png" class="SchoolPlaceHolder" />
	                                       </div>
	                                       <!-- col-md-3 -->
	                                       <div class="col-md-9 paddingRight0">
	                                          <h5 class=" marginBottom0"><strong>University of Karachi</strong></h5>
	                                          <h5 class="font-grey-cascade"><strong>M.P.A</strong>, Public Administration</h5>
	                                          <div class="col-md-6 padding0">
	                                             <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-graduation"></span>&nbsp;&nbsp;&nbsp;2nd Division</h5>
	                                          </div>
	                                          <div class="col-md-6">
	                                             <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-calendar"></span>&nbsp;&nbsp;&nbsp;2001</h5>
	                                          </div>
	                                       </div>
	                                       <!-- col-md-9 -->
	                                    </div>
	                                    <!-- portlet-body -->
	                                 </div>
	                                 <!-- portlet -->
	                              </div>
	                              <!-- col-md-6 -->
	                           </div>
	                           <!-- row -->
	                           <h4 class="form-section headingBorderBottom">College</h4>
	                           <div class="row">
	                              <div class="col-md-6">
	                                 <div class="portlet light bordered lowPadding">
	                                    <div class="portlet-body">
	                                       <div class="col-md-3 padding0">
	                                          <img src="http://10.10.10.50/gsims/public/metronic/pages/img/schoolIcon.jpg" class="SchoolPlaceHolder" />
	                                       </div>
	                                       <!-- col-md-3 -->
	                                       <div class="col-md-9 paddingRight0">
	                                          <h5 class=" marginBottom0"><strong>P.A.F (Faisal Base)</strong></h5>
	                                          <h5 class="font-grey-cascade"><strong>B.Sc</strong>, Computer Science, Economics & Maths</h5>
	                                          <div class="col-md-6 padding0">
	                                             <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-graduation"></span>&nbsp;&nbsp;&nbsp;2nd Division</h5>
	                                          </div>
	                                          <div class="col-md-6">
	                                             <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-calendar"></span>&nbsp;&nbsp;&nbsp;1997</h5>
	                                          </div>
	                                       </div>
	                                       <!-- col-md-9 -->
	                                    </div>
	                                    <!-- portlet-body -->
	                                 </div>
	                                 <!-- portlet -->
	                              </div>
	                              <!-- col-md-6 -->
	                           </div>
	                           <!-- row -->
	                           <h4 class="form-section headingBorderBottom">School</h4>
	                           <div class="row">
	                              <div class="col-md-6">
	                                 <div class="portlet light bordered lowPadding">
	                                    <div class="portlet-body">
	                                       <div class="col-md-3 padding0">
	                                          <img src="http://10.10.10.50/gsims/public/metronic/pages/img/schoolIcon.jpg" class="SchoolPlaceHolder" />
	                                       </div>
	                                       <!-- col-md-3 -->
	                                       <div class="col-md-9 paddingRight0">
	                                          <h5 class=" marginBottom0"><strong>National High School</strong></h5>
	                                          <h5 class="font-grey-cascade"><strong>Matric</strong>, Science</h5>
	                                          <div class="col-md-6 padding0">
	                                             <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-graduation"></span>&nbsp;&nbsp;&nbsp;1st Division</h5>
	                                          </div>
	                                          <div class="col-md-6">
	                                             <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-calendar"></span>&nbsp;&nbsp;&nbsp;1991</h5>
	                                          </div>
	                                       </div>
	                                       <!-- col-md-9 -->
	                                    </div>
	                                    <!-- portlet-body -->
	                                 </div>
	                                 <!-- portlet -->
	                              </div>
	                              <!-- col-md-6 -->
	                           </div>
	                           <!-- row -->
	                        </div>
	                        <!-- tab_education -->
	                        <div class="tab-pane" id="tab_employment">
	                           <div class="row">
	                              <div class="col-md-12">
	                                 <div class="portlet light lowPadding2 onlyBorderBottom marginBottom0">
	                                    <div class="portlet-body">
	                                       <div class="col-md-1 padding0">
	                                          <img src="http://10.10.10.50/gsims/public/metronic/pages/img/aflogo.jpg" class="SchoolPlaceHolder" />
	                                       </div>
	                                       <!-- col-md-3 -->
	                                       <div class="col-md-11 paddingRight0">
	                                          <h5 class=" marginBottom0 font-grey-mint marginTop0"><strong>IT Business Analyst</strong> at <strong>Assessment Fund</strong></h5>
	                                          <h5 class="font-grey-salsa marginBottom4">
	                                             <span class="positionDetail"><i class="fa fa-money tooltips" data-container="body" data-placement="top" data-original-title="Sallary"></i> <strong>10,000</strong></span>
	                                             <span class="positionDetail"><i class="fa fa-calendar tooltips" data-container="body" data-placement="top" data-original-title="Tenure"></i> <strong>2001</strong> to <strong>2005</strong></span>
	                                             <span class="positionDetail"><img src="http://10.10.10.50/gsims/public/metronic/pages/img/blackboard.png" width="20" class="tooltips" data-container="body" data-placement="top" data-original-title="Classes Taught" /> <strong>10,000</strong></span>
	                                             <span class="positionDetail"><i class="icon-book-open tooltips" data-container="body" data-placement="top" data-original-title="Subjects Taught"></i> <strong>Islamiat, Islamiat English, Urdu</strong></span>
	                                          </h5>
	                                          <p class="font-grey-salsa marginBottom0">Reason for Leaving: <span class="font-grey-mint">Lorem Ipsum dolor sit amet, Lorem Ipsum dolor sit amet Lorem Ipsum dolor</span> </p>
	                                       </div>
	                                       <!-- col-md-9 -->
	                                    </div>
	                                    <!-- portlet-body -->
	                                 </div>
	                                 <!-- portlet -->
	                              </div>
	                              <!-- col-md-6 -->
	                           </div>
	                           <!-- row -->
	                           <div class="row">
	                              <div class="col-md-12">
	                                 <div class="portlet light lowPadding2 onlyBorderBottom marginBottom0">
	                                    <div class="portlet-body">
	                                       <div class="col-md-1 padding0">
	                                          <img src="http://10.10.10.50/gsims/public/metronic/pages/img/BriefacaseIcon.jpg" class="SchoolPlaceHolder" />
	                                       </div>
	                                       <!-- col-md-3 -->
	                                       <div class="col-md-11 paddingRight0">
	                                          <h5 class=" marginBottom0 font-grey-mint marginTop0">Formerly worked at <strong>HireLabs</strong> on the position of <strong>UI/UX Lead</strong></h5>
	                                          <h5 class="font-grey-salsa marginBottom4">
	                                             <span class="positionDetail"><i class="fa fa-money tooltips" data-container="body" data-placement="top" data-original-title="Sallary"></i> <strong>10,000</strong></span>
	                                             <span class="positionDetail"><i class="fa fa-calendar tooltips" data-container="body" data-placement="top" data-original-title="Tenure"></i> <strong>2001</strong> to <strong>2005</strong></span>
	                                             <span class="positionDetail"><img src="http://10.10.10.50/gsims/public/metronic/pages/img/blackboard.png" width="20" class="tooltips" data-container="body" data-placement="top" data-original-title="Classes Taught" /> <strong>I, II, III </strong></span>
	                                             <span class="positionDetail"><i class="icon-book-open tooltips" data-container="body" data-placement="top" data-original-title="Subjects Taught"></i> <strong>Islamiat, Islamiat English, Urdu</strong></span>
	                                          </h5>
	                                          <p class="font-grey-salsa marginBottom0">Reason for Leaving: <span class="font-grey-mint">-</span> </p>
	                                       </div>
	                                       <!-- col-md-9 -->
	                                    </div>
	                                    <!-- portlet-body -->
	                                 </div>
	                                 <!-- portlet -->
	                              </div>
	                              <!-- col-md-6 -->
	                           </div>
	                           <!-- row -->
	                           <div class="row">
	                              <div class="col-md-12">
	                                 <div class="portlet light lowPadding2 marginBottom0">
	                                    <div class="portlet-body">
	                                       <div class="col-md-1 padding0">
	                                          <img src="http://10.10.10.50/gsims/public/metronic/pages/img/BriefacaseIcon.jpg" class="SchoolPlaceHolder" />
	                                       </div>
	                                       <!-- col-md-3 -->
	                                       <div class="col-md-11 paddingRight0">
	                                          <h5 class=" marginBottom0 font-grey-mint marginTop0">Web Developer at <strong>TechiBits</strong></h5>
	                                          <h5 class="font-grey-salsa marginBottom4">
	                                             <span class="positionDetail"><i class="fa fa-money tooltips" data-container="body" data-placement="top" data-original-title="Sallary"></i> <strong>10,000</strong></span>
	                                             <span class="positionDetail"><i class="fa fa-calendar tooltips" data-container="body" data-placement="top" data-original-title="Tenure"></i> <strong>2001</strong> to <strong>2005</strong></span>
	                                             <span class="positionDetail"><img src="http://10.10.10.50/gsims/public/metronic/pages/img/blackboard.png" width="20" class="tooltips" data-container="body" data-placement="top" data-original-title="Classes Taught" /> <strong>10,000</strong></span>
	                                             <span class="positionDetail"><i class="icon-book-open tooltips" data-container="body" data-placement="top" data-original-title="Subjects Taught"></i> <strong>Islamiat, Islamiat English, Urdu</strong></span>
	                                          </h5>
	                                          <p class="font-grey-salsa marginBottom0">Reason for Leaving: <span class="font-grey-mint">Personal Growth</span> </p>
	                                       </div>
	                                       <!-- col-md-9 -->
	                                    </div>
	                                    <!-- portlet-body -->
	                                 </div>
	                                 <!-- portlet -->
	                              </div>
	                              <!-- col-md-6 -->
	                           </div>
	                           <!-- row -->
	                        </div>
	                        <!-- tab_employment -->
	                        <div class="tab-pane " id="tab_parent">
	                           <table width="100%" border="0" class="table table-bordered">
	                              <thead class="bg-grey">
	                                 <tr>
	                                    <th class="text-center" width="40%">Father</th>
	                                    <th class="text-center" width="20%">&nbsp;</th>
	                                    <th class="text-center" width="40%">Spouse</th>
	                                 </tr>
	                              </thead>
	                              <tbody id="tab_parent_table">
	                                 <tr>
	                                    <td class="">Ilyas Ahmed Khan (Late)</td>
	                                    <td class="text-center"><strong>Name</strong></td>
	                                    <td class="">Sana Afsar</td>
	                                 </tr>
	                                 <tr>
	                                    <td>Bureaucrats</td>
	                                    <td class="text-center"><strong>Profession</strong></td>
	                                    <td>Housewife</td>
	                                 </tr>
	                                 <tr>
	                                    <td></td>
	                                    <td class="text-center"><strong>Qualification</strong></td>
	                                    <td>Bachelors</td>
	                                 </tr>
	                                 <tr>
	                                    <td></td>
	                                    <td class="text-center"><strong>Designation</strong></td>
	                                    <td></td>
	                                 </tr>
	                                 <tr>
	                                    <td></td>
	                                    <td class="text-center"><strong>Department</strong></td>
	                                    <td></td>
	                                 </tr>
	                                 <tr>
	                                    <td></td>
	                                    <td class="text-center"><strong>Organisation</strong></td>
	                                    <td></td>
	                                 </tr>
	                                 <tr>
	                                    <td></td>
	                                    <td class="text-center"><strong>CNIC</strong></td>
	                                    <td></td>
	                                 </tr>
	                                 <tr>
	                                    <td></td>
	                                    <td class="text-center"><strong>Mobile</strong></td>
	                                    <td>0300-2333365</td>
	                                 </tr>
	                                 <tr>
	                                    <td>&nbsp;</td>
	                                    <td class="text-center"><strong>Address</strong></td>
	                                    <td>&nbsp;</td>
	                                 </tr>
	                              </tbody>
	                           </table>
	                        </div>
	                        <!-- tab_parent -->
	                        <div class="tab-pane" id="tab_children">
	                           <div class="row">
	                              <div class="col-md-12">
	                                 <div class="portlet light portlet-fit">
	                                    <div class="portlet-body padding0">
	                                       <div class="mt-element-card mt-element-overlay">
	                                          <div class="row" id="tab_staff_child">
	                                             <div class="col-md-3">
	                                                <div class="mt-card-item">
	                                                   <div class="mt-card-avatar mt-overlay-4">
	                                                      <img src="http://10.10.10.50/gsims/public/assets/photos/sis/500x500/student/2416.jpg" />
	                                                      <div class="mt-overlay">
	                                                         <h2>11-C <span class="font-yellow-lemon">(Jinnah)</span></h2>
	                                                         <div class="mt-info font-white">
	                                                            <div class="mt-card-content">
	                                                               <p class="mt-card-desc font-white">GF-ID: <strong>16-249</strong> (1/3)</p>
	                                                               <div class="mt-card-social">
	                                                               </div>
	                                                            </div>
	                                                         </div>
	                                                      </div>
	                                                      <!-- mt-overlay -->
	                                                   </div>
	                                                   <!-- mt-card-avatar -->
	                                                   <div class="mt-card-content">
	                                                      <h3 class="mt-card-name">Suleman Atif</h3>
	                                                      <p class="mt-card-desc font-grey-mint">GS-ID: <strong>10-102</strong> (S-CFS)</p>
	                                                   </div>
	                                                   <!-- mt-card-content -->
	                                                </div>
	                                                <!-- mt-card-item -->
	                                             </div>
	                                             <!-- col-md-3 -->
	                                             <div class="col-md-3">
	                                                <div class="mt-card-item alumni">
	                                                   <div class="mt-card-avatar mt-overlay-4">
	                                                      <img src="http://10.10.10.50/gsims/public/assets/photos/sis/500x500/student/494.jpg" />
	                                                      <div class="mt-overlay">
	                                                         <h2>Alumni</h2>
	                                                         <div class="mt-info font-white">
	                                                            <div class="mt-card-content">
	                                                               <p class="mt-card-desc font-white">GF-ID: <strong>02-596</strong> (2/3)</p>
	                                                               <div class="mt-card-social">
	                                                               </div>
	                                                            </div>
	                                                         </div>
	                                                      </div>
	                                                      <!-- mt-overlay -->
	                                                   </div>
	                                                   <!-- mt-card-avatar -->
	                                                   <div class="mt-card-content">
	                                                      <h3 class="mt-card-name">Mushtaq Atif</h3>
	                                                      <p class="mt-card-desc font-grey-mint">GS-ID: <strong>10-102</strong> (A-GRD)</p>
	                                                   </div>
	                                                   <!-- mt-card-content -->
	                                                </div>
	                                                <!-- mt-card-item -->
	                                             </div>
	                                             <!-- col-md-3 -->
	                                             <div class="col-md-3">
	                                                <div class="mt-card-item">
	                                                   <div class="mt-card-avatar mt-overlay-4">
	                                                      <img src="http://10.10.10.50/gsims/public/assets/photos/sis/500x500/student/2416.jpg" />
	                                                      <div class="mt-overlay">
	                                                         <h2>11-C <span class="font-yellow-lemon">(Jinnah)</span></h2>
	                                                         <div class="mt-info font-white">
	                                                            <div class="mt-card-content">
	                                                               <p class="mt-card-desc font-white">GF-ID: <strong>16-249</strong> (1/3)</p>
	                                                               <div class="mt-card-social">
	                                                               </div>
	                                                            </div>
	                                                         </div>
	                                                      </div>
	                                                      <!-- mt-overlay -->
	                                                   </div>
	                                                   <!-- mt-card-avatar -->
	                                                   <div class="mt-card-content">
	                                                      <h3 class="mt-card-name">Suleman Atif</h3>
	                                                      <p class="mt-card-desc font-grey-mint">GS-ID: <strong>10-102</strong> (S-CFS)</p>
	                                                   </div>
	                                                   <!-- mt-card-content -->
	                                                </div>
	                                                <!-- mt-card-item -->
	                                             </div>
	                                             <!-- col-md-3 -->
	                                             <div class="col-md-3">
	                                                <div class="mt-card-item">
	                                                   <div class="mt-card-avatar mt-overlay-4">
	                                                      <img src="http://10.10.10.50/gsims/public/assets/photos/sis/500x500/student/494.jpg" />
	                                                      <div class="mt-overlay">
	                                                         <h2>Alumni</h2>
	                                                         <div class="mt-info font-white">
	                                                            <div class="mt-card-content">
	                                                               <p class="mt-card-desc font-white">GF-ID: <strong>02-596</strong> (2/3)</p>
	                                                               <div class="mt-card-social">
	                                                               </div>
	                                                            </div>
	                                                         </div>
	                                                      </div>
	                                                      <!-- mt-overlay -->
	                                                   </div>
	                                                   <!-- mt-card-avatar -->
	                                                   <div class="mt-card-content">
	                                                      <h3 class="mt-card-name">Mushtaq Atif</h3>
	                                                      <p class="mt-card-desc font-grey-mint">GS-ID: <strong>10-102</strong> (A-GRD)</p>
	                                                   </div>
	                                                   <!-- mt-card-content -->
	                                                </div>
	                                                <!-- mt-card-item -->
	                                             </div>
	                                             <!-- col-md-3 -->
	                                          </div>
	                                          <!-- row -->
	                                       </div>
	                                       <!-- mt-element-card -->
	                                    </div>
	                                    <!-- portlet-body -->
	                                 </div>
	                                 <!-- portlet -->
	                              </div>
	                              <!-- col-md-12 -->
	                           </div>
	                           <!-- row -->
	                        </div>
	                        <!-- tab_children -->
	                        <div class="tab-pane" id="tab_alternate">
	                           <table width="100%" border="0" class="table table-bordered">
	                              <thead class="bg-grey">
	                                 <tr>
	                                    <th class="text-center" width="40%">Next of Kin</th>
	                                    <th class="text-center" width="20%">&nbsp;</th>
	                                    <th class="text-center" width="40%">Emergency Contact</th>
	                                 </tr>
	                              </thead>
	                              <tbody id="tab_alternate_contact">
	                                 <tr>
	                                    <td>Mrs Farida Ilyas</td>
	                                    <td class="text-center"><strong>Name</strong></td>
	                                    <td>Dr Altaf Ahmed</td>
	                                 </tr>
	                                 <tr>
	                                    <td>E-33/1, Block-7, Gulshan-e-Iqbal, Karachi</td>
	                                    <td class="text-center"><strong>Address</strong></td>
	                                    <td>A- , Block-2, Gulshan-e-Iqbal, Karachi</td>
	                                 </tr>
	                                 <tr>
	                                    <td></td>
	                                    <td class="text-center"><strong>Email</strong></td>
	                                    <td></td>
	                                 </tr>
	                                 <tr>
	                                    <td>0300-8226220</td>
	                                    <td class="text-center"><strong>Mobile</strong></td>
	                                    <td>0300-8291947</td>
	                                 </tr>
	                                 <tr>
	                                    <td>Mother</td>
	                                    <td class="text-center"><strong>Relationship</strong></td>
	                                    <td>Brother-in-Law</td>
	                                 </tr>
	                              </tbody>
	                           </table>
	                        </div>
	                        <!-- tab_alternate -->
	                        <div class="tab-pane" id="tab_other">
	                           <div class="form-body">
	                              <h3 class="form-section marginTop0 headingBorderBottom">Other Details</h3>
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5">Provident Fund :</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold"> No </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5">NTN:</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold"> 42501-4559651-3 </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5">EOBI/SESSI number: </label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold"> 0100H477722 </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                              <h3 class="form-section headingBorderBottom">Bank Details</h3>
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5">Bank Name : </label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold"> Meezan Bank </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5">Branch :</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold"> Block-F, North Nazimabad </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5">Account Number :</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold"> 0001-3101-0026-0704 </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                              <h3 class="form-section headingBorderBottom">Takaful</h3>
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5">Self :</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold"> Yes </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5">Spouse :</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold"> Yes </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                              <div class="row">
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5">Children :</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold"> Yes </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                                 <div class="col-md-6">
	                                    <div class="form-group">
	                                       <label class="control-label col-md-5">Certificate :</label>
	                                       <div class="col-md-7">
	                                          <p class="form-control-static bold"> - </p>
	                                       </div>
	                                    </div>
	                                 </div>
	                                 <!--/span-->
	                              </div>
	                              <!--/row-->
	                           </div>
	                           <!-- form-body -->
	                        </div>
	                        <!-- tab_other -->
	                     </div>
	                     <!-- tab-content -->
	                  </div>
	                  <!-- tabbable-line -->
	               </div>
	               <!-- tab_1_1 -->
	               <div class="tab-pane fade" id="tab_1_2">
	                  <div class="summarySection col-md-12">
	                     <div class="col-md-6 paddingRight0">
	                        <div class="col-md-6 paddingLeft0">
	                           <div class="primaryReporting">
	                              <h4 class="PrimaryName"><span class="namePrimaryCode">KNN</span><span>Khadija Noorani</span></h4>
	                              <h5 class="PrimaryTopLine">Vice Principal</h5>
	                              <h5 class="PrimaryBottomLine">Starter & Junior Section</h5>
	                           </div>
	                           <!-- primaryReporting -->
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6 paddingRight0">
	                           <div class="reportingPersonal">
	                              <h4 class="PrimaryName"><span class="namePrimaryCode">SSD</span>Shoaib Siddiqui</h4>
	                              <h5 class="PrimaryTopLine">Coordinator, Academics</h5>
	                              <h5 class="PrimaryBottomLine">Starter Section</h5>
	                           </div>
	                           <!-- primaryReporting -->
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-6 -->
	                     <div class="col-md-6 paddingLeft0">
	                        <div class="col-md-6 paddingLeft0 paddingRight0">
	                           <h6 class="normalFont pull-right"><span class="leftLab3">Fundamental Reportees:</span> <strong>2</strong></h6>
	                           <h6 class="normalFont pull-right"><span class="leftLab3">Primary Reportees:</span> <strong>4</strong></h6>
	                           <h6 class="normalFont pull-right"><span class="leftLab3">Total Reportees:</span> <strong>5</strong></h6>
	                           <h6 class="normalFont pull-right"><span class="leftLab3">Total Members:</span> <strong>6</strong></h6>
	                        </div>
	                        <!-- -->
	                        <div class="col-md-6 paddingLeft0 paddingRight0">
	                           <h6 class="normalFont pull-right"><span class="leftLab3">Class Role:</span> <strong>06-070</strong></h6>
	                           <h6 class="normalFont pull-right"><span class="leftLab3"> Total Teaching Roles:</span> <strong>06-070</strong></h6>
	                           <h6 class="normalFont pull-right"><span class="leftLab3">Total Teaching Blocks:</span> <strong>06-070</strong></h6>
	                           <h6 class="normalFont pull-right"><span class="leftLab3">Total Teaching Students:</span> <strong>06-070</strong></h6>
	                           <h6 class="normalFont pull-right"><span class="leftLab3">Total Unique Students:</span> <strong>06-070</strong></h6>
	                           <h6 class="normalFont pull-right"><span class="leftLab3">Total Student Blocks:</span> <strong>06-070</strong></h6>
	                        </div>
	                        <!-- -->
	                     </div>
	                     <!-- col-md-6 -->
	                  </div>
	                  <!-- summarySection -->
	                  <hr style="margin-top: 5px;" />
	                  <div class="TimingSection col-md-12">
	                     <div class="col-md-3 paddingLeft0 text-center ">
	                        <h5>Timing Profile & Hours</h5>
	                        <table width="100%" border="0" class="TimingSectionTable">
	                           <tr>
	                              <td colspan="2">&nbsp;</td>
	                           </tr>
	                           <tr>
	                              <td colspan="2">Timing Profile</td>
	                           </tr>
	                           <tr>
	                              <td colspan="2">
	                                 <h4 style="margin:0;font-size:16px;">Heads</h4>
	                              </td>
	                           </tr>
	                           <tr>
	                              <td>&nbsp;</td>
	                              <td>&nbsp;</td>
	                           </tr>
	                           <tr>
	                              <td>&nbsp;</td>
	                              <td>&nbsp;</td>
	                           </tr>
	                           <tr>
	                              <td colspan="2">Average Weekly Hours</td>
	                           </tr>
	                           <tr>
	                              <td colspan="2">
	                                 <h4 style="margin:0;font-size:16px;">53:00</h4>
	                              </td>
	                           </tr>
	                           <tr>
	                              <td colspan="2">&nbsp;</td>
	                           </tr>
	                        </table>
	                     </div>
	                     <!-- col-md-3 -->
	                     <div class="col-md-3 paddingLeft0 text-center">
	                        <h5>Full Time Parameters</h5>
	                        <table width="100%" border="0" class="TimingSectionTable">
	                           <tr>
	                              <td colspan="2">&nbsp;</td>
	                           </tr>
	                           <tr>
	                              <td class="text-left">Standard IN</td>
	                              <td class="text-right"><strong>07:30</strong></td>
	                           </tr>
	                           <tr>
	                              <td class="text-left">Standard OUT</td>
	                              <td class="text-right"><strong>15:30</strong></td>
	                           </tr>
	                           <tr>
	                              <td>&nbsp;</td>
	                              <td>&nbsp;</td>
	                           </tr>
	                           <tr>
	                              <td>&nbsp;</td>
	                              <td>&nbsp;</td>
	                           </tr>
	                           <tr>
	                              <td class="text-left">Friday OUT</td>
	                              <td class="text-right"><strong>14:30</strong></td>
	                           </tr>
	                           <tr>
	                              <td class="text-left">Saturday Hrs</td>
	                              <td class="text-right"><strong>5.0</strong></td>
	                           </tr>
	                           <tr>
	                              <td colspan="2">&nbsp;</td>
	                           </tr>
	                        </table>
	                     </div>
	                     <!-- col-md-3 -->
	                     <div class="col-md-3 paddingLeft0 text-center">
	                        <h5>Secondary Parameters</h5>
	                        <table width="100%" border="0" class="TimingSectionTable">
	                           <tr>
	                              <td colspan="2">&nbsp;</td>
	                           </tr>
	                           <tr>
	                              <td class="text-left">Sat's Working</td>
	                              <td class="text-right"><strong>2</strong></td>
	                           </tr>
	                           <tr>
	                              <td class="text-left">Sat's Off</td>
	                              <td class="text-right"><strong>-</strong></td>
	                           </tr>
	                           <tr>
	                              <td>&nbsp;</td>
	                              <td>&nbsp;</td>
	                           </tr>
	                           <tr>
	                              <td class="text-left">Ext. Out</td>
	                              <td class="text-right"><strong>15:30</strong></td>
	                           </tr>
	                           <tr>
	                              <td class="text-left">Ext. FREQ</td>
	                              <td class="text-right"><strong>2</strong></td>
	                           </tr>
	                           <tr>
	                              <td class="text-left">July Category</td>
	                              <td class="text-right"><strong>W2</strong></td>
	                           </tr>
	                           <tr>
	                              <td colspan="2">&nbsp;</td>
	                           </tr>
	                        </table>
	                     </div>
	                     <!-- col-md-3 -->
	                     <div class="col-md-3 paddingLeft0 text-center">
	                        <h5>Custom Timings</h5>
	                        <table width="100%" border="0" class="TimingSectionTable">
	                           <tr>
	                              <td colspan="3">&nbsp;</td>
	                           </tr>
	                           <tr>
	                              <td>Mon</td>
	                              <td><strong>07:00</strong></td>
	                              <td><strong>14:00</strong></td>
	                           </tr>
	                           <tr>
	                              <td>Tue</td>
	                              <td><strong>07:00</strong></td>
	                              <td><strong>14:00</strong></td>
	                           </tr>
	                           <tr>
	                              <td>Wed</td>
	                              <td><strong>07:00</strong></td>
	                              <td><strong>14:00</strong></td>
	                           </tr>
	                           <tr>
	                              <td>Thu</td>
	                              <td><strong>07:00</strong></td>
	                              <td><strong>14:00</strong></td>
	                           </tr>
	                           <tr>
	                              <td>Fri</td>
	                              <td><strong>07:00</strong></td>
	                              <td><strong>14:00</strong></td>
	                           </tr>
	                           <tr>
	                              <td>Sat</td>
	                              <td><strong>07:00</strong></td>
	                              <td><strong>14:00</strong></td>
	                           </tr>
	                           <tr>
	                              <td>&nbsp;</td>
	                              <td>&nbsp;</td>
	                              <td>&nbsp;</td>
	                           </tr>
	                        </table>
	                     </div>
	                     <!-- col-md-3 -->
	                  </div>
	                  <!-- TimingSection -->
	                  <hr style="margin-top: 5px;" />
	                  <div class="MatrixRolesSection">
	                     <h4 class="col-md-6 col-md-offset-3 text-center MatrixRoles">Matrix Role(s) <small>for Classes and Groups</small></h4>
	                     <div class="col-md-12 paddingBottom40">
	                        <div class="col-md-6 col-md-offset-3 paddingLeft0 paddingRight0">
	                           <table width="100%" border="0" class="FunDaMentalReporting">
	                              <tr>
	                                 <td class="text-center FunRep">FR</td>
	                                 <td class="text-center ClassTeach">CLT</td>
	                                 <td class="text-center ClassHere">IV-G</td>
	                                 <td class="text-center ClassSectionHere">IV-CLT-0-G</td>
	                                 <td class="text-center StuStrength">28</td>
	                                 <td class="text-center TopBottomLine">YT, Grade IV<br />Sadia Ashar</td>
	                                 <td class="text-center ReportingCodeName">SAS</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap" style="border:1px solid #000;">
	                              <tr>
	                                 <td class="text-center SRNO">2</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                                 <td class="text-center FunRep">FR</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">14</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">3</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                                 <td class="text-center FunRep White"></td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">15</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">4</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                                 <td class="text-center FunRep White"></td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">16</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">5</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                                 <td class="text-center FunRep White"></td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">17</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">6</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                                 <td class="text-center FunRep White"></td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">18</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">7</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                                 <td class="text-center FunRep White"></td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">19</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">8</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                                 <td class="text-center FunRep White"></td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">20</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">9</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                                 <td class="text-center FunRep White"></td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">21</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">10</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                                 <td class="text-center FunRep White"></td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">22</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">11</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                                 <td class="text-center FunRep White"></td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">23</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">12</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                                 <td class="text-center FunRep White"></td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">24</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">13</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                                 <td class="text-center FunRep White"></td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="0" class="FunDaMentalReportingChap">
	                              <tr>
	                                 <td class="text-center SRNO">25</td>
	                                 <td class="text-center SubjectName">X-PHYS-A-1</td>
	                                 <td class="text-center StuStrength">29</td>
	                                 <td class="text-center Blocks">3</td>
	                                 <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
	                                 <td class="text-center NameCodeHere">RHI</td>
	                                 <td class="text-center RankHere">7</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                  </div>
	                  <!-- MatrixRolesSection -->
	                  <hr style="margin-top: 5px;" />
	                  <div class="orgChartSection">
	                     <h4 class="col-md-6 col-md-offset-3 text-center MatrixRoles">Org Chart Roles(s) <small>for Non-Classroom Roles</small> | Role 1</h4>
	                     <?php /* ?><?php */ ?>
	                     <div class="no-padding col-md-10 col-md-offset-1">
	                        <div class="blackSolidBorder">&nbsp;</div>
	                        <div class="graySolidBorder">&nbsp;</div>
	                        <div class="grayDashedBorder">&nbsp;</div>
	                        <div class="col-md-12 ">
	                           <div class="col-md-6 text-center">
	                              <table width="100%" border="1" class="secondLevelReporting">
	                                 <tr>
	                                    <td colspan="3">
	                                       <h5>PRIMARY GRANDREPORTOO</h5>
	                                    </td>
	                                 </tr>
	                                 <tr>
	                                    <td width="30%" height="40">JN-T001</td>
	                                    <td width="30%">OPQ</td>
	                                    <td width="30%">2</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30">Vice Principal, Junior Section</td>
	                                 </tr>
	                                 <tr>
	                                    <td height="40">GT 10-567</td>
	                                    <td colspan="2">KHN</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30">Khadija Noorani</td>
	                                 </tr>
	                              </table>
	                           </div>
	                           <!-- col-md-6 -->
	                           <div class="col-md-6 text-center">
	                              <table width="100%" border="1" class="secondLevelReporting">
	                                 <tr>
	                                    <td colspan="3">
	                                       <h5>SECONDARY GRANDREPORTOO</h5>
	                                    </td>
	                                 </tr>
	                                 <tr>
	                                    <td width="30%" height="40">JN-T001</td>
	                                    <td width="30%">OPQ</td>
	                                    <td width="30%">2</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30">Vice Principal, Junior Section</td>
	                                 </tr>
	                                 <tr>
	                                    <td height="40">GT 10-567</td>
	                                    <td colspan="2">KHN</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30">Khadija Noorani</td>
	                                 </tr>
	                              </table>
	                           </div>
	                           <!-- col-md-6 -->
	                        </div>
	                        <!-- col-md-12 -->
	                        <div class="col-md-12 paddingTop50">
	                           <div class="col-md-6 text-center">
	                              <table width="100%" border="1" class="firstLevelReporting">
	                                 <tr>
	                                    <td colspan="3">
	                                       <h5>PRIMARY REPORTOO</h5>
	                                    </td>
	                                 </tr>
	                                 <tr>
	                                    <td width="30%" height="40" bgcolor="#e5d998">JN-T001</td>
	                                    <td width="30%" bgcolor="#ffff00">OPQ</td>
	                                    <td width="30%" bgcolor="#ffff00">2</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30" bgcolor="#e5d998">Vice Principal, Junior Section</td>
	                                 </tr>
	                                 <tr>
	                                    <td height="40" bgcolor="#f4ecfd">GT 10-567</td>
	                                    <td colspan="2" bgcolor="#f4ecfd">KHN</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30" bgcolor="#f4ecfd">Khadija Noorani</td>
	                                 </tr>
	                              </table>
	                           </div>
	                           <!-- col-md-6 -->
	                           <div class="col-md-6 text-center">
	                              <table width="100%" border="1" class="firstLevelReporting">
	                                 <tr>
	                                    <td colspan="3">
	                                       <h5>SECONDARY REPORTOO</h5>
	                                    </td>
	                                 </tr>
	                                 <tr>
	                                    <td width="30%" height="40">JN-T001</td>
	                                    <td width="30%">OPQ</td>
	                                    <td width="30%">2</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30">Vice Principal, Junior Section</td>
	                                 </tr>
	                                 <tr>
	                                    <td height="40">GT 10-567</td>
	                                    <td colspan="2">KHN</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30">Khadija Noorani</td>
	                                 </tr>
	                              </table>
	                           </div>
	                           <!-- col-md-6 -->
	                        </div>
	                        <!-- col-md-12 -->
	                        <div class="col-md-12 paddingTop50">
	                           <div class="col-md-6 col-md-offset-3 text-center" style="background:#e2e2e2;padding:15px;">
	                              <table width="100%" border="1" bgcolor="#fff" class="firstLevelReporting" style="background:#fff;" >
	                                 <tr>
	                                    <td bgcolor="#ade4f2">
	                                       <h5 style="color:#;">FR</h5>
	                                    </td>
	                                    <td colspan="2" bgcolor="#ade4f2">
	                                       <h5>ROLE A</h5>
	                                    </td>
	                                 </tr>
	                                 <tr>
	                                    <td width="30%" height="40" bgcolor="#e5d998">JN-B-01</td>
	                                    <td width="30%" bgcolor="#ffff00">OPQ</td>
	                                    <td width="30%" bgcolor="#ffff00">4</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30" bgcolor="#e5d998">Headmistress, Junior Section</td>
	                                 </tr>
	                                 <tr>
	                                    <td height="40" bgcolor="#ade4f2">ZHA-A</td>
	                                    <td colspan="2" bgcolor="#f4ecfd">Zillehuma Asif</td>
	                                 </tr>
	                              </table>
	                           </div>
	                           <!-- col-md-6 -->
	                        </div>
	                        <!-- col-md-12 -->
	                        <div class="col-md-12 paddingTop50">
	                           <div class="col-md-6 col-md-offset-3 text-center" style="background:none;padding:15px;">
	                              <table width="100%" border="1">
	                                 <tr>
	                                    <td colspan="2" width="33%" height="90">
	                                       Fundamental<br />Primary<br />
	                                       <h5>06</h5>
	                                    </td>
	                                    <td colspan="2" width="33%" height="90">
	                                       Total<br />Primary<br />
	                                       <h5>06</h5>
	                                    </td>
	                                    <td colspan="2" width="33%" height="90">
	                                       Total<br />Reportee<br />
	                                       <h5>06</h5>
	                                    </td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" width="50%"  height="80">
	                                       Total Staff<br />Members<br />
	                                       <h5>200</h5>
	                                    </td>
	                                    <td colspan="3" width="50%"  height="80">
	                                       Total Student<br />Members<br />
	                                       <h5>1382</h5>
	                                    </td>
	                                 </tr>
	                              </table>
	                           </div>
	                           <!-- col-md-6 -->
	                        </div>
	                        <!-- col-md-12 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <hr class="smallHR" />
	                     <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td bgcolor="#f5f5f5">1</td>
	                                 <td bgcolor="#f5f5f5">P</td>
	                                 <td bgcolor="#f4ecfd"><strong>Rakhshanda Ovais</strong></td>
	                                 <td bgcolor="#ade4f2">ROV-B</td>
	                                 <td bgcolor="#ade4f2">3 (25)</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#ffff00">IND</td>
	                                 <td bgcolor="#ffff00">(ARS)</td>
	                                 <td bgcolor="#e5d998">Headmistress</td>
	                                 <td colspan="2" bgcolor="#e5d998">N-ML-M01</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td bgcolor="#f5f5f5">1</td>
	                                 <td bgcolor="#f5f5f5">P</td>
	                                 <td bgcolor="#f4ecfd"><strong>Rakhshanda Ovais</strong></td>
	                                 <td bgcolor="#ade4f2">ROV-B</td>
	                                 <td bgcolor="#ade4f2">3 (25)</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#ffff00">IND</td>
	                                 <td bgcolor="#ffff00">(ARS)</td>
	                                 <td bgcolor="#e5d998">Headmistress</td>
	                                 <td colspan="2" bgcolor="#e5d998">N-ML-M01</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td bgcolor="#f5f5f5">1</td>
	                                 <td bgcolor="#f5f5f5">P</td>
	                                 <td bgcolor="#f4ecfd"><strong>Rakhshanda Ovais</strong></td>
	                                 <td bgcolor="#ade4f2">ROV-B</td>
	                                 <td bgcolor="#ade4f2">3 (25)</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#ffff00">IND</td>
	                                 <td bgcolor="#ffff00">(ARS)</td>
	                                 <td bgcolor="#e5d998">Headmistress</td>
	                                 <td colspan="2" bgcolor="#e5d998">N-ML-M01</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td bgcolor="#f5f5f5">1</td>
	                                 <td bgcolor="#f5f5f5">P</td>
	                                 <td bgcolor="#f4ecfd"><strong>Rakhshanda Ovais</strong></td>
	                                 <td bgcolor="#ade4f2">ROV-B</td>
	                                 <td bgcolor="#ade4f2">3 (25)</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#ffff00">IND</td>
	                                 <td bgcolor="#ffff00">(ARS)</td>
	                                 <td bgcolor="#e5d998">Headmistress</td>
	                                 <td colspan="2" bgcolor="#e5d998">N-ML-M01</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                  </div>
	                  <!-- orgChartSection -->
	                  <hr style="margin-top: 5px;" />
	                  <div class="orgChartSection">
	                     <h4 class="col-md-6 col-md-offset-3 text-center MatrixRoles">Org Chart Roles(s) <small>for Non-Classroom Roles</small> | Role 2</h4>
	                     <?php /* ?><?php */ ?>
	                     <div class="no-padding col-md-10 col-md-offset-1">
	                        <div class="blackSolidBorder">&nbsp;</div>
	                        <div class="graySolidBorder">&nbsp;</div>
	                        <div class="grayDashedBorder">&nbsp;</div>
	                        <div class="col-md-12 ">
	                           <div class="col-md-6 text-center">
	                              <table width="100%" border="1" class="secondLevelReporting">
	                                 <tr>
	                                    <td colspan="3">
	                                       <h5>PRIMARY GRANDREPORTOO</h5>
	                                    </td>
	                                 </tr>
	                                 <tr>
	                                    <td width="30%" height="40">JN-T001</td>
	                                    <td width="30%">OPQ</td>
	                                    <td width="30%">2</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30">Vice Principal, Junior Section</td>
	                                 </tr>
	                                 <tr>
	                                    <td height="40">GT 10-567</td>
	                                    <td colspan="2">KHN</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30">Khadija Noorani</td>
	                                 </tr>
	                              </table>
	                           </div>
	                           <!-- col-md-6 -->
	                           <div class="col-md-6 text-center">
	                              <table width="100%" border="1" class="secondLevelReporting">
	                                 <tr>
	                                    <td colspan="3">
	                                       <h5>SECONDARY GRANDREPORTOO</h5>
	                                    </td>
	                                 </tr>
	                                 <tr>
	                                    <td width="30%" height="40">JN-T001</td>
	                                    <td width="30%">OPQ</td>
	                                    <td width="30%">2</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30">Vice Principal, Junior Section</td>
	                                 </tr>
	                                 <tr>
	                                    <td height="40">GT 10-567</td>
	                                    <td colspan="2">KHN</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30">Khadija Noorani</td>
	                                 </tr>
	                              </table>
	                           </div>
	                           <!-- col-md-6 -->
	                        </div>
	                        <!-- col-md-12 -->
	                        <div class="col-md-12 paddingTop50">
	                           <div class="col-md-6 text-center">
	                              <table width="100%" border="1" class="firstLevelReporting">
	                                 <tr>
	                                    <td colspan="3">
	                                       <h5>PRIMARY REPORTOO</h5>
	                                    </td>
	                                 </tr>
	                                 <tr>
	                                    <td width="30%" height="40" bgcolor="">JN-T001</td>
	                                    <td width="30%" >OPQ</td>
	                                    <td width="30%" >2</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30" bgcolor="">Vice Principal, Junior Section</td>
	                                 </tr>
	                                 <tr>
	                                    <td height="40" >GT 10-567</td>
	                                    <td colspan="2" bgcolor="#d1fbfb" ><strong>KHN</strong></td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30">Khadija Noorani</td>
	                                 </tr>
	                              </table>
	                           </div>
	                           <!-- col-md-6 -->
	                           <div class="col-md-6 text-center">
	                              <table width="100%" border="1" class="firstLevelReporting">
	                                 <tr>
	                                    <td colspan="3">
	                                       <h5>SECONDARY REPORTOO</h5>
	                                    </td>
	                                 </tr>
	                                 <tr>
	                                    <td width="30%" height="40">JN-T001</td>
	                                    <td width="30%">OPQ</td>
	                                    <td width="30%">2</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30">Vice Principal, Junior Section</td>
	                                 </tr>
	                                 <tr>
	                                    <td height="40">GT 10-567</td>
	                                    <td colspan="2">KHN</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30">Khadija Noorani</td>
	                                 </tr>
	                              </table>
	                           </div>
	                           <!-- col-md-6 -->
	                        </div>
	                        <!-- col-md-12 -->
	                        <div class="col-md-12 paddingTop50">
	                           <div class="col-md-6 col-md-offset-3 text-center" style="background:#e2e2e2;padding:15px;">
	                              <table width="100%" border="1" bgcolor="#fff" class="firstLevelReporting" style="background:#fff;" >
	                                 <tr>
	                                    <td colspan="3" bgcolor="">
	                                       <h5>ROLE 2</h5>
	                                    </td>
	                                 </tr>
	                                 <tr>
	                                    <td width="30%" height="40" bgcolor="">JN-B-01</td>
	                                    <td width="30%" bgcolor="">OPQ</td>
	                                    <td width="30%" bgcolor="">4</td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" height="30" bgcolor="">Headmistress, Junior Section</td>
	                                 </tr>
	                                 <tr>
	                                    <td height="40" bgcolor="">ZHA-A</td>
	                                    <td colspan="2" bgcolor="">Zillehuma Asif</td>
	                                 </tr>
	                              </table>
	                           </div>
	                           <!-- col-md-6 -->
	                        </div>
	                        <!-- col-md-12 -->
	                        <div class="col-md-12 paddingTop50">
	                           <div class="col-md-6 col-md-offset-3 text-center" style="background:none;padding:15px;">
	                              <table width="100%" border="1">
	                                 <tr>
	                                    <td colspan="2" width="33%" height="90">
	                                       Fundamental<br />Primary<br />
	                                       <h5>06</h5>
	                                    </td>
	                                    <td colspan="2" width="33%" height="90">
	                                       Total<br />Primary<br />
	                                       <h5>06</h5>
	                                    </td>
	                                    <td colspan="2" width="33%" height="90">
	                                       Total<br />Reportee<br />
	                                       <h5>06</h5>
	                                    </td>
	                                 </tr>
	                                 <tr>
	                                    <td colspan="3" width="50%"  height="80">
	                                       Total Staff<br />Members<br />
	                                       <h5>200</h5>
	                                    </td>
	                                    <td colspan="3" width="50%"  height="80">
	                                       Total Student<br />Members<br />
	                                       <h5>1382</h5>
	                                    </td>
	                                 </tr>
	                              </table>
	                           </div>
	                           <!-- col-md-6 -->
	                        </div>
	                        <!-- col-md-12 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <hr class="smallHR" />
	                     <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                     <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                        <div class="col-md-6">
	                           <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
	                              <tr>
	                                 <td width="15%" bgcolor="#f5f5f5">1</td>
	                                 <td width="15%" bgcolor="#f5f5f5">P</td>
	                                 <td width="15%" bgcolor="">INDIR</td>
	                                 <td width="15%" bgcolor="">ARS</td>
	                                 <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
	                              </tr>
	                              <tr>
	                                 <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
	                                 <td bgcolor="#e1e1e1">16 (300)</td>
	                                 <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
	                                 <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
	                              </tr>
	                           </table>
	                        </div>
	                        <!-- col-md-6 -->
	                     </div>
	                     <!-- col-md-12 -->
	                  </div>
	                  <!-- orgChartSection -->
	               </div>
	               <!-- tab_1_2 -->

	               <div class="tab-pane fade" id="tab_1_3">
	                  <div class="tabbable-line">
	                     <ul class="nav nav-tabs" id="">
	                        <li class="active">
	                           <a href="#tab_1_3_3" data-toggle="tab"> Attendance Breakdown </a>
	                        </li>
	                        <li>
	                           <a href="#tab_1_3_2" data-toggle="tab"> Absentia </a>
	                        </li>
	                        
	                        <li>
	                           <a href="#tab_1_3_4" data-toggle="tab"> Leave Applications </a>
	                        </li>
	                        <li>
	                           <a href="#tab_1_3_5" data-toggle="tab"> Exceptional Adjustments </a>
	                        </li>
	                        <li>
	                           <a href="#tab_1_3_6" data-toggle="tab"> Missed Tap Event </a>
	                        </li>
	                     </ul>
	                     <div class="tab-content">
	                        
	                        <div class="tab-pane fade active in" id="tab_1_3_3">
	                          <div class="portlet-body">
	                              
	                                <div class="row">
	                                
	                                <div id="datepaginator"> </div>
	                                
	                                    <div class="col-md-12" style="margin-top:20px;">
	                                    
	                                       <!-- BEGIN PORTLET-->
	                                       <div class="portlet light form-fit bordered">
	                                          <div class="portlet-title">
	                                             <div class="caption">
	                                                <i class="icon-settings font-dark"></i>
	                                                <span class="caption-subject font-dark sbold uppercase date_label">Attendance for <?php echo date('D F,d Y') ?></span>
	                                             </div>
	                                          </div><!-- portlet-title -->
	                                          <div class="portlet-body form">
	                                             <div class="opardiv"></div>
	                                             <form role="form" class="form-horizontal form-bordered">
	                                                <div class="form-body">
	                                                   <div class="form-group">
	                                                      <div class="col-md-3">
	                                                         Expected Time
	                                                      </div>
	                                                      <div class="col-md-9" style="height: 84px;">
	                                                         <!-- <input id="range_3" type="text" value="" /> -->
	                                                         <div id="weeklySlider"></div>
	                                                      </div>
	                                                   </div>
	                                                   <!-- form-group -->
	                                                   <div class="form-group">
	                                                      <div class="col-md-3">
	                                                         Tap IN/OUT Attendance
	                                                      </div>
	                                                      <div class="col-md-9">
	                                                         <div id="tapSlider"></div>
	                                                         <!-- <input id="range_3_1" type="text" value="" /> -->
	                                                      </div>
	                                                   </div>
	                                                   <!-- form-group -->
	                                                   <div class="form-group">
	                                                      <div class="col-md-3">
	                                                         Absentia Attendance
	                                                      </div>
	                                                      <div class="col-md-9">
	                                                         <!-- <input id="range_3_2" type="text" value="" /> -->
	                                                         <div id="AiAabsentia"></div>
	                                                      </div>
	                                                   </div>
	                                                   <!-- form-group -->
	                                                   <div class="form-group">
	                                                      <div class="col-md-3">
	                                                         Buffer Time Utilization
	                                                      </div>
	                                                      <div class="col-md-9">
	                                                         <!-- <input id="range_3_3" type="text" value="" /> -->
	                                                         <div id="bufferTime"></div>
	                                                      </div>
	                                                   </div>
	                                                   <!-- form-group -->
	                                                   <div class="form-group">
	                                                      <div class="col-md-3">
	                                                         Payroll Attendance
	                                                      </div>
	                                                      <div class="col-md-9">
	                                                         <!-- <input id="range_3_4" type="text" value="" /> -->
	                                                         <div id="PayrollAttendance"></div>
	                                                      </div>
	                                                   </div>
	                                                   <!-- form-group -->
	                                                   <div class="form-group">
	                                                      <div class="col-md-3">
	                                                         Complaince
	                                                      </div>
	                                                      <div class="col-md-9">
	                                                         <div class="col-md-2 text-center">
	                                                            <img src="img/complaint.png" width="24" class="compliance_one_img" /><br /><small>In Compliance</small>
	                                                         </div>
	                                                         <div class="col-md-8 text-center">
	                                                            <img src="img/noncomplaint.png" width="24" class="compliance_duration_img" /><br /><small>Duration Compliance</small>
	                                                         </div>
	                                                         <div class="col-md-2 text-center">
	                                                            <img src="img/complaint.png" width="24" class="compliance_two_img"  /><br /><small>Out Compliance</small>
	                                                         </div>
	                                                      </div>
	                                                   </div>
	                                                </div>
	                                                <!-- form-body -->
	                                             </form>
	                                             <!-- form-horizontal -->
	                                             <div style="padding:10px 20px;">
	                                             <h4 class="text-center">Compensation & Proportion details</h4>
	                                             <table class="table table-striped table-hover table-bordered">
	                                                <thead style="background: #efefef;">
	                                                   <tr>
	                                                       <!--  <th width="25%" class="text-center">Attendance Complaince<br />Proportion</th> -->
	                                                        <th width="33%" class="text-center">Non Compliant<br />Adjustment Factor</th>
	                                                        <th width="33%" class="text-center">Attendance Compensation<br />Proportion</th>
	                                                        <th width="34%" class="text-center">Attendance Deduction<br />Proportion</th>
	                                                    </tr>
	                                                </thead>
	                                                <tbody>
	                                                   <tr>
	                                                      <!-- <td class="text-center">0.89</td> -->
	                                                        <td class="text-center">0.8</td>
	                                                        <td class="text-center factor_remaining_deduction"></td>
	                                                        <td class="text-center factor_deduction_from"></td>
	                                                    </tr>
	                                                </tbody>
	                                             </table>
	                                             
	                                             <h4 class="text-center">Leaves status & Buffer details</h4>
	                                             <table class="table table-striped table-hover table-bordered">
	                                                <thead style="background: #efefef;">
	                                                   <tr>
	                                                        <th width="25%" class="text-center">Previous EL<br />Balance</th>
	                                                        <th width="25%" class="text-center">Current EL<br />Balance</th>
	                                                        <th width="25%" class="text-center">Daily Buffer Used<br /><small class="daily_buffer_assign"></small></th>
	                                                        <th width="25%" class="text-center">Remaining Buffer<br /><small class="monthly_buffer_assign"></small></th>
	                                                    </tr>
	                                                </thead>
	                                                <tbody>
	                                                   <tr>
	                                                      <td class="text-center previous_el_balance"></td>
	                                                        <td class="text-center current_el_balance"></td>
	                                                        <td class="text-center daily_buffer_used" ><strong>0 min</strong> <small>/</small> <strong>5 min</strong></td>
	                                                        <td class="text-center monthly_buffer_used"><strong>0 min</strong> <small>/</small> <strong>15 min</strong></td>
	                                                    </tr>
	                                                </tbody>
	                                             </table>
	                                             </div>
	                                          </div><!-- portlet-body -->
	                                       </div><!-- portlet -->
	                                       <!-- END PORTLET-->
	                                    </div><!-- col-md-12 -->
	                                </div><!-- row -->
	                          </div>
	                        </div>
	                        <!-- tab_1_3_3 -->
	                        <div class="tab-pane" id="tab_1_3_2">
	                           <div class="portlet light bordered padding0 marginBottom0">
	                              <div class="portlet-title">
	                                 <div class="caption">
	                                    <i class="icon-users font-dark"></i>
	                                    <span class="caption-subject font-dark sbold uppercase">Absentia </span>
	                                 </div>
	                                 <div class="actions">
	                                    <div class="btn-group btn-group-devided" data-toggle="buttons">
	                                       <!-- <input type="radio" name="options" class="toggle" id="profileDefinationAdd">Add New Profile</label> -->
	                                       <button class="tooltips btn btn-transparent dark btn-outline btn-circle btn-sm" data-placement="bottom" data-original-title="Add Absentia" data-toggle="modal" href="#AddAIA" id="">Add Absentia</button>
	                                    </div>
	                                 </div>
	                              </div>
	                              <!-- portlet-title -->
	                              <div class="portlet-body" style="padding:15px;">
	                                 <table width="100%" border="0" class="table table-striped table-hover table-bordered" id="absentia_table">
	                                    <thead>
	                                       <tr>
	                                          <th width="15%">Title</th>
	                                          <th width="15%">Date</th>
	                                          <th width="15%">From <small>(time)</small></th>
	                                          <th width="15%">To <small>(time)</small></th>
	                                          <th width="30%">Description</th>
	                                          <th width="30%">Action</th>
	                                       </tr>
	                                    </thead>
	                                    <tbody>
	                                    </tbody>
	                                 </table>
	                              </div>
	                              <!-- portlet-body -->
	                              <div class="modal fade" id="AddAIA" tabindex="-1" role="basic" aria-hidden="true">
	                                 <div class="modal-dialog">
	                                    <div class="modal-content">
	                                       <div class="modal-header">
	                                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
	                                          <h3 class="modal-title">Add Absentia</h3>
	                                       </div>
	                                       <div class="modal-body" style="float:left;width:100%;">
	                                          <div class="portlet box blue-hoki">
	                                             <div class="portlet-title">
	                                                <div class="caption">
	                                                   <i class="fa fa-user"></i><font id="selected_individuals">Attendance in Absentia form</font>
	                                                </div>
	                                             </div>
	                                             <!-- portlet-title -->
	                                             <div class="headRightDetailsInner">
	                                                <table>
	                                                   <tbody>
	                                                      <tr id="">
	                                                         <td class="" style="padding-right:10px;">
	                                                            <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
	                                                         </td>
	                                                         <td class="staffView_StaffName">
	                                                            <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
	                                                         </td>
	                                                      </tr>
	                                                   </tbody>
	                                                </table>
	                                                <!-- col-md-4 -->
	                                             </div>
	                                             <div class="portlet-body fixedHeightmodalPortlet">
	                                                <div class="form-body">
	                                                   <div class="row">
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Title:</label>
	                                                            <div class="">
	                                                               <input type="text" class="form-control" name="" id="absentia_title" data-id="">
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Date:</label>
	                                                            <div class="">
	                                                               <input type="date" class="form-control" name="" id="absentia_date" data-id="">
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                   <div class="row">
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Start Time:</label>
	                                                            <div class="">
	                                                               <input type="time" class="form-control" name="" id="absentia_startTime" data-id="">
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">End Time:</label>
	                                                            <div class="">
	                                                               <input type="time" class="form-control" name="" id="absentia_endTime" data-id="">
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                   <div class="row">
	                                                      <div class="col-md-12 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Description:</label>
	                                                            <div class="">
	                                                               <textarea id="absentia_description" cols="85" rows="5"></textarea>
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                </div>
	                                                <!-- form-body -->
	                                             </div>
	                                             <!-- portlet-body fixedHeightmodalPortlet-->
	                                          </div>
	                                       </div>
	                                       <div class="modal-footer text-center" style="text-align:center;">
	                                          <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
	                                          <button onclick="addAbsentia()" type="button" class="btn dark btn-outline active" data-dismiss="">Add</button>
	                                          <!--button type="button" class="btn green">Add Badge</button -->
	                                       </div>
	                                    </div>
	                                    <!-- /.modal-content -->
	                                 </div>
	                                 <!-- /.modal-dialog -->
	                              </div>
	                              <!-- Start Edit Absenia_id -->
	                              <div class="modal fade" id="AddAIAE" tabindex="-1" role="basic" aria-hidden="true">
	                                  <input type="hidden" name="Edit_Absentia_id_hidden" id="Edit_Absentia_id_hidden" value="0" />
	                                  <input type="hidden" name="Edit_Absentia_id_staff_id_hidden" id="Edit_Absentia_id_staff_id_hidden" value="0" />
	                                  
	                                  
	                                           <div class="modal-dialog">
	                                              <div class="modal-content">
	                                                 <div class="modal-header">
	                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
	                                                    <h3 class="modal-title">Edit Absentia</h3>
	                                                 </div>
	                                                 <div class="modal-body" style="float:left;width:100%;">
	                                                    <div class="portlet box blue-hoki">
	                                                       <div class="portlet-title">
	                                                          <div class="caption">
	                                                             <i class="fa fa-user"></i><font id="selected_individuals">Attendance in Absentia form</font>
	                                                          </div>
	                                                       </div>
	                                                       <!-- portlet-title -->
	                                                       <div class="headRightDetailsInner">
	                                                          <table>
	                                                             <tbody>
	                                                                <tr id="">
	                                                                   <td class="" style="padding-right:10px;">
	                                                                      <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" src="" width="42">
	                                                                   </td>
	                                                                   <td class="staffView_StaffName">
	                                                                      <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" ></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" ></span></small>
	                                                                   </td>
	                                                                </tr>
	                                                             </tbody>
	                                                          </table>
	                                                          <!-- col-md-4 -->
	                                                       </div>
	                                                       <div class="portlet-body fixedHeightmodalPortlet">
	                                                          <div class="form-body" id="Absenia_Contents"> </div>
	                                                          <!-- form-body -->
	                                                       </div>
	                                                       <!-- portlet-body fixedHeightmodalPortlet-->
	                                                    </div>
	                                                 </div>
	                                                 <div class="modal-footer text-center" style="text-align:center;">
	                                                    <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
	                                                    <button onclick="addAbsentiaE()" type="button" class="btn dark btn-outline active" data-dismiss="">Update</button>
	                                                    <!--button type="button" class="btn green">Add Badge</button -->
	                                                 </div>
	                                              </div>
	                                              <!-- /.modal-content -->
	                                           </div>
	                                           <!-- /.modal-dialog -->
	                                        </div>
	                              <!-- End Edit Absenia_id-->
	                            </div>
	                           <!-- portlet -->
	                        </div>
	                        <!-- tab_1_3_2 -->
	                        
	                        <div class="tab-pane" id="tab_1_3_4">
	                           <div class="portlet light bordered padding0">
	                              <div class="portlet-title">
	                                 <div class="caption">
	                                    <i class="icon-users font-dark"></i>
	                                    <span class="caption-subject font-dark sbold uppercase"> Leave Applications </span>
	                                 </div>
	                                 <div class="actions">
	                                    <div class="btn-group btn-group-devided" data-toggle="buttons">
	                                       <!-- <input type="radio" name="options" class="toggle" id="profileDefinationAdd">Add New Profile</label> -->
	                                       <button class="tooltips btn btn-transparent dark btn-outline btn-circle btn-sm" data-placement="bottom" data-original-title="Leave Application" data-toggle="modal" href="#LeaveApp" onClick="clearLeave()">Apply for Leave</button>
	                                    </div>
	                                 </div>
	                              </div>
	                              <!-- portlet-title -->
	                              <div class="portlet-body" style="padding:15px;">
	                                 <table width="100%" border="0" class="table table-striped table-hover table-bordered" id="leave_table">
	                                    <thead>
	                                       <tr>
	                                          <th width="15%">Title <small>(type)</small></th>
	                                          <th width="12%">Compensation</th>
	                                          <th width="15%">From </th>
	                                          <th width="13%">To </th>
	                                          <th width="30%">Additional Comments</th>
	                                          <th width="9%" class="text-center">Action</th>
	                                       </tr>
	                                    </thead>
	                                    <tbody class="font-grey-mint">
	                          
	                                    </tbody>
	                                 </table>
	                              </div>
	                     
	                              <!-- portlet-body -->
	                              <div class="modal fade" id="LeaveApproval" tabindex="-1" role="basic" aria-hidden="true">
	                                 <div class="modal-dialog">
	                                    <div class="modal-content">
	                                       <div class="modal-header">
	                                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
	                                          <h3 class="modal-title">Leave Application Approval</h3>
	                                       </div>
	                                       <div class="modal-body" style="float:left;width:100%;">
	                                          <div class="portlet box blue-hoki">
	                                             <div class="portlet-title">
	                                                <div class="caption">
	                                                   <i class="fa fa-user"></i><font id="">Leave Approval</font>
	                                                </div>
	                                             </div>
	                                             <!-- portlet-title -->
	                                             <div class="headRightDetailsInner">
	                                                <table>
	                                                   <tbody>
	                                                      <tr id="">
	                                                         <td class="" style="padding-right:10px;">
	                                                            <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
	                                                         </td>
	                                                         <td class="staffView_StaffName">
	                                                            <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
	                                                         </td>
	                                                      </tr>
	                                                   </tbody>
	                                                </table>
	                                                <!-- col-md-4 -->
	                                             </div>
	                                             <!-- headRightDetailsInner -->
	                                             <div class="portlet-body fixedHeightmodalPortlet">
	                                                <div class="form-body">
	                                                   <div class="row">
	                                                      <div class="col-md-12 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Leave Status</label>
	                                                            <div class="">
	                                                               <span class="switch-box">
	                                                               <input type="checkbox" data-on-text="Approve" data-off-text="Disapprove" id="change-color-switch" class="ck-in switch-box a1">
	                                                               </span>
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                   <div class="row">
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Leave Title:</label>
	                                                            <div class="">
	                                                               <input type="hidden" id="leave_title_id"/>
	                                                               <input type="text" class="form-control" id="leave_title_update"  disabled="disabled">
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Leave Type:</label>
	                                                            <div class="">
	                                                               <select class="form-control" id="leave_type_update">
	                                                               <option selected disabled value="0">Select Leave Type</option>
	                                                               @foreach($leaveType as $type)
	                                                                  <option value="{{$type->id}}">{{$type->leave_type_name}}</option>
	                                                               @endforeach
	                                                               </select>
	                                                               <!-- select -->
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                   <div class="row">
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">From:</label>
	                                                            <div class="">
	                                                               <input type="date" class="form-control"  id="leave_from_update" data-id="" disabled="disabled">
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">To:</label>
	                                                            <div class="">
	                                                               <input type="date" class="form-control"  id="leave_to_update" data-id="" disabled="disabled">
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                   <div class="no-padding" id="approvedformShow" style="display:none;">
	                                                      <div class="row">
	                                                         <div class="col-md-6 paddingBottom10">
	                                                            <div class="form-group">
	                                                               <label class="">Approved From:</label>
	                                                               <div class="">
	                                                                  <input type="date" class="form-control" id="approve_from">
	                                                               </div>
	                                                            </div>
	                                                            <!-- form-group -->
	                                                         </div>
	                                                         <!-- col-md-6 -->
	                                                         <div class="col-md-6 paddingBottom10">
	                                                            <div class="form-group">
	                                                               <label class="">Approved To:</label>
	                                                               <div class="">
	                                                                  <input type="date" class="form-control" id="approve_to">
	                                                               </div>
	                                                            </div>
	                                                            <!-- form-group -->
	                                                         </div>
	                                                         <!-- col-md-6 -->
	                                                      </div>
	                                                      <!-- row -->
	                                                      <div class="row">
	                                                         <div class="col-md-6 paddingBottom10">
	                                                            <div class="form-group">
	                                                               <label class="">Paid Compensation:</label>
	                                                               <div class="">
	                                                                  <span class="switch-box">
	                                                                  <input type="checkbox" data-on-text="Yes" data-off-text="No" id="changeSwitch" class="ck-in switch-box a1">
	                                                                  </span>
	                                                               </div>
	                                                            </div>
	                                                            <!-- form-group -->
	                                                         </div>
	                                                         <!-- col-md-6 -->
	                                                         <div class="col-md-6 paddingBottom10" id="paidField" style="display:none;">
	                                                            <div class="form-group">
	                                                               <label class="">Paid Percent:</label>
	                                                               <div class="input-group">
	                                                                  <input type="number" class="form-control" id="paid_compensation_percentage">
	                                                                  <span class="input-group-addon">
	                                                                  <i class="fa fa-percent"></i>
	                                                                  </span>
	                                                               </div>
	                                                            </div>
	                                                            <!-- form-group -->
	                                                         </div>
	                                                         <!-- col-md-6 -->
	                                                      </div>
	                                                      <!-- row -->
	                                                   </div>
	                                                   <div class="row">
	                                                      <div class="col-md-12 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Additional Comments <small>(if any)</small>:</label>
	                                                            <div class="">
	                                                               <textarea id="leave_comment_update" cols="85" rows="5"></textarea>
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                </div>
	                                                <!-- form-body -->
	                                             </div>
	                                             <!-- portlet-body fixedHeightmodalPortlet-->
	                                          </div>
	                                       </div>
	                                       <div class="modal-footer text-center" style="text-align:center;">
	                                          <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
	                                          <button onClick="LeaveUpdateById()" type="button" class="btn dark btn-outline active" data-dismiss="">Submit</button>
	                                          <!--button type="button" class="btn green">Add Badge</button -->
	                                       </div>
	                                    </div>
	                                    <!-- /.modal-content -->
	                                 </div>
	                                 <!-- /.modal-dialog -->
	                              </div>
	                              
	                     
	                            <div class="modal fade" id="LeaveApp" tabindex="-1" role="basic" aria-hidden="true">
	                                 <div class="modal-dialog">
	                                    <div class="modal-content">
	                                       <div class="modal-header">
	                                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
	                                          <h3 class="modal-title">Leave Application</h3>
	                                       </div>
	                                       <div class="modal-body" style="float:left;width:100%;">
	                                          <div class="portlet box blue-hoki">
	                                             <div class="portlet-title">
	                                                <div class="caption">
	                                                   <i class="fa fa-user"></i><font id="">Leave form</font>
	                                                </div>
	                                             </div>
	                                             <!-- portlet-title -->
	                                             <div class="headRightDetailsInner">
	                                                <table>
	                                                   <tbody>
	                                                      <tr id="">
	                                                         <td class="" style="padding-right:10px;">
	                                                            <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
	                                                         </td>
	                                                         <td class="staffView_StaffName">
	                                                            <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
	                                                         </td>
	                                                      </tr>
	                                                   </tbody>
	                                                </table>
	                                                <!-- col-md-4 -->
	                                             </div>
	                                             <!-- headRightDetailsInner -->
	                                             <div class="portlet-body fixedHeightmodalPortlet">
	                                                <div class="form-body">
	                                                   <div class="row">
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Leave Title:</label>
	                                                            <div class="">
	                                                               <input type="text" class="form-control" name="" id="leave_title" >
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Leave Type:</label>
	                                                            <div class="leave_type">
	                                                               <select class="form-control">
	                                                               <option selected disabled value="0">Select Leave Type</option>
	                                                               @foreach($leaveType as $type)
	                                                                  <option value="{{$type->id}}">{{$type->leave_type_name}}</option>
	                                                               @endforeach
	                                                               </select>
	                                                               <!-- select -->
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                   <div class="row">
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">From:</label>
	                                                            <div class="">
	                                                               <input type="date" class="form-control" name="" id="leave_from">
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">To:</label>
	                                                            <div class="">
	                                                               <input type="date" class="form-control" name="" id="leave_to">
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                   <div class="row">
	                                                      <div class="col-md-12 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Additional Comments <small>(if any)</small>:</label>
	                                                            <div class="">
	                                                               <textarea id="leave_comment" cols="85" rows="5"></textarea>
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                   <div class="row">
	                                                      <div class="col-md-12 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Request for a paid Compensation</label>
	                                                            <div class="">
	                                                               <input type="checkbox" class="make-switch" data-on-text="Yes" data-off-text="No" id="limit">
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                </div>
	                                                <!-- form-body -->
	                                             </div>
	                                             <!-- portlet-body fixedHeightmodalPortlet-->
	                                          </div>
	                                       </div>
	                                       <div class="modal-footer text-center" style="text-align:center;">
	                                          <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
	                                          <button onClick="add_leave()" type="button" class="btn dark btn-outline active" data-dismiss="">Add</button>
	                                          <!--button type="button" class="btn green">Add Badge</button -->
	                                       </div>
	                                    </div>
	                                    <!-- /.modal-content -->
	                                 </div>
	                                 <!-- /.modal-dialog -->
	                            </div>
	                          
	                            <!-- Kashif Solangi Leave Application Edit Functionality Modal-->
	                            <div class="modal fade" id="LeaveAppForEdit" tabindex="-1" role="basic" aria-hidden="true">
	                               <div class="modal-dialog">
	                                  <div class="modal-content">
	                                     <div class="modal-header">
	                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
	                                        <h3 class="modal-title">Leave Application</h3>
	                                     </div>
	                                     <div class="modal-body" style="float:left;width:100%;">
	                                        <div class="portlet box blue-hoki">
	                                           <div class="portlet-title">
	                                              <div class="caption">
	                                                 <i class="fa fa-user"></i><font id="">Leave form</font>
	                                              </div>
	                                           </div>
	                                           <!-- portlet-title -->
	                                           <div class="headRightDetailsInner">
	                                              <table>
	                                                 <tbody>
	                                                    <tr id="">
	                                                       <td class="" style="padding-right:10px;">
	                                                          <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
	                                                       </td>
	                                                       <td class="staffView_StaffName">
	                                                          <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
	                                                       </td>
	                                                    </tr>
	                                                 </tbody>
	                                              </table>
	                                              <!-- col-md-4 -->
	                                           </div>
	                                           <!-- headRightDetailsInner -->
	                                           <div class="portlet-body fixedHeightmodalPortlet">
	                                              <div class="form-body" id="Leave_main_containter">
	                                             </div>
	                                              <!-- form-body -->
	                                           </div>
	                                           <!-- portlet-body fixedHeightmodalPortlet-->
	                                        </div>
	                                     </div>
	                                     <div class="modal-footer text-center" style="text-align:center;">
	                                        <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
	                                        <button onClick="edit_leave()" type="button" class="btn dark btn-outline active" data-dismiss=""> Update </button>
	                                        <!--button type="button" class="btn green">Add Badge</button -->
	                                     </div>
	                                  </div>
	                                  <!-- /.modal-content -->
	                               </div>
	                               <!-- /.modal-dialog -->
	                            </div>
	                           <!-- End Kashi Solangi Leave Applicaiton Modal -->
	                            </div>
	                           <!-- portlet -->
	                           <div class="portlet light bordered padding0">
	                              <div class="portlet-title">
	                                 <div class="caption">
	                                    <i class="icon-users font-dark"></i>
	                                    <span class="caption-subject font-dark sbold uppercase"> Unauthorized Leave Penalties </span>
	                                 </div>
	                                 <div class="actions">
	                                    <div class="btn-group btn-group-devided" data-toggle="buttons">
	                                       <!-- <input type="radio" name="options" class="toggle" id="profileDefinationAdd">Add New Profile</label> -->
	                                       <button class="tooltips btn btn-transparent dark btn-outline btn-circle btn-sm" data-placement="bottom" data-original-title="Unauthorized Leave Penalty" data-toggle="modal" href="#UnAuthLeavePen" id="">Penalty</button>
	                                    </div>
	                                 </div>
	                              </div>
	                              <!-- portlet-title -->
	                              <div class="portlet-body" style="padding:15px;">
	                                 <table width="100%" border="0" class="table table-striped table-hover table-bordered" id="penaltyTable">
	                                    <thead>
	                                       <tr>
	                                           <th width="15%">Penalty Title</th>
	                                          <th width="10%" scope="row">Penalty <br /> (no of days)</th>
	                                          <th width="15%">From - To </th>
	                                          <th width="15%">Timestamp </th>
	                                          <th width="22%">Additional Comments</th>
	                                          <th width="10%">Action</th>
	                                       </tr>
	                                    </thead>
	                                    <tbody class="font-grey-mint">

	                                    </tbody>
	                                 </table>
	                              </div>
	                              <!-- portlet-body -->
	                              <div class="modal fade" id="UnAuthLeavePen" tabindex="-1" role="basic" aria-hidden="true">
	                                 <div class="modal-dialog">
	                                    <div class="modal-content">
	                                       <!-- <div class="modal-header">
	                                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
	                                          <h3 class="modal-title">Leave Application Approval</h3>
	                                          </div> -->
	                                       <div class="modal-body" style="float:left;width:100%;">
	                                          <div class="portlet box blue-hoki">
	                                             <div class="portlet-title">
	                                                <div class="caption">
	                                                   <i class="fa fa-user"></i><font id="">Penalty</font>
	                                                </div>
	                                             </div>
	                                             <!-- portlet-title -->
	                                             <div class="headRightDetailsInner">
	                                                <table>
	                                                   <tbody>
	                                                      <tr id="">
	                                                         <td class="" style="padding-right:10px;">
	                                                            <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
	                                                         </td>
	                                                         <td class="staffView_StaffName">
	                                                            <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
	                                                         </td>
	                                                      </tr>
	                                                   </tbody>
	                                                </table>
	                                                <!-- col-md-4 -->
	                                             </div>
	                                             <!-- headRightDetailsInner -->
	                                             <div class="portlet-body fixedHeightmodalPortlet">
	                                                <div class="form-body">
	                                                   <div class="row">
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Penalty Title:</label>
	                                                            <div class="">
	                                                               <input type="text" class="form-control" name="" id="penalty_title">
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Penalty for <small>(no of days)</small>:</label>
	                                                            <div class="input-group">
	                                                               <input type="number" class="form-control" id="penalty_day">
	                                                               <span class="input-group-addon">
	                                                               <i class="fa fa-hashtag"></i>
	                                                               </span>
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                   <div class="row">
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Penalty from:</label>
	                                                            <div class="">
	                                                               <input type="date" class="form-control"  id="penalty_from">
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Penalty to:</label>
	                                                            <div class="">
	                                                               <input type="date" class="form-control" id="penalty_to">
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                   <div class="row">
	                                                      <div class="col-md-12 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Information regarding Penalty:</label>
	                                                            <div class="">
	                                                               <textarea cols="85" rows="5" id="penalty_description"></textarea>
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                </div>
	                                                <!-- form-body -->
	                                             </div>
	                                             <!-- portlet-body fixedHeightmodalPortlet-->
	                                          </div>
	                                       </div>
	                                       <div class="modal-footer text-center" style="text-align:center;">
	                                          <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
	                                          <button onCLick="addPenalty()" type="button" class="btn dark btn-outline active" data-dismiss="">Submit</button>
	                                          <!--button type="button" class="btn green">Add Badge</button -->
	                                       </div>
	                                    </div>
	                                    <!-- /.modal-content -->
	                                 </div>
	                                 <!-- /.modal-dialog -->
	                              </div>
	                            <!-- Edit Penalties -->
	                             <div class="modal fade" id="UnAuthLeavePenEdit" tabindex="-1" role="basic" aria-hidden="true">
	                                <div class="modal-dialog">
	                                  <div class="modal-content">
	                                   <div class="modal-body" style="float:left;width:100%;">
	                                      <div class="portlet box blue-hoki">
	                                         <div class="portlet-title">
	                                           <div class="caption">
	                                             <i class="fa fa-user"></i><font id="">Penalty</font>
	                                           </div>
	                                         </div>
	                                         <div class="headRightDetailsInner">
	                                           <table>
	                                             <tbody>
	                                               <tr id="">
	                                                  <td class="" style="padding-right:10px;">
	                                                    <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
	                                                  </td>
	                                                  <td class="staffView_StaffName">
	                                                    <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
	                                                  </td>
	                                               </tr>
	                                             </tbody>
	                                           </table>
	                                           <!-- col-md-4 -->
	                                         </div>
	                                         <!-- headRightDetailsInner -->
	                                         <div class="portlet-body fixedHeightmodalPortlet">
	                                           <div class="form-body" id="Penalties_Contents">
	                                            
	                                           </div>
	                                         </div>
	                                      </div>
	                                    </div>
	                                    <div class="modal-footer text-center" style="text-align:center;">
	                                      <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
	                                      <button onCLick="editPenalty()" type="button" class="btn dark btn-outline active" data-dismiss=""> Update </button>
	                                    </div>
	                                  </div>
	                                </div>
	                             </div>
	                              <!-- End Penalties -->
	                           </div>
	                           <!-- portlet -->
	                        </div>
	                        <!-- tab_1_3_4 -->
	                        <div class="tab-pane" id="tab_1_3_5">
	                           <div class="portlet light bordered padding0">
	                              <div class="portlet-title">
	                                 <div class="caption">
	                                    <i class="icon-users font-dark"></i>
	                                    <span class="caption-subject font-dark sbold uppercase"> Exceptional Adjustments </span>
	                                 </div>
	                                 <div class="actions">
	                                    <div class="btn-group btn-group-devided" data-toggle="buttons">
	                                       <!-- <input type="radio" name="options" class="toggle" id="profileDefinationAdd">Add New Profile</label> -->
	                                       <button class="tooltips btn btn-transparent dark btn-outline btn-circle btn-sm" data-placement="bottom" data-original-title="Add Exceptional Adjustment" data-toggle="modal" href="#ExceptionalAdjustmentForm" onClick="clearAdjustment()">Adjustments</button>
	                                    </div>
	                                 </div>
	                              </div>
	                              <!-- portlet-title -->
	                              <div class="portlet-body" style="padding:15px;">
	                                 <table width="100%" border="0" class="table table-striped table-hover table-bordered" id="adjustment_table">
	                                    <thead>
	                                       <tr>
	                                         <th width="15%">Adjustment Title</th>
	                                          <th width="10%">Adjustment <br />(no of days)</th>
	                                          <th width="15%">Timestamp </th>
	                                          <th width="22%">Additional Comments</th>
	                                          <th width="10%">Action</th>
	                                       </tr>
	                                    </thead>
	                                    <tbody class="font-grey-mint">
	                                    </tbody>
	                                 </table>
	                              </div>
	                              <!-- portlet-body -->
	                              <div class="modal fade" id="ExceptionalAdjustmentForm" tabindex="-1" role="basic" aria-hidden="true">
	                                 <div class="modal-dialog">
	                                    <div class="modal-content">
	                                       <!-- <div class="modal-header">
	                                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
	                                          <h3 class="modal-title">Leave Application Approval</h3>
	                                          </div> -->
	                                       <div class="modal-body" style="float:left;width:100%;">
	                                          <div class="portlet box blue-hoki">
	                                             <div class="portlet-title">
	                                                <div class="caption">
	                                                   <i class="fa fa-user"></i><font id="">Adjustments</font>
	                                                </div>
	                                             </div>
	                                             <!-- portlet-title -->
	                                             <div class="headRightDetailsInner">
	                                                <table>
	                                                   <tbody>
	                                                      <tr id="">
	                                                         <td class="" style="padding-right:10px;">
	                                                            <img class="user-pic rounded  absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="assets/photos/hcm/150x150/staff/782.png" width="42">
	                                                         </td>
	                                                         <td class="staffView_StaffName">
	                                                            <a href="javascript:;" class="primary-link absentia_staff_name tooltips" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="tooltips absentia_name_code" data-container="body" data-placement="top" data-original-title="a.hussain"></small><br><small class="shortHeight"><span class="tooltips absentia_bottom_line" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
	                                                         </td>
	                                                      </tr>
	                                                   </tbody>
	                                                </table>
	                                                <!-- col-md-4 -->
	                                             </div>
	                                             <!-- headRightDetailsInner -->
	                                             <div class="portlet-body fixedHeightmodalPortlet">
	                                                <div class="form-body">
	                                                   <div class="row">
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Title:</label>
	                                                            <div class="">
	                                                               <input type="text" class="form-control" name="" id="adjustment_title" >
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Adjustment for <small>(no of days)</small>:</label>
	                                                            <div class="input-group">
	                                                               <input type="number" class="form-control" id="adjustment_no">
	                                                               <span class="input-group-addon">
	                                                               <i class="fa fa-hashtag"></i>
	                                                               </span>
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                   <div class="row">
	                                                      <div class="col-md-12 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Information regarding Adjustments:</label>
	                                                            <div class="">
	                                                               <textarea id="adjustment_description" cols="85" rows="5"></textarea>
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                </div>
	                                                <!-- form-body -->
	                                             </div>
	                                             <!-- portlet-body fixedHeightmodalPortlet-->
	                                          </div>
	                                       </div>
	                                       <div class="modal-footer text-center" style="text-align:center;">
	                                          <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
	                                          <button onClick="addAdjustment()" type="button" class="btn dark btn-outline active">Submit</button>
	                                          <!--button type="button" class="btn green">Add Badge</button -->
	                                       </div>
	                                    </div>
	                                    <!-- /.modal-content -->
	                                 </div>
	                                 <!-- /.modal-dialog -->
	                              </div>
	                              <!-- portlet-body -->
	                              <div class="modal fade" id="ExceptionalAdjustmentFormEdit" tabindex="-1" role="basic" aria-hidden="true">
	                                 <div class="modal-dialog">
	                                    <div class="modal-content">
	                                      
	                                       <div class="modal-body" style="float:left;width:100%;">
	                                          <div class="portlet box blue-hoki">
	                                             <div class="portlet-title">
	                                                <div class="caption">
	                                                   <i class="fa fa-user"></i><font id="">Adjustments</font>
	                                                </div>
	                                             </div>
	                                             <!-- portlet-title -->
	                                             <div class="headRightDetailsInner">
	                                                <table>
	                                                   <tbody>
	                                                      <tr id="">
	                                                         <td class="" style="padding-right:10px;">
	                                                            <img class="user-pic rounded  absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="assets/photos/hcm/150x150/staff/782.png" width="42">
	                                                         </td>
	                                                         <td class="staffView_StaffName">
	                                                            <a href="javascript:;" class="primary-link absentia_staff_name tooltips" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="tooltips absentia_name_code" data-container="body" data-placement="top" data-original-title="a.hussain"></small><br><small class="shortHeight"><span class="tooltips absentia_bottom_line" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
	                                                         </td>
	                                                      </tr>
	                                                   </tbody>
	                                                </table>
	                                                <!-- col-md-4 -->
	                                             </div>
	                                             <!-- headRightDetailsInner -->
	                                             <div class="portlet-body fixedHeightmodalPortlet">
	                                                <div class="form-body" id="Adjustment_Contents">
	                                   
	                                                
	                                   </div>
	                                                <!-- form-body -->
	                                             </div>
	                                             <!-- portlet-body fixedHeightmodalPortlet-->
	                                          </div>
	                                       </div>
	                                       <div class="modal-footer text-center" style="text-align:center;">
	                                          <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
	                                          <button onClick="editAdjustment()" type="button" class="btn dark btn-outline active">Update</button>
	                                          <!--button type="button" class="btn green">Add Badge</button -->
	                                       </div>
	                                    </div>
	                                    <!-- /.modal-content -->
	                                 </div>
	                                 <!-- /.modal-dialog -->
	                              </div>
	                            </div>
	                           <!-- portlet -->
	                        </div>
	                        <!-- tab_1_3_5 -->
	                        <div class="tab-pane" id="tab_1_3_6">
	                           <div class="portlet light bordered padding0">
	                              <div class="portlet-title">
	                                 <div class="caption">
	                                    <i class="icon-users font-dark"></i>
	                                    <span class="caption-subject font-dark sbold uppercase"> Missed Tap Event </span>
	                                 </div>
	                                 <div class="actions">
	                                    <div class="btn-group btn-group-devided" data-toggle="buttons">
	                                       <!-- <input type="radio" name="options" class="toggle" id="profileDefinationAdd">Add New Profile</label> -->
	                                       <button class="tooltips btn btn-transparent dark btn-outline btn-circle btn-sm" data-placement="bottom" data-original-title="Add Exceptional Adjustment" data-toggle="modal" href="#ManualAttendanceForm" onClick="clearManual()">Attendance</button>
	                                    </div>
	                                 </div>
	                              </div>
	                              <!-- portlet-title -->
	                              <div class="portlet-body" style="padding:15px;">
	                     
	                                 <input type="hidden" name="Missed_id" id="Missed_id" value="0" />
	                                 <input type="hidden" name="Table_name" id="Table_name" value="0" />
	                     
	                                 <table width="100%" border="0" class="table table-striped table-hover table-bordered" id="manual_table">
	                                    <thead>
	                                      
	                                       <tr>
	                                          <th width="15%">Attendance Date </th>
	                                          <th width="12%">Tap</th>
	                                          <th width="15%">Timestamp </th>
	                                          <th width="23%">Additional Comments</th>
	                                          <th width="10%">Action</th>
	                                       </tr>
	                                    </thead>
	                                 
	                                    <tbody class="font-grey-mint">
	                                    </tbody>
	                                 </table>
	                              </div>
	                              <!-- portlet-body -->
	                              <div class="modal fade" id="ManualAttendanceForm" tabindex="-1" role="basic" aria-hidden="true">
	                                 <div class="modal-dialog">
	                                   <div class="modal-content">
	                                       <div class="modal-body" style="float:left;width:100%;">
	                                          <div class="portlet box blue-hoki">
	                                             <div class="portlet-title">
	                                                <div class="caption">
	                                                   <i class="fa fa-user"></i><font id="">Manual</font>
	                                                </div>
	                                             </div>
	                                             <!-- portlet-title -->
	                                             <div class="headRightDetailsInner">
	                                                <table>
	                                                   <tbody>
	                                                      <tr id="">
	                                                         <td class="" style="padding-right:10px;">
	                                                            <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
	                                                         </td>
	                                                         <td class="staffView_StaffName">
	                                                            <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
	                                                         </td>
	                                                      </tr>
	                                                   </tbody>
	                                                </table>
	                                                <!-- col-md-4 -->
	                                             </div>
	                                             <!-- headRightDetailsInner -->
	                                             <div class="portlet-body fixedHeightmodalPortlet">
	                                                <div class="form-body">
	                                                   <div class="row">
	                                                      <div class="col-md-12 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Attendance Date:</label>
	                                                            <div class="">
	                                                               <input type="date" class="form-control"  id="manual_attendance">
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                   <div class="row">
	                                                      <div class="col-md-6 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Tap :</label>
	                                                            <div class="">
	                                                               <input type="time" class="form-control" name="" id="manual_missTap" data-id="">
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                            
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                   <div class="row">
	                                                      <div class="col-md-12 paddingBottom10">
	                                                         <div class="form-group">
	                                                            <label class="">Information regarding missed tap event:</label>
	                                                            <div class="">
	                                                               <textarea id="manual_description" cols="85" rows="5"></textarea>
	                                                            </div>
	                                                         </div>
	                                                         <!-- form-group -->
	                                                      </div>
	                                                      <!-- col-md-6 -->
	                                                   </div>
	                                                   <!-- row -->
	                                                </div>
	                                                <!-- form-body -->
	                                             </div>
	                                             <!-- portlet-body fixedHeightmodalPortlet-->
	                                          </div>
	                                       </div>
	                                       <div class="modal-footer text-center" style="text-align:center;">
	                                          <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
	                                          <button type="button" class="btn dark btn-outline active" data-dismiss="" onClick="insert_manual()">Submit</button>
	                                          <!--button type="button" class="btn green">Add Badge</button -->
	                                       </div>
	                                    </div>
	                                    <!-- /.modal-content -->
	                                 </div>
	                                 <!-- /.modal-dialog -->
	                              </div>
	                              <div class="modal fade" id="ManualAttendanceFormEdit" tabindex="-1" role="basic" aria-hidden="true">
	                                 <div class="modal-dialog">
	                                   <div class="modal-content">
	                                       <div class="modal-body" style="float:left;width:100%;">
	                                          <div class="portlet box blue-hoki">
	                                             <div class="portlet-title">
	                                                <div class="caption">
	                                                   <i class="fa fa-user"></i><font id="">Manual</font>
	                                                </div>
	                                             </div>
	                                             <!-- portlet-title -->
	                                             <div class="headRightDetailsInner">
	                                                <table>
	                                                   <tbody>
	                                                      <tr id="">
	                                                         <td class="" style="padding-right:10px;">
	                                                            <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
	                                                         </td>
	                                                         <td class="staffView_StaffName">
	                                                            <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
	                                                         </td>
	                                                      </tr>
	                                                   </tbody>
	                                                </table>
	                                                <!-- col-md-4 -->
	                                             </div>
	                                             <!-- headRightDetailsInner -->
	                                             <div class="portlet-body fixedHeightmodalPortlet">
	                                                <div class="form-body" id="Manual_Form_Entry">
	                                                </div>
	                                                <!-- form-body -->
	                                             </div>
	                                             <!-- portlet-body fixedHeightmodalPortlet-->
	                                          </div>
	                                       </div>
	                                       <div class="modal-footer text-center" style="text-align:center;">
	                                          <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
	                                          <button type="button" class="btn dark btn-outline active" data-dismiss="" onClick="edit_manual()"> Update </button>
	                                          <!--button type="button" class="btn green">Add Badge</button -->
	                                       </div>
	                                    </div>
	                                    <!-- /.modal-content -->
	                                 </div>
	                                 <!-- /.modal-dialog -->
	                              </div> <!-- End ManualAttendanceFormEdit modal -->
	                     
	                            </div>
	                           <!-- portlet -->
	                        </div>
	                        <!-- tab_1_3_6 -->
	                     </div>
	                     <!-- tab-content -->
	                  </div>
	                  <!-- tabbable-line -->
	               </div>
	               <!-- tab_1_3 -->
	               <div class="tab-pane fade" id="tab_1_4">
	                  <div class="portlet box light">
	                     <div class="portlet-body padding0">
	                        <div class="panel-group accordion" id="accordion3">
	                           <div class="panel panel-default">
	                              <div class="panel-heading">
	                                 <h4 class="panel-title">
	                                    <a class="accordion-toggle accordion-toggle-styled" data-toggle="collapse" data-parent="#accordion3" href="#collapse_3_1"> Admission </a>
	                                 </h4>
	                              </div>
	                              <div id="collapse_3_1" class="panel-collapse in">
	                                 <div class="panel-body">
	                                    <table width="100%" border="0" class="table bordered accessTable">
	                                       <thead>
	                                          <tr>
	                                             <th></th>
	                                             <th width="10%" class="text-center">Create</th>
	                                             <th width="10%" class="text-center">Read</th>
	                                             <th width="10%" class="text-center">Update</th>
	                                          </tr>
	                                       </thead>
	                                       <tr>
	                                          <td>Issuance Form</td>
	                                          <td class="text-center"><i class="icon-plus font-green-jungle fontSize20"></i></td>
	                                          <td class="text-center"><i class="icon-eye font-green-jungle fontSize20"></i></td>
	                                          <td class="text-center"><i class="icon-reload font-green-jungle fontSize20"></i></td>
	                                       </tr>
	                                       <tr>
	                                          <td>Submission Form</td>
	                                          <td class="text-center"><i class="icon-plus font-green-jungle fontSize20"></i></td>
	                                          <td class="text-center"><i class="icon-eye font-green-jungle fontSize20"></i></td>
	                                          <td class="text-center"><i class="icon-reload font-green-jungle fontSize20"></i></td>
	                                       </tr>
	                                       <tr>
	                                          <td>Followup Form</td>
	                                          <td class="text-center"><i class="icon-plus font-green-jungle fontSize20"></i></td>
	                                          <td class="text-center"><i class="icon-eye font-green-jungle fontSize20"></i></td>
	                                          <td class="text-center"><i class="icon-reload font-red-thunderbird fontSize20"></i></td>
	                                       </tr>
	                                       <tr>
	                                          <td>AnD Process Form</td>
	                                          <td class="text-center"><i class="icon-plus font-green-jungle fontSize20"></i></td>
	                                          <td class="text-center"><i class="icon-eye font-red-thunderbird fontSize20"></i></td>
	                                          <td class="text-center"><i class="icon-reload font-red-thunderbird fontSize20"></i></td>
	                                       </tr>
	                                       <tr>
	                                          <td>Admin Authority Form</td>
	                                          <td class="text-center"><i class="icon-plus font-red-thunderbird fontSize20"></i></td>
	                                          <td class="text-center"><i class="icon-eye font-red-thunderbird fontSize20"></i></td>
	                                          <td class="text-center"><i class="icon-reload font-red-thunderbird fontSize20"></i></td>
	                                       </tr>
	                                    </table>
	                                 </div>
	                              </div>
	                           </div>
	                           <div class="panel panel-default">
	                              <div class="panel-heading">
	                                 <h4 class="panel-title">
	                                    <a class="accordion-toggle accordion-toggle-styled collapsed" data-toggle="collapse" data-parent="#accordion3" href="#collapse_3_2"> HR </a>
	                                 </h4>
	                              </div>
	                              <div id="collapse_3_2" class="panel-collapse collapse">
	                                 <div class="panel-body" style="height:200px; overflow-y:auto;">
	                                    <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
	                                    <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
	                                       eiusmod. 
	                                    </p>
	                                    <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
	                                    <p>
	                                       <a class="btn blue" href="ui_tabs_accordions_navs.html#collapse_3_2" target="_blank"> Activate this section via URL </a>
	                                    </p>
	                                 </div>
	                              </div>
	                           </div>
	                           <div class="panel panel-default">
	                              <div class="panel-heading">
	                                 <h4 class="panel-title">
	                                    <a class="accordion-toggle accordion-toggle-styled collapsed" data-toggle="collapse" data-parent="#accordion3" href="#collapse_3_3"> Finance </a>
	                                 </h4>
	                              </div>
	                              <div id="collapse_3_3" class="panel-collapse collapse">
	                                 <div class="panel-body">
	                                    <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
	                                       eiusmod. Brunch 3 wolf moon tempor. 
	                                    </p>
	                                    <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
	                                    <p>
	                                       <a class="btn green" href="ui_tabs_accordions_navs.html#collapse_3_3" target="_blank"> Activate this section via URL </a>
	                                    </p>
	                                 </div>
	                              </div>
	                           </div>
	                           <div class="panel panel-default">
	                              <div class="panel-heading">
	                                 <h4 class="panel-title">
	                                    <a class="accordion-toggle accordion-toggle-styled collapsed" data-toggle="collapse" data-parent="#accordion3" href="#collapse_3_4"> SIS </a>
	                                 </h4>
	                              </div>
	                              <div id="collapse_3_4" class="panel-collapse collapse">
	                                 <div class="panel-body">
	                                    <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
	                                    <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
	                                       eiusmod. Brunch 3 wolf moon tempor. 
	                                    </p>
	                                    <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
	                                    <p>
	                                       <a class="btn red" href="ui_tabs_accordions_navs.html#collapse_3_4" target="_blank"> Activate this section via URL </a>
	                                    </p>
	                                 </div>
	                              </div>
	                           </div>
	                        </div>
	                     </div>
	                  </div>
	               </div>
	               <!-- tab_1_4 -->
	               <div class="tab-pane fade active in" id="tab_1_5">
	                  <div class="portlet box light">
	                     <div class="portlet-body padding0">
	                        <div class="chat-form">
	                           <div class="pull-left commentBox width100">
	                              <input type="text" class="form-control borderRight0 width78" placeholder="Type a comment here..." id="commentText" />
	                              <div class="rightpullAbsolutes">
	                                 <div class="pull-right commentType" id="">
	                                    <button type="button" class="btn-default btn dropdown-toggle borderRight0 show_show" data-toggle="dropdown" tabindex="-1" aria-expanded="false" id="show" onClick="show_dropdown()">
	                                    Category &nbsp;<i class="fa fa-angle-down"></i>
	                                    </button>

	                                    <div class="dropdown-menuu pull-right" role="menu" style="display:none;">
	                                       <h4 class="bbottom">Comment Category</h4>

	                                       @foreach($staffCategory as $category)
	                                       <label class="mt-checkbox">
	                                       <input type="checkbox"  data-name="{{$category->name}}" value="{{$category->id}}" class="CheckBox_Category" /> {{$category->name}}
	                                       <span></span>
	                                       </label><br />
	                                       @endforeach

	                                    </div>
	                                 </div>
	                                 <!-- commnetType -->
	                                 <div class="pull-left commentButton">
	                                    <button type="button"  class="btn uppercase green-jungle borderRight0" id="" tabindex="-1" onClick="insertComment()">Comment</button>
	                                 </div>
	                                 <!-- commentButton -->
	                                 <div class="theme-panel hidden-xs hidden-sm">
	                                    <div class="toggler4"> </div>
	                                    <div class="toggler4-close"> </div>
	                                    <div class="theme-options4">
	                                       <div class="theme-option">
	                                          <span> Source </span>
	                                          <select id="filter_user" class="layout-option form-control input-sm">
	                                             <option value="" disabled selected>Select source</option>
	                                             <option value="user">User</option>
	                                             <option value="system">System</option>
	                                          </select>
	                                       </div>
	                                       <div class="theme-option">
	                                          <span style="padding-bottom:10px;"> Category</span>
	                                          <span style="width:100%;">
	                                          <label class="mt-checkbox">
	                                          <input type="checkbox" name="Search_Cat[]" value="Accounts" /> Finance
	                                          <span></span>
	                                          </label>
	                                          <label class="mt-checkbox">
	                                          <input type="checkbox" name="Search_Cat[]" value="Academic" /> Academic
	                                          <span></span>
	                                          </label>
	                                          <label class="mt-checkbox">
	                                          <input type="checkbox" name="Search_Cat[]" value="Etab" /> E-TAB
	                                          <span></span>
	                                          </label>
	                                          <label class="mt-checkbox">
	                                          <input type="checkbox" name="Search_Cat[]" value="SIS" /> SIS
	                                          <span></span>
	                                          </label>
	                                          <label class="mt-checkbox">
	                                          <input type="checkbox" name="Search_Cat[]" value="Family" /> Family
	                                          <span></span>
	                                          </label>
	                                          <label class="mt-checkbox">
	                                          <input type="checkbox" name="Search_Cat[]" value="SMS" /> SMS
	                                          <span></span>
	                                          </label>
	                                          </span>
	                                       </div>
	                                       <div class="theme-option">
	                                          <div class="input-group date-picker input-daterange" data-date="10/11/2012" data-date-format="mm/dd/yyyy">
	                                             <input type="date" class="form-control" name="from" id="from_date" min="" />
	                                             <span class="input-group-addon"> to </span>
	                                             <input type="date" class="form-control" name="to" id="to_date" /> 
	                                          </div>
	                                          <!-- /input-group -->
	                                          <span class="help-block"> Select date range </span>
	                                       </div>
	                                       <div class="theme-option text-center" id="">
	                                          <a href="javascript:;" class="btn uppercase green-jungle applySearch">Apply Filter</a>
	                                          <a href="javascript:;" class="btn uppercase grey-salsa clearSearch" onClick="clearSearch()">Clear Filter</a>
	                                       </div>
	                                    </div>
	                                    <!-- theme-options -->
	                                 </div>
	                              </div>
	                              <!-- rightpullAbsolute -->
	                           </div>
	                           <!-- commentBox -->
	                        </div>
	                        <!-- chat-form -->
	                        <div class="col-md-12" style="" data-always-visible="1" data-rail-visible1="1" id="">
	                           <ul class="chats" id="stories">
	                           </ul>
	                           <!-- chats -->
	                        </div>
	                        <!-- col-md-12  -->
	                     </div>
	                     <!-- portlet-body-->
	                  </div>
	                  <!-- portlet -->
	               </div>
	               <!-- tab_1_5 -->
	<style>
	.padRight1 {
	padding-right:1%; 
	text-align:right;
	width:49%;
	}
	.padLeft1 {
	padding-left:1%;
	width:49%;  
	}
	.currentStaff tbody {
	background:#f5eba3;  
	}
	.innerTbodyStaff {
	text-align: left;
	padding: 4px;
	float: left;
	width: 100%;
	border: 1px solid #e0dfdf;
	height: 55px;
	background: #efefef;
	}
	.innerTbodyStaff .user-pic {
	height: 43px !important;
	}
	.rolesTable tr.pBottom10 {
	width: 100%;
	height: 60px;
	}
	.rolesTable td.staffView_StaffName {
	padding-left: 6px;
	width:100%;
	}
	.innerTbodyStaff .row td {
	float:left; 
	}
	.innerTbodyStaff .row tdLlast-child {
	float:right;
	width:15%;

	}
	.leftInformationRoleStaff {
	float:left;
	}
	.rightInformationRoleStaff {
	float: right;
	padding: 12px 10px;
	font-weight: bold;
	color: #717171;
	font-size: 14px;
	border: 1px solid #c3c3c3;
	background: #d0d0d0;
	}
	</style>                     
	               <div class="tab-pane fade" id="tab_1_6">
	                  <div id="content_role_position_distance"> 
					
	                     <div class="portlet-body padding0">
	                        <table width="100%" class="rolesTable">
	                           <tr class="pBottom10">
	                                 <td class="padRight1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padRight1 -->
	                                  <td class="padLeft1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="VP/HM" data-department="Principal, Generation's School" style="display: table-row;">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="90-001" src="assets/photos/hcm/150x150/staff/973.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <span class="leftInformationRoleStaff">
	                                                          <a class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="DGS" data-staffid="19" data-staffgtid="90-001" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Ghazala Siddiqui</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="g.siddiqui">DGS</small><br>
	                                                          <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">20 B</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Principal, Generation's School">Generation's School: Principal</span></small>
	                                                      </span><!-- leftInformation -->
	                                                      <span class="rightInformationRoleStaff">
	                                                          <span class="rolesRelations">
	                                                              20 B
	                                                          </span>  
	                                                      </span><!-- rightInformationRoleStaff -->                                                             
	                                                   </td>
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padLeft1 -->
	                              </tr>
	                              <!-- -->
	                              <tr class="pBottom10">
	                                 <td width="50%" class="padRight1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="VP/HM" data-department="Principal, Generation's School" style="display: table-row;">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="90-001" src="assets/photos/hcm/150x150/staff/973.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <span class="leftInformationRoleStaff">
	                                                          <a class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="DGS" data-staffid="19" data-staffgtid="90-001" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Ghazala Siddiqui</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="g.siddiqui">DGS</small><br>
	                                                          <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">20 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Principal, Generation's School">Generation's School: Principal</span></small>
	                                                      </span><!-- leftInformation -->
	                                                      <span class="rightInformationRoleStaff">
	                                                          <span class="rolesRelations">
	                                                              20 A
	                                                          </span>  
	                                                      </span><!-- rightInformationRoleStaff --> 
	                                                   </td>
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padRight1 -->
	                                  <td width="50%" class="padLeft1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="VP/HM" data-department="Director, Generation's School" style="display: table-row;">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="90-003" src="assets/photos/hcm/150x150/staff/299.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <span class="leftInformationRoleStaff">
	                                                          <a class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="SSD" data-staffid="15" data-staffgtid="90-003" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Shoaib Siddiqui</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="s.siddiqui">SSD</small><br>
	                                                          <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">20 B</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Director, Generation's School">Generation's School: Director</span></small>
	                                                      </span><!-- leftInformation -->
	                                                      <span class="rightInformationRoleStaff">
	                                                          <span class="rolesRelations">
	                                                              20 B
	                                                          </span>  
	                                                      </span><!-- rightInformationRoleStaff -->
	                                                   </td>
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padLeft1 -->
	                              </tr>
	                              <!-- -->
	                              <tr class="pBottom10">
	                                 <td width="50%" class="padRight1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="VP/HM" data-department="Director, Generation's School" style="display: table-row;">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="90-003" src="assets/photos/hcm/150x150/staff/299.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <span class="leftInformationRoleStaff">
	                                                          <a class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="SSD" data-staffid="15" data-staffgtid="90-003" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Shoaib Siddiqui</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="s.siddiqui">SSD</small><br>
	                                                          <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Director, Generation's School">Generation's School: Director</span></small>
	                                                      </span><!-- leftInformation -->
	                                                      <span class="rightInformationRoleStaff">
	                                                          <span class="rolesRelations">
	                                                              10 A
	                                                          </span>  
	                                                      </span><!-- rightInformationRoleStaff -->
	                                                   </td>
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padRight1 -->
	                                  <td width="50%" class="padLeft1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="" data-department="Senior General Manager, Generation's School">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="15-067" src="assets/photos/hcm/150x150/staff/1010.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <span class="leftInformationRoleStaff">
	                                                          <a class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="KSM" data-staffid="606" data-staffgtid="15-067" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Kashif Shamim</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="k.shamim">KSM</small><br>
	                                                          <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 B</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Senior General Manager, Generation's School">Generation's School: Senior General Manager</span></small>
	                                                      </span><!-- leftInformation -->
	                                                      <span class="rightInformationRoleStaff">
	                                                          <span class="rolesRelations">
	                                                              10 B
	                                                          </span>  
	                                                      </span><!-- rightInformationRoleStaff -->
	                                                   </td>
	                                               
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padLeft1 -->
	                              </tr>
	                              <!-- -->
	                              <tr class="pBottom10 currentStaff">
	                                 <td width="50%" class="padRight1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row " data-attendance="Absent" data-campus="South" data-profile="Software Team" data-department="Head, Digital Systems, Digital Infrastructures">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="15-076" src="assets/photos/hcm/150x150/staff/1014.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <a href="" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="MHF" data-staffid="615" data-staffgtid="15-076" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Muhammad Faisal</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="m.faisal2">MHF</small><br>
	                                                      <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">R</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Head, Digital Systems, Digital Infrastructures">Digital Infrastructures: Head, Digital Systems</span></small>
	                                                   </td>
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padRight1 -->
	                                  <td width="50%" class="padLeft1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row " data-attendance="Absent" data-campus="South" data-profile="Software Team" data-department="Head, Digital Systems, Digital Infrastructures">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="15-076" src="assets/photos/hcm/150x150/staff/1014.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <a href="" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="MHF" data-staffid="615" data-staffgtid="15-076" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Muhammad Faisal</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="m.faisal2">MHF</small><br>
	                                                      <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">R</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Head, Digital Systems, Digital Infrastructures">Digital Infrastructures: Head, Digital Systems</span></small>
	                                                   </td>
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padLeft1 -->
	                              </tr>
	                              <!-- -->
	                              <tr class="pBottom10">
	                                 <td width="50%" class="padRight1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="Software test Profile" data-department="Software, Team Lead, Software">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="09-008" src="assets/photos/hcm/150x150/staff/298.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <span class="leftInformationRoleStaff">
	                                                          <a href="" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="ANA" data-staffid="1" data-staffgtid="09-008" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Atif Naseem Ahmed</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="a.naseem">ANA</small><br>
	                                                          <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Software, Team Lead, Software">Software: Software, Team Lead</span></small>
	                                                      </span>
	                                                      <span class="rightInformationRoleStaff">
	                                                         <span class="rolesRelations">
	                                                              10 A
	                                                          </span>   
	                                                      </span><!-- rightInformationRoleStaff -->
	                                                   </td>
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padRight1 -->
	                                  <td width="50%" class="padLeft1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="DI" data-department="IT Incharge, Digital Infrastructures">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="12-043" src="assets/photos/hcm/150x150/staff/714.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <span class="leftInformationRoleStaff">
	                                                          <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="SAA" data-staffid="287" data-staffgtid="12-043" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Syed Asder Ahmed</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="s.a.ahmed">SAA</small><br>
	                                                          <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="IT Incharge, Digital Infrastructures">Digital Infrastructures: IT Incharge</span></small>
	                                                      </span>
	                                                      <span class="rightInformationRoleStaff">
	                                                         <span class="rolesRelations">
	                                                              10 A
	                                                          </span>   
	                                                      </span><!-- rightInformationRoleStaff -->
	                                                   </td>
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padLeft1 -->
	                              </tr>
	                              <!-- -->
	                              <tr class="pBottom10">
	                                 <td width="50%" class="padRight1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="Software test Profile" data-department="Software Developer, Software" style="display: table-row;">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="16-009" src="assets/photos/hcm/150x150/staff/1103.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <span class="leftInformationRoleStaff">
	                                                          <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="KMS" data-staffid="774" data-staffgtid="16-009" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Kashif Mustafa</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="k.mustafa">KMS</small><br>
	                                                          <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Software Developer, Software">Software: Software Developer</span></small>
	                                                      </span><!-- leftInformation -->
	                                                      <span class="rightInformationRoleStaff">
	                                                          <span class="rolesRelations">
	                                                              10 A
	                                                          </span>  
	                                                      </span><!-- rightInformationRoleStaff -->
	                                                   </td>
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padRight1 -->
	                                  <td width="50%" class="padLeft1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="" data-department="CCTV Technician, Digital Infrastructures">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="15-195" src="assets/photos/hcm/150x150/staff/1076.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <span class="leftInformationRoleStaff">
	                                                          <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="MAV" data-staffid="737" data-staffgtid="15-195" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Amin Vohra</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="a.vohra">MAV</small><br>
	                                                          <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">13 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="CCTV Technician, Digital Infrastructures">Digital Infrastructures: CCTV Technician</span></small>
	                                                      </span><!-- leftInformation -->
	                                                      <span class="rightInformationRoleStaff">
	                                                          <span class="rolesRelations">
	                                                              13 A
	                                                          </span>  
	                                                      </span><!-- rightInformationRoleStaff -->     
	                                                   </td>
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padLeft1 -->
	                              </tr>
	                              <!-- -->
	                              <tr class="pBottom10">
	                                 <td width="50%" class="padRight1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="Digital Infrastructure" data-department="Software Developer, Software" style="display: table-row;">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="16-070" src="assets/photos/hcm/150x150/staff/1159.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <span class="leftInformationRoleStaff">
	                                                          <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="HOL" data-staffid="835" data-staffgtid="16-070" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Muhammad Haris Ola</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="h.ola">HOL</small><br>
	                                                          <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Software Developer, Software">Software: Software Developer</span></small>
	                                                      </span><!-- leftInformation -->
	                                                      <span class="rightInformationRoleStaff">
	                                                          <span class="rolesRelations">
	                                                              10 A
	                                                          </span>  
	                                                      </span><!-- rightInformationRoleStaff -->  
	                                                   </td>
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padRight1 -->
	                                  <td width="50%" class="padLeft1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="Digital Infrastructure" data-department="IT Administrator, Digital Infrastructures">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="13-025" src="assets/photos/hcm/150x150/staff/818.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <span class="leftInformationRoleStaff">
	                                                          <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="RHA" data-staffid="350" data-staffgtid="13-025" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">M Rehan Akhtar</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="r.akhtar">RHA</small><br>
	                                                          <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">13 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="IT Administrator, Digital Infrastructures">Digital Infrastructures: IT Administrator</span></small>
	                                                      </span><!-- leftInformation -->
	                                                      <span class="rightInformationRoleStaff">
	                                                          <span class="rolesRelations">
	                                                              13 A
	                                                          </span>  
	                                                      </span><!-- rightInformationRoleStaff --> 
	                                                   </td>
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padLeft1 -->
	                              </tr>
	                              <!-- -->
	                              <tr class="pBottom10">
	                                 <td width="50%" class="padRight1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="Lead Teachers SC" data-department="Software Developer, Software" style="display: table-row;">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="16-008" src="assets/photos/hcm/150x150/staff/1104.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <span class="leftInformationRoleStaff">
	                                                          <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="ROA" data-staffid="773" data-staffgtid="16-008" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Rohail Aslam</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="r.aslam">ROA</small><br>
	                                                          <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Software Developer, Software">Software: Software Developer</span></small>
	                                                      </span><!-- leftInformation -->
	                                                      <span class="rightInformationRoleStaff">
	                                                          <span class="rolesRelations">
	                                                              10 A
	                                                          </span>  
	                                                      </span><!-- rightInformationRoleStaff -->  
	                                                   </td>
	                                               
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padRight1 -->
	                                  <td width="50%" class="padLeft1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="Digital Infrastructure" data-department="IT Administrator, Digital Infrastructures" style="display: table-row;">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="16-010" src="assets/photos/hcm/150x150/staff/1105.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <span class="leftInformationRoleStaff">
	                                                          <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="NAB" data-staffid="775" data-staffgtid="16-010" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Mirza Numair</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="m.numair">NAB</small><br>
	                                                          <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">13 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="IT Administrator, Digital Infrastructures">Digital Infrastructures: IT Administrator</span></small>
	                                                      </span><!-- leftInformation -->
	                                                      <span class="rightInformationRoleStaff">
	                                                          <span class="rolesRelations">
	                                                              13 A
	                                                          </span>  
	                                                      </span><!-- rightInformationRoleStaff -->  
	                                                   </td>
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padLeft1 -->
	                              </tr>
	                              <!-- -->
	                              <tr class="pBottom10">
	                                 <td width="50%" class="padRight1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="Software Team" data-department="SIS Officer, Coordination">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="13-035" src="assets/photos/hcm/150x150/staff/878.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <span class="leftInformationRoleStaff">
	                                                          <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="MSQ" data-staffid="2" data-staffgtid="13-035" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Muhammad Saqib</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="m.saqib">MSQ</small><br>
	                                                         <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 C</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="SIS Officer, Coordination">Coordination: SIS Officer</span></small>
	                                                     </span><!-- leftInformation -->
	                                                      <span class="rightInformationRoleStaff">
	                                                          <span class="rolesRelations">
	                                                              10 C
	                                                          </span>  
	                                                      </span><!-- rightInformationRoleStaff -->   
	                                                   </td>
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padRight1 -->
	                                  <td width="50%" class="padLeft1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row" data-attendance="Absent" data-campus="North" data-profile="" data-department="IT Administrator, Digital Infrastructures" style="display: table-row;">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="12-034" src="assets/photos/hcm/150x150/staff/718.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <span class="leftInformationRoleStaff">
	                                                          <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="KAM" data-staffid="278" data-staffgtid="12-034" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Khurram Majeed</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="k.a.majeed">KAM</small><br>
	                                                          <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">13 C</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="IT Administrator, Digital Infrastructures">Digital Infrastructures: IT Administrator</span></small>
	                                                      </span><!-- leftInformation -->
	                                                      <span class="rightInformationRoleStaff">
	                                                          <span class="rolesRelations">
	                                                              13 C
	                                                          </span>  
	                                                      </span><!-- rightInformationRoleStaff -->  
	                                                   </td>
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padLeft1 -->
	                              </tr>
	                              <!-- -->
	                              <tr class="pBottom10">
	                                 <td width="50%" class="padRight1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="Software test Profile" data-department="Software Developer, Software" style="display: table-row;">
	                                                   <td class="">
	                                                      <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="17-066" src="assets/photos/hcm/150x150/staff/male.png">
	                                                   </td>
	                                                   <td class="staffView_StaffName">
	                                                      <span class="leftInformationRoleStaff">
	                                                          <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="ABL" data-staffid="933" data-staffgtid="17-066" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Asim Bilal</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="a.bilal2">ABL</small><br>
	                                                          <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-TPB: Probation">T</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Software Developer, Software">Software: Software Developer</span></small>
	                                                      </span><!-- leftInformation -->
	                                                      <span class="rightInformationRoleStaff">
	                                                          <span class="rolesRelations">
	                                                              10 A
	                                                          </span>  
	                                                      </span><!-- rightInformationRoleStaff -->  
	                                                   </td>
	                                             </tr>
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padRight1 -->
	                                  <td width="50%" class="padLeft1">
	                                    <table width="100%">
	                                       <tbody class="innerTbodyStaff">
	                                              
	                                          </tbody><!-- tbody .innerTbodyStaff -->
	                                      </table><!-- table -->
	                                  </td><!-- padLeft1 -->
	                              </tr>
	                              
	                              <!-- -->
	                          </table>
	                     </div>
	                     <!-- portlet-body-->
	                  </div>
	                  <!-- portlet -->
	               </div>
	               <!-- tab_1_6 -->
	            </div>
	            <!-- tab-content -->
	         </div>
	         <!-- portlet-body -->
	      </div>
	      <!-- portlet -->
	   </div>
	   <!-- col-md-12 v-->
	</div>
	<!-- row -->
</div>
<!-- col-md-8 -->













<script type="text/javascript">
 $(document).ready(function(){
 	
 });
</script>