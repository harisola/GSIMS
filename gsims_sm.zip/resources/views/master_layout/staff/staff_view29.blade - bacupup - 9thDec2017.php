<!--BEGIN PAGE LEVEL STYLES -->
<style>
   /***** BEGIN - Search Result Highlight CSS *****/
/*div#datepaginator1 {
    width: 100% !important;
    display: block !important;
    float: left;
}*/
.red-bar{
      border:1px solid red !important;
      z-index: 0 !important;
      height: 26px !important;
      top: -10px !important;
   }
#tapSlider .green-color {
   background: #89c589 !important;
}
   .red-bar .noUi-tooltip {
    top: 34px !important;
    height: 19px !important;
   }
   .grey-color{
      background: none !important;
   }
   span.match{
   background-color:#f8dda9;
   border:1px solid #edd19b;
   margin:-1px;
   color:#390705;
   }
   .form-actions {
   text-align: center;
   padding: 25px 0 0 0;
   border-top: 1px solid #ccc;
   margin-top: 30px;
   }
   .portlet.light>.portlet-title {
   padding: 10px 20px 0;
   min-height: 48px;
   }
   .table > tbody > tr > td {
   vertical-align: middle;
   }
   .paddingLeft0 {
   padding-left:0 !important;  
   }
   /***** END - Search Result Highlight CSS *****/
   .mt-checkbox, .mt-radio {
   margin-bottom: 8px !important;
   }
   .theme-option .mt-checkbox {
   margin-right: 20px;
   }
   h4.bbottom {
   padding-bottom: 7px;
   border-bottom:1px solid #ccc;  
   }
   .dropdown-menuu {
   background: #fafafa;
   position: absolute;
   width: 270px;
   border: 1px solid #999;
   right: 0px;
   top: 33px;
   z-index: 999999;
   height: 220px;
   padding: 5px 16px;
   box-shadow: 1px 1px 4px #000;
   overflow-y: scroll;
   }
   .theme-panel>.theme-options4>.theme-option>select.form-control {
   width: 231px !important;
   }
   .theme-panel>.toggler4, .theme-panel>.toggler4-close {
   padding: 17px !important;
   -webkit-border-radius: 4px;
   -moz-border-radius: 4px;
   -ms-border-radius: 4px;
   -o-border-radius: 4px;
   top: 37px !important;
   cursor: pointer;
   }
   .theme-panel>.theme-options4 {
   top: 69px !important;
   }
   .commentType {
   right: 164px;
   position: absolute;
   }
   .inputs {
   position:relative;  
   }
   .pull-left.commentButton {
   position: absolute;
   right: 0px;
   width: 164px;
   }
   .border0 {
   border: 0 none; 
   }
   .rightpullAbsolutes {
   float: right;
   margin-top: -34px;  
   }
   .width100 {
   width:100%; 
   }
   .width78 {
   width: 93%;
   padding-right: 185px;   
   }
   .portlet-body .nav-tabs>li>a {
   padding: 10px 12px !important;
   }
   .dropdown-menu-right, .dropdown-menu.pull-right {
   left: auto;
   right: 0px;
   top: 24px;
   }
   .chat-form {
   margin-top: 15px;
   padding: 10px;
   background-color: #e9eff3;
   overflow: visible;
   clear: both;
   float: left;
   width: 100%;
   margin-bottom: 20px;
   }
   .md-radio {
   position: relative;
   margin: 11px 9px;
   }
   .md-radio label>span.inc {
   display:none;   
   }
   .theme-panel>.toggler4, .theme-panel>.toggler4-close {
   padding: 16px !important;
   -webkit-border-radius: 4px;
   -moz-border-radius: 4px;
   -ms-border-radius: 4px;
   -o-border-radius: 4px;
   top: 4px;
   cursor: pointer;
   }
   .theme-panel>.toggler4, .theme-panel>.toggler4-close {
   padding: 16px !important;
   -webkit-border-radius: 4px;
   -moz-border-radius: 4px;
   -ms-border-radius: 4px;
   -o-border-radius: 4px;
   top: 4px;
   cursor: pointer;
   }
   .theme-panel>.toggler4 {
   right: 0;
   position: absolute;
   background: url(./img/icon-color-filter.png) center no-repeat #536881 !important;
   border-radius: 4px;
   }
/*   ul.pagination {
   width:101%; 
   }*/
   .irs-disabled {
   opacity:1 !important;
   }
   .approvedBorder {
   border-left:3px solid green; 
   }
   .NoapprovedBorder {
   border-left:3px solid red;
   }
   .PendingapprovedBorder {
   border-left: 3px solid #BFCAD1;  
   }
   .bootstrap-switch-on > #approvedformShow {
   display: block !important;   
   }
   .headRightDetailsInner {
   background: #dedede;
   width: 100%;
   padding: 5px 15px;
   border-bottom: 1px solid #eef1f5;
   z-index: 999;
   margin-top: 0px;
   }
   .modal-body .portlet-body {
   padding-top:15px !important;
   }
   .irs-shadow {
   height: 12px !important;
   top: 25px !important;
   background: #27af64 !important;
   opacity: 1 !important;
   }
   .abridgedPersonalName,
   .abridgedPrimaryName {
   float: right;
   width: 57%;
   margin-top: -7px;
   }
   .noUi-handle .noUi-tooltip {
   left: -10px !important;
   }
/*   .noUi-connect.c-1-color {
   background: green;
   }
   .noUi-connect.c-3-color {
   background: green;
   }
   .noUi-connect.c-2-color {
   background: red;
   }*/

   .red-bar{
      border:1px solid red !important;
      z-index: 2 !important;
   }
   .grey-color{
      background: none !important;
   }
   .select2-container--bootstrap .select2-selection--multiple .select2-selection__choice {
      font-family: 'Conv_calibri';
   }

   #bufferTime .noUi-handle {
    border: 0 none;
    background: none;
}

   .red-color{
      background: red !important;
   }
.opardiv {
    background: #ff000003;
    width: 97%;
    height: 400px;
    position: absolute;
    z-index: 9;
}
</style>
<link href="{{ URL::to('/metronic/global/plugins/ion.rangeslider/css/ion.rangeSlider.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::to('/metronic/global/plugins/ion.rangeslider/css/ion.rangeSlider.skinFlat.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::to('/metronic/global/plugins/bootstrap-markdown/css/bootstrap-markdown.min.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::to('/metronic/global/plugins/bootstrap-summernote/summernote.css') }}" rel="stylesheet" type="text/css" />
<!-- -->
<link href="{{ URL::to('/css/staffLayout.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::to('/metronic/global/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::to('/metronic/global/plugins/bootstrap-datepaginator/bootstrap-datepaginator.min.css') }}" rel="stylesheet" type="text/css" />
<!-- -->
<link href="{{ URL::to('/metronic/global/plugins/time-range/css/flatpickr.min.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::to('/metronic/global/plugins/time-range/css/nouislider.min.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::to('/metronic/global/plugins/select2/css/select2.min.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::to('/metronic/global/plugins/select2/css/select2-bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
<!-- END PAGE LEVEL STYLES -->
<script>
   $("#change-color-switch").bootstrapSwitch();
   
   $(document).ready(function(){
       


         
   $('#change-color-switch').on('switchChange.bootstrapSwitch', function (e, data) {
     var state=$(this).bootstrapSwitch('state');//returns true or false
      if(state)
        {
           $("#approvedformShow").show();
        }
      else
        {
           $("#approvedformShow").hide();
           $('#approve_from').val('');
           $('#approve_to').val('');
           $('#paid_compensation_percentage').val('');
        }
    });
   });
   
   $("#changeSwitch").bootstrapSwitch();

   
   $(document).ready(function(){
       
         
   $('#changeSwitch').on('switchChange.bootstrapSwitch', function (e, data) {
     var state=$(this).bootstrapSwitch('state');//returns true or false
      if(state)
        {
           $("#paidField").show();
        }
      else
        {
           $("#paidField").hide();
        }
    });



   });
   
</script>
<!-- BEGIN PAGE BAR -->
<div class="page-bar">
   <ul class="page-breadcrumb">
      <li>
         <a href="index.html">Home</a>
         <i class="fa fa-circle"></i>
      </li>
      <li>
         <span>Staff List</span>
      </li>
   </ul>
   <!-- page-breadcrumb -->
</div>

<!-- BEGIN USE PROFILE -->
<div class="row marginTop20">
   <div class="col-md-4 borderRightDashed">
      <!-- BEGIN EXAMPLE TABLE PORTLET-->
      <div class="portlet light bordered fixed-height-NoScroll marginBottom0">
         <h3 class="headTitle">Staff List</h3>
         <div class="portlet-title padding0">
            <div class="caption caption-md">
               <h3 id="staffView_StaffList_Total" class="marginTop0 marginBottom0 padding0">Staff List</h3>
            </div>
            <div class="actions">
                <div class="btn-group btn-group-devided" data-toggle="buttons">
                        <!-- <input type="radio" name="options" class="toggle" id="profileDefinationAdd">Add New Profile</label> -->
                        <button class="tooltips btn btn-transparent dark btn-outline btn-circle btn-sm" data-placement="bottom" data-original-title="Add new profile"data-toggle="modal" href="#ProcessEntry" id="">Entry Forms</button>
                </div>
                <div class="modal fade 100pxwidth" id="ProcessEntry" tabindex="-1" role="basic" aria-hidden="true">
                   <div class="modal-dialog">
                      <div class="modal-content">
                         <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                            <h3 class="modal-title">Entry Forms</h3>
                         </div>
                         <div class="modal-body" style="float:left;width:100%;">
                           <div class="tabbable-line">
                                <ul class="nav nav-tabs" id="staffViewTabs">
                                     <li class="active">
                                        <a href="#tab_5_1" data-toggle="tab"> Att in Absentia </a>
                                     </li>
                                     <li class="">
                                        <a href="#tab_5_2" data-toggle="tab"> Leave Application </a>
                                     </li>
                                     <li>
                                        <a href="#tab_5_3" data-toggle="tab"> Unauthorized Leave Penalty </a>
                                     </li>
                                     <li>
                                        <a href="#tab_5_4" data-toggle="tab"> Missed Tap Event. </a>
                                     </li>
                                     <li>
                                        <a href="#tab_5_5" data-toggle="tab"> Exceptional Adjustments </a>
                                     </li>
                                </ul>
                                
                                <div class="tab-content">
                                  <div class="tab-pane active" id="tab_5_1">
                                    <div class="portlet box blue-hoki">
                                       <div class="portlet-title">
                                          <div class="caption">
                                             <i class="fa fa-user"></i><font id="selected_individuals">Attendance in Absentia form</font>
                                          </div>
                                       </div>
                                       <!-- portlet-title -->
                                       <div class="headRightDetailsInner2 form-group">
                                          <div class="input-group select2-bootstrap-append">
                                            <select id="multi-append" class="form-control select2 absentiaSelect" multiple>
                                                <option></option>
                                                @foreach ($staff as $data)
                                                  <option value="{{ $data->staff_id }}"> {{ $data->abridged_name }}<small> - {{ $data->name_code }}</small></option>
                                                @endforeach                  
                                            </select>
                                            <span class="input-group-btn">
                                                <button class="btn btn-default" type="button" data-select2-open="multi-append">
                                                    <span class="glyphicon glyphicon-search"></span>
                                                </button>
                                            </span>
                                        </div>
                                       </div><!-- -->
                                       <div class="portlet-body fixedHeightmodalPortlet">
                                          <div class="form-body">
                                             <div class="row">
                                                <div class="col-md-6 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Title:</label>
                                                      <div class="">
                                                         <input type="text" class="form-control" name="" id="multiple_absentia_title" data-id="">
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                                <div class="col-md-6 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Date:</label>
                                                      <div class="">
                                                         <input type="date" class="form-control" name="" id="multiple_absentia_date" data-id="">
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                             </div>
                                             <!-- row -->
                                             <div class="row">
                                                <div class="col-md-6 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Start Time:</label>
                                                      <div class="">
                                                         <input type="time" class="form-control" name="" id="multiple_absentia_startTime" data-id="">
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                                <div class="col-md-6 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">End Time:</label>
                                                      <div class="">
                                                         <input type="time" class="form-control" name="" id="multiple_absentia_endTime" data-id="">
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                             </div>
                                             <!-- row -->
                                             <div class="row">
                                                <div class="col-md-12 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Description:</label>
                                                      <div class="">
                                                         <textarea id="multiple_absentia_description" cols="85" rows="5"></textarea>
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                             </div>
                                             <!-- row -->
                                          </div>
                                          <!-- form-body -->
                                          <div class="form-actions">
                                            <button type="submit" class="btn blue saveMultipleAbsentia">Submit</button>
                                            <button type="button" class="btn default">Cancel</button>
                                        </div>
                                       </div>
                                       <!-- portlet-body fixedHeightmodalPortlet-->
                                       
                                    </div>
                                  </div><!-- tab_5_1 -->
                                  <div class="tab-pane" id="tab_5_2">
                                    <div class="portlet box blue-hoki">
                                       <div class="portlet-title">
                                          <div class="caption">
                                             <i class="fa fa-user"></i><font id="">Leave form</font>
                                          </div>
                                       </div>
                                       <!-- portlet-title -->
                                       <div class="headRightDetailsInner2 form-group">
                                      <div class="input-group select2-bootstrap-append">
                                        <select id="multi-append" class="form-control select2 leaveSelect" multiple>
                                            <option></option>
                                            @foreach ($staff as $data)
                                            <option value="{{ $data->staff_id }}"> {{ $data->abridged_name }}<small> - {{ $data->name_code }}</small></option>
                                            @endforeach
                         
                                        </select>
                                        <span class="input-group-btn">
                                            <button class="btn btn-default" type="button" data-select2-open="multi-append">
                                                <span class="glyphicon glyphicon-search"></span>
                                            </button>
                                        </span>
                                    </div>
                                   </div><!-- -->
                                       <!-- headRightDetailsInner -->
                                       <div class="portlet-body fixedHeightmodalPortlet">
                                          <div class="form-body">
                                             <div class="row">
                                                <div class="col-md-6 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Leave Title:</label>
                                                      <div class="">
                                                         <input type="text" class="form-control" name="leave_title" id="multiple_leave_title" data-id="">
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                                <div class="col-md-6 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Leave Type:</label>
                                                      <div class="">
                                                         <select class="form-control multiple_leave_type">
                                                         @foreach($leaveType as $type)
                                                                        <option value="{{$type->id}}">{{$type->leave_type_name}}</option>
                                                                     @endforeach
                                                         </select>
                                                         <!-- select -->
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                             </div>
                                             <!-- row -->
                                             <div class="row">
                                                <div class="col-md-6 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">From:</label>
                                                      <div class="">
                                                         <input type="date" class="form-control" name="" id="multiple_leave_from" data-id="">
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                                <div class="col-md-6 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">To:</label>
                                                      <div class="">
                                                         <input type="date" class="form-control" name="" id="multiple_leave_to" data-id="">
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                             </div>
                                             <!-- row -->
                                             <div class="row">
                                                <div class="col-md-12 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Additional Comments <small>(if any)</small>:</label>
                                                      <div class="">
                                                         <textarea id="multiple_leave_comment" cols="85" rows="5"></textarea>
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                             </div>
                                             <!-- row -->
                                             <div class="row">
                                                <div class="col-md-12 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Request for a paid Compensation</label>
                                                      <div class="">
                                                         <input id="multiple_limit" type="checkbox" class="make-switch" data-on-text="Yes" data-off-text="No">
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                             </div>
                                             <!-- row -->
                                          </div>
                                          <!-- form-body -->
                                          <div class="form-actions">
                                            <button type="submit" class="btn blue saveMultipleLeave">Submit</button>
                                            <button type="button" class="btn default">Cancel</button>
                                        </div>
                                       </div>
                                       <!-- portlet-body fixedHeightmodalPortlet-->
                                       
                                    </div>
                                  </div><!-- tab_5_2 -->
                                  <div class="tab-pane" id="tab_5_3">
                                    <div class="portlet box blue-hoki">
                                       <div class="portlet-title">
                                          <div class="caption">
                                             <i class="fa fa-user"></i><font id="">Penalty</font>
                                          </div>
                                       </div>
                                       <!-- portlet-title -->
                                       <div class="headRightDetailsInner2 form-group">
                                      <div class="input-group select2-bootstrap-append">
                                        <select id="multi-append" class="form-control select2 selectPenalty" multiple>
                                            <option></option>
                                             @foreach ($staff as $data)
                                                  <option value="{{ $data->staff_id }}"> {{ $data->abridged_name }}<small> - {{ $data->name_code }}</small></option>
                                             @endforeach 
                                        </select>
                                        <span class="input-group-btn">
                                            <button class="btn btn-default" type="button" data-select2-open="multi-append">
                                                <span class="glyphicon glyphicon-search"></span>
                                            </button>
                                        </span>
                                    </div>
                                   </div>
                                       <!-- headRightDetailsInner -->
                                       <div class="portlet-body fixedHeightmodalPortlet">
                                          <div class="form-body">
                                             <div class="row">
                                                <div class="col-md-6 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Penalty Title:</label>
                                                      <div class="">
                                                         <input type="text" class="form-control" name="" id="multiple_penalty_title" data-id="">
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                                <div class="col-md-6 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Penalty for <small>(no of days)</small>:</label>
                                                      <div class="input-group">
                                                         <input id="multiple_penalty_day" type="number" class="form-control" placeholder="">
                                                         <span class="input-group-addon">
                                                         <i class="fa fa-hashtag"></i>
                                                         </span>
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                             </div>
                                             <!-- row -->
                                             <div class="row">
                                                <div class="col-md-6 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Penalty from:</label>
                                                      <div class="">
                                                         <input type="date" class="form-control" name="" id="multiple_penalty_from" data-id="">
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                                <div class="col-md-6 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Penalty to:</label>
                                                      <div class="">
                                                         <input id="multiple_penalty_to" type="date" class="form-control" placeholder="">
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                             </div>
                                             <!-- row -->
                                             <div class="row">
                                                <div class="col-md-12 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Information regarding Penalty:</label>
                                                      <div class="">
                                                         <textarea id="multiple_penalty_description" cols="85" rows="5"></textarea>
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                             </div>
                                             <!-- row -->
                                          </div>
                                          <!-- form-body -->
                                          <div class="form-actions">
                                            <button type="submit" class="btn blue saveMultiplePenalty">Submit</button>
                                            <button type="button" class="btn default">Cancel</button>
                                        </div>
                                       </div>
                                       <!-- portlet-body fixedHeightmodalPortlet-->
                                       
                                    </div>
                                  </div><!-- tab_5_3 -->
                                  <div class="tab-pane" id="tab_5_4">
                                    <div class="portlet box blue-hoki">
                                       <div class="portlet-title">
                                          <div class="caption">
                                             <i class="fa fa-user"></i><font id="">Missed Tap</font>
                                          </div>
                                       </div>
                                       <!-- portlet-title -->
                                       <div class="headRightDetailsInner2 form-group">
                                      <div class="input-group select2-bootstrap-append">
                                        <select id="multi-append" class="form-control select2 selectManual" multiple>
                                            <option></option>
                                             @foreach ($staff as $data)
                                                  <option value="{{ $data->staff_id }}"> {{ $data->abridged_name }}<small> - {{ $data->name_code }}</small></option>
                                             @endforeach 
                                        </select>
                                        <span class="input-group-btn">
                                            <button class="btn btn-default" type="button" data-select2-open="multi-append">
                                                <span class="glyphicon glyphicon-search"></span>
                                            </button>
                                        </span>
                                    </div>
                                   </div>
                                       <!-- headRightDetailsInner -->
                                       <div class="portlet-body fixedHeightmodalPortlet">
                                          <div class="form-body">
                                             <div class="row">
                                                <div class="col-md-12 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Attendance Date:</label>
                                                      <div class="">
                                                         <input type="date" class="form-control" name="" id="multiple_manual_attendance" data-id="">
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                             </div>
                                             <!-- row -->
                                             <div class="row">
                                                <div class="col-md-6 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Miss Tap:</label>
                                                      <div class="">
                                                         <input type="time" class="form-control" name="" id="multiple_manual_tap" data-id="">
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>


                                                <!-- col-md-6 -->
                                             </div>
                                             <!-- row -->
                                             <div class="row">
                                                <div class="col-md-12 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Information regarding manual attendance:</label>
                                                      <div class="">
                                                         <textarea id="multiple_manual_description" cols="85" rows="5"></textarea>
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                             </div>
                                             <!-- row -->
                                          </div>
                                          <!-- form-body -->
                                          <div class="form-actions">
                                            <button type="submit" class="btn blue saveMultipleManual">Submit</button>
                                            <button type="button" class="btn default">Cancel</button>
                                        </div>
                                       </div>
                                       <!-- portlet-body fixedHeightmodalPortlet-->
                                       
                                    </div>
                                  </div><!-- tab_5_4 -->
                                  <div class="tab-pane" id="tab_5_5">
                                    <div class="portlet box blue-hoki">
                                       <div class="portlet-title">
                                          <div class="caption">
                                             <i class="fa fa-user"></i><font id="">Adjustments</font>
                                          </div>
                                       </div>
                                       <!-- portlet-title -->
                                       <div class="headRightDetailsInner2 form-group">
                                      <div class="input-group select2-bootstrap-append">
                                        <select id="multi-append" class="form-control select2 selectAdjustments" multiple>
                                            <option></option>
                                             @foreach ($staff as $data)
                                                  <option value="{{ $data->staff_id }}"> {{ $data->abridged_name }}<small> - {{ $data->name_code }}</small></option>
                                             @endforeach 
                                        </select>
                                        <span class="input-group-btn">
                                            <button class="btn btn-default" type="button" data-select2-open="multi-append">
                                                <span class="glyphicon glyphicon-search"></span>
                                            </button>
                                        </span>
                                    </div>
                                   </div>
                                       <!-- headRightDetailsInner -->
                                       <div class="portlet-body fixedHeightmodalPortlet">
                                          <div class="form-body">
                                             <div class="row">
                                                <div class="col-md-6 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Title:</label>
                                                      <div class="">
                                                         <input type="text" class="form-control" name="" id="multiple_adjustment_title" data-id="">
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                                <div class="col-md-6 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Adjustment for <small>(no of days)</small>:</label>
                                                      <div class="input-group">
                                                         <input id="multiple_adjustment_no" type="number" class="form-control" placeholder="">
                                                         <span class="input-group-addon">
                                                         <i class="fa fa-hashtag"></i>
                                                         </span>
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                             </div>
                                             <!-- row -->
                                             <div class="row">
                                                <div class="col-md-12 paddingBottom10">
                                                   <div class="form-group">
                                                      <label class="">Information regarding Adjustments:</label>
                                                      <div class="">
                                                         <textarea id="multiple_adjustment_description" cols="85" rows="5"></textarea>
                                                      </div>
                                                   </div>
                                                   <!-- form-group -->
                                                </div>
                                                <!-- col-md-6 -->
                                             </div>
                                             <!-- row -->
                                          </div>
                                          <!-- form-body -->
                                          <div class="form-actions">
                                            <button type="submit" class="btn blue saveMultipleAdjustment">Submit</button>
                                            <button type="button" class="btn default">Cancel</button>
                                        </div>
                                       </div>
                                       <!-- portlet-body fixedHeightmodalPortlet-->
                                       
                                    </div>
                                  </div><!-- tab_5_5 -->
                                </div><!-- tab-content -->
                            </div><!-- tabbable-line -->
                            
                         </div>
                         <div class="modal-footer text-center" style="text-align:center;">
                         </div>
                      </div>
                      <!-- /.modal-content -->
                   </div>
                   <!-- /.modal-dialog -->
                </div>
            </div><!-- actions -->
         </div>

         <!-- portlet-title -->
         <div class="portlet-body">
            <div class="inputs">
               <div class="portlet-input">
                  <div class="input-icon right">
                     <i class="icon-magnifier"></i>
                     <input id="staffView_StaffList_Search" type="text" class="form-control form-control-solid" placeholder="Search..."> 
                  </div>
               </div>
               <div class="theme-panel hidden-xs hidden-sm"  style="right:33px;">
                  <div class="toggler"> </div>
                  <div class="toggler-close"> </div>
                  <div class="theme-options">
                     <div class="theme-option">
                        <span> Profile </span>
                        <select data-attribute="profile" multiple="multiple" id="StaffView_Filter_Profile" class="ddlFilterTableRow layout-option form-control input-sm">
                           @foreach ($filter['tt_profile'] as $d)
                           <option value="{{ $d->name }}">{{ $d->name }}</option>
                           @endforeach
                        </select>
                     </div>
                     <div class="theme-option">
                        <span> Department </span>
                        <select data-attribute="department" multiple="multiple" id="StaffView_Filter_Department" class="ddlFilterTableRow layout-option form-control input-sm">
                           @foreach ($filter['department'] as $d)
                           <option value="{{ $d->c_bottomline }}">{{ $d->c_bottomline }}</option>
                           @endforeach
                        </select>
                     </div>
                     <div class="theme-option">
                        <span> Campus </span>
                        <select  data-attribute="campus" multiple="multiple" id="StaffView_Filter_Campus" class="ddlFilterTableRow page-header-option form-control input-sm">
                           <option value="South">South</option>
                           <option value="North">North</option>
                        </select>
                     </div>
                     <div class="theme-option">
                        <span> Attendance Status </span>
                        <select  data-attribute="attendance" multiple="multiple" id="StaffView_Filter_AtdStd" class="ddlFilterTableRow page-header-option form-control input-sm">
                           <option value="On Time">On Time</option>
                           <option value="LATE">Late</option>
                           <option value="ABSENT">Absent</option>
                           <option value="HALFDAY">Half Day</option>
                           <option value="SHORTLEAVE">Short Leave</option>
                        </select>
                     </div>
                     <div class="theme-option">
                        <span> Staff Status </span>
                        <select  data-attribute="staff" multiple="multiple" id="StaffView_Filter_StaffStd" class="ddlFilterTableRow page-header-option form-control input-sm">
                           <option value="s">S</option>
                           <option value="c">C</option>
                           <option value="x">X</option>
                           <option value="f">F</option>
                        </select>
                     </div>
                     <div class="theme-option text-center" id="staffView_filter_btn">
                        <a href="javascript:;" class="btn uppercase green-jungle applyFilter">Apply Filter</a>
                        <a href="javascript:;" class="btn uppercase grey-salsa clearFilter">Clear Filter</a>
                     </div>
                  </div>
                  <!-- theme-options -->
               </div>
               <!-- theme-panel -->
               <div class="theme-panel hidden-xs hidden-sm">
                  <div class="toggler2"> </div>
                  <div class="toggler2-close"> </div>
                  <div class="theme-options2">
                     <div class="theme-option">
                        <span> By Name </span>
                        <select id="StaffView_Sort_Name" class="layout-option form-control input-sm">
                           <option value="A to Z">Ascending order (A to Z)</option>
                           <option value="Z to A">Descending order (Z to A)</option>
                        </select>
                     </div>
                     <div class="theme-option">
                        <span> By Department Name </span>
                        <select id="StaffView_Sort_Department" class="layout-option form-control input-sm">
                           <option value="A to Z">Ascending order (A to Z)</option>
                           <option value="Z to A">Descending order (Z to A)</option>
                        </select>
                     </div>
                     <div class="theme-option">
                        <span> By Attendance Score</span>
                        <select id="StaffView_Sort_AtdScore" class="page-header-option form-control input-sm">
                           <option value="H to L">High to Low</option>
                           <option value="L to H">Low to High</option>
                        </select>
                     </div>
                     <div class="theme-option text-center" id="staffView_sort_btn">
                        <a href="javascript:;" class="btn uppercase green-jungle applySort">Apply Sorters</a>
                        <a href="javascript:;" class="btn uppercase grey-salsa clearSort">Clear Sorters</a>
                     </div>
                  </div>
                  <!-- theme-options -->
               </div>
               <!-- updated sorter -->
               <?php /* ?>
               <div class="theme-panel hidden-xs hidden-sm">
                  <div class="sorter"> </div>
                  <div class="sorter-close"> </div>
                  <div class="sorter-options">
                     <div class="theme-option">
                        <span> Profile </span>
                        <select id="StaffView_Filter_Profile" class="layout-option form-control input-sm">
                           @foreach ($filter['tt_profile'] as $d)
                           <option value="{{ $d->name }}">{{ $d->name }}</option>
                           @endforeach
                        </select>
                     </div>
                     <div class="theme-option">
                        <span> Department </span>
                        <select id="StaffView_Filter_Department" class="layout-option form-control input-sm">
                           @foreach ($filter['department'] as $d)
                           <option value="{{ $d->c_bottomline }}">{{ $d->c_bottomline }}</option>
                           @endforeach
                        </select>
                     </div>
                     <div class="theme-option">
                        <span> Campus </span>
                        <select id="StaffView_Filter_Campus" class="page-header-option form-control input-sm">
                           <option value="South">South</option>
                           <option value="North">North</option>
                        </select>
                     </div>
                     <div class="theme-option">
                        <span> Attendance Status </span>
                        <select id="StaffView_Filter_AtdStd" class="page-header-option form-control input-sm">
                           <option value="OT">On TIme</option>
                           <option value="LATE">Late</option>
                           <option value="ABSENT">Absent</option>
                           <option value="HALFDAY">Half Day</option>
                           <option value="SHORTLEAVE">Short Leave</option>
                        </select>
                     </div>
                     <div class="theme-option text-center" id="staffView_filter_btn">
                        <a href="javascript:;" class="btn uppercase green-jungle applyFilter">Apply Filter</a>
                        <a href="javascript:;" class="btn uppercase grey-salsa clearFilter">Clear Filter</a>
                     </div>
                  </div>
                  <!-- theme-options -->
               </div>
               <!-- theme-panel -->
               <?php */ ?>
            </div>
            <!-- inputs -->
            <div class="table-scrollable table-scrollable-borderless">
               <table class="table table-hover table-light sortable" id="staffView_Table_StaffList">
                  <thead>
                     <tr class="uppercase">
                        <th colspan="2"> Staff </th>
                        <th class="text-center NoShowOnMob" colspan="2"> Atd. Status </th>
                        <th class="text-center ShowOnMob" colspan="2"> Atd. </th>
                     </tr>
                  </thead>
                  <!-- Static Table Row -->
                  <?php /*
                     <tr>
                         <td class="fit">
                             <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="16-070" src="http://10.10.10.50/gsims/public/assets/photos/hcm/150x150/staff/1159.png"> </td>
                         <td>
                             <a href="javascript:;" class="primary-link tooltips" data-container="body" data-placement="top" data-original-title="MHO">Muhammad Haris Ola</a> - <span class="nameCodeOption tooltips" data-container="body" data-placement="top" data-original-title="h.ola">MHO</span><br />
                             <small class="shortHeight"><span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="T-CPM">T</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">R</span> Front End Developer, Software</small>
                         </td>
                         <td class="text-center" colspan="2"> 
                             <span class="AttStatusNew">
                                 <span class="currentAttStatus"><img style="" src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png"  class="popovers" data-container="body" data-trigger="hover" data-placement="top" data-content="Tap in awaited" data-original-title="Absent" width="16" /></span>
                                 <span class="tenDayAttStatus">10</span>
                                 <span class="sixtyDayAttStatus">60</span>
                             </span>
                         </td>
                         
                     </tr>
                     <tr>
                         <td class="fit">
                             <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="16-070" src="http://10.10.10.50/gsims/public/assets/photos/hcm/150x150/staff/1159.png"> </td>
                         <td>
                             <a href="javascript:;" class="primary-link tooltips" data-container="body" data-placement="top" data-original-title="MHO">Muhammad Haris Ola</a> - <span class="nameCodeOption tooltips" data-container="body" data-placement="top" data-original-title="h.ola">MHO</span><br />
                             <small class="shortHeight"><span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="T-CPM">T</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">R</span> Front End Developer, Software</small>
                         </td>
                         <td class="text-center" colspan="2"> 
                             <span style="width:30px; text-align:center; float:left;">
                             <img style="margin-top: 6px;" src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png"  class="popovers" data-container="body" data-trigger="hover" data-placement="top" data-content="Tap in awaited" data-original-title="Absent" width="25" />
                             </span>
                             <span class="AttStatusNeww">
                                 <span class="tenDayAttStatuss">10</span>
                                 <span class="sixtyDayAttStatuss">60</span>
                             </span>
                         </td>
                         
                     </tr>
                     
                     <tr>
                         <td class="fit">
                             <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="16-070" src="http://10.10.10.50/gsims/public/assets/photos/hcm/150x150/staff/1159.png"> </td>
                         <td>
                             <a href="javascript:;" class="primary-link tooltips" data-container="body" data-placement="top" data-original-title="MHO">Muhammad Haris Ola</a><br />
                             <small style="float:left;margin-left:20px;" class="shortHeight">Front End Developer, Software</small>
                         </td>
                         <td class="text-center"> <img src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png"  class="popovers" data-container="body" data-trigger="hover" data-placement="top" data-content="Tap in awaited" data-original-title="Absent" width="25" /> </td>
                         <td class="text-center">
                             <span class="bold theme-font">80%</span>
                         </td>
                     </tr>
                     <tr>
                         <td class="fit">
                             <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="16-070" src="http://10.10.10.50/gsims/public/assets/photos/hcm/150x150/staff/1159.png"> </td>
                         <td>
                             <a href="javascript:;" class="primary-link tooltips" data-container="body" data-placement="top" data-original-title="MHO">Muhammad Haris Ola</a><br />
                             <small style="float:left;margin-left:20px;" class="shortHeight">Front End Developer, Software</small>
                         </td>
                         <td class="text-center"> <img src="http://10.10.10.50/gsims/public/metronic/pages/img/HalfDay.png" class="popovers" data-container="body" data-trigger="hover" data-placement="top" data-content="Tap In at 12:30 pm" data-original-title="Half Day" width="25" /> </td>
                         <td class="text-center">
                             <span class="bold theme-font">80%</span>
                         </td>
                     </tr>
                     <tr>
                         <td class="fit">
                             <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="16-070" src="http://10.10.10.50/gsims/public/assets/photos/hcm/150x150/staff/1159.png"> </td>
                         <td>
                             <a href="javascript:;" class="primary-link tooltips" data-container="body" data-placement="top" data-original-title="MHO">Muhammad Haris Ola</a><br />
                             <small style="float:left;margin-left:20px;" class="shortHeight">Front End Developer, Software</small>
                         </td>
                         <td class="text-center"> <img src="http://10.10.10.50/gsims/public/metronic/pages/img/ShortLeaveIcon.png" class="popovers" data-container="body" data-trigger="hover" data-placement="top" data-content="Tap In at 11:59 am" data-original-title="Short Leave" width="25" /> </td>
                         <td class="text-center">
                             <span class="bold theme-font">80%</span>
                         </td>
                     </tr>
                     <!-- End Static Table Row -->
                     */ ?>
                  @foreach ($staff as $data)
                  <tr class="Row" data-attendance="{{ $data->atd_title }}"   data-campus="{{ $data->campus }}" data-profile="{{ $data->tt_profile_name }}" data-department="{{ $data->c_topline }}, {{ $data->c_bottomline }}">
                     <td class="">
                        <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="{{ $data->gt_id }}" src="{{ $data->photo150 }}">
                     </td>
                     <td class="staffView_StaffName">
                        <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="{{ $data->name_code }}" data-staffID="{{ $data->staff_id }}" data-staffGTID="{{ $data->gt_id }}" data-src="{{url('metronic/pages/img') }}/{{ $data->atd_icon }}" data-content="Tap In {{ $data->atd_content }}" data-title="{{ $data->atd_title }}">{{ $data->abridged_name }}</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="{{ $data->email }}">{{ $data->name_code }}</small><br />
                        <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="{{ $data->status_description }}">{{ $data->status_name_code }}</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">R</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="{{ $data->c_topline }}, {{ $data->c_bottomline }}">{{ $data->c_bottomline }}: {{ $data->c_topline }}</span></small>
                     </td>
                     <td class="text-center" colspan="2">
                        <span style="width:30px; text-align:center; float:left;">
                        <img style="margin-top: 6px;" src="{{ url('metronic/pages/img') }}/{{ $data->atd_icon }}" class="popovers" data-container="body" data-trigger="hover" data-placement="top" data-content="Tap In {{ $data->atd_content }}" data-original-title="{{ $data->atd_title }}" width="25" />
                        </span>
                        <span class="AttStatusNeww">
                        <span class="tenDayAttStatuss tooltips" data-container="body" data-placement="top" data-original-title="10 day status">10</span>
                        <span class="sixtyDayAttStatuss tooltips" data-container="body" data-placement="top" data-original-title="60 day status">60</span>
                        </span>
                     </td>
                     <td class="text-center" style="display:none;"> <span aria-hidden="true"></span> {{ $data->name_code }} </td>
                     <td class="text-center" style="display:none;"> <span aria-hidden="true"></span> {{ $data->gt_id }} </td>
                     <td class="text-center" style="display:none;"> <span aria-hidden="true"></span> {{ $data->tt_profile_name }} </td>
                     <td class="text-center" style="display:none;"> <span aria-hidden="true"></span> {{ $data->c_bottomline }} </td>
                     <td class="text-center" style="display:none;"> <span aria-hidden="true"></span> {{ $data->campus }} </td>
                     <td class="text-center" style="display:none;"> <span aria-hidden="true"></span> {{ $data->atd_title }} </td>
                     <td class="text-center" style="display:none;"> <span aria-hidden="true"></span> {{ $data->abridged_name }} </td>
                  </tr>
                  @endforeach
               </table>
            </div>
            <!-- table-scrollable-borderless -->
         </div>
         <!-- portlet-body -->
      </div>
      <!-- portlet -->
   </div>
   <!-- col-md-4 -->
   <div class="col-md-8 fixed-height" id="staffView_StaffInfo">
      <div class="headRightDetails">
         <table>
            <tr id="staffView_ProcessorBar">
               <td class="" style="padding-right:10px;">
                  <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="12-057" src="assets/photos/hcm/150x150/staff/745.png" width="42">
               </td>
               <td class="staffView_StaffName">
                  <a href="javascript:;" class="primary-link tooltips" data-container="body" data-placement="top" data-original-title="745" data-staffid="295" data-staffgtid="12-057">Abdul Kalam</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="745">745</small><br>
                  <small class="shortHeight"><span class="tooltips" data-container="body" data-placement="top" data-original-title="Peon, South Campus, Operations &amp; Housekeeping">Operations &amp; Housekeeping: Peon, South Campus</span></small>
               </td>
            </tr>
         </table>
         <!-- col-md-4 -->
      </div>
      <div class="row">
         <div class="col-md-3 col-xs-6 MobPaddingRight0">
            <div class="profile-sidebar-portlet portlet light fixedHeight3">
               <!-- SIDEBAR USERPIC -->
               <div class="profile-userpic">
                  <img src="" class="img-responsive" alt=""> 
               </div>
               <!-- END SIDEBAR USERPIC -->
               <!-- SIDEBAR USER TITLE -->
               <div class="profile-usertitle">
                  <div class="profile-usertitle-name"></div>
               </div>
               <!-- END SIDEBAR USER TITLE -->
            </div>
            <!-- fixedHeight250 -->
         </div>
         <!-- col-md-3 -->
         <div class="col-md-3 paddingRight0 col-xs-6">
            <div class="portlet light fixedHeight3 paddingLeft10 paddingTop0">
               <div class="margin-top-10 profile-desc-link ">
                  <i class="icon-credit-card tooltips" data-container="body" data-placement="bottom" data-original-title="GT ID"></i>
                  <span class="linkLookalike profile-usertitle-gtid"></span>
               </div>
               <!--  -->
               <div class="margin-top-10 profile-desc-link ">
                  <i class="icon-envelope tooltips" data-container="body" data-placement="bottom" data-original-title="GU ID"></i>
                  <span class="linkLookalike profile-usertitle-email"></span>
               </div>
               <!--  -->
               <div class="margin-top-10 profile-desc-link ">
                  <i class="fa fa-map-marker tooltips" data-container="body" data-placement="bottom" data-original-title="Campus"></i>
                  <span class="linkLookalike profile-usertitle-campus"> Campus</span>
               </div>
               <!--  -->
               <div class="margin-top-10 profile-desc-link ">
                  <i class="fa fa-phone-square tooltips" data-container="body" data-placement="bottom" data-original-title="Mobile"></i>
                  <span class="profile-usertitle-mobilePhone linkLookalike"></span>
               </div>
               <!--  -->
               <div class="margin-top-10 profile-desc-link ">
                  <i class="fa fa-file-text-o tooltips" data-container="body" data-placement="bottom" data-original-title="Leave status"></i>
                  <span class=" linkLookalike currentLeave">3 / 10</span>
               </div>
               <!--  -->
            </div>
            <!-- fixedHeight250 -->
         </div>
         <!-- col-md-3 -->
         <div class="col-md-3 paddingRight0">
            <div class="portlet light fixedHeight3 paddingRight0 paddingLeft10 paddingTop0">
               <div class="margin-top-10 profile-desc-link pull-left width100">
                  <span class="pull-left width20"><img src="img/designationIcon.png" width="19px" class="tooltips" data-container="body" data-placement="bottom" data-original-title="Bottom Line: Top Line" /></span>
                  <span class="pull-left width80 linkLookalike profile-usertitle-bottomline"></span>
                  <span class="pull-left width20">&nbsp;</span>
                  <small  class="italicGray tooltips width80 pull-left" data-container="body" data-placement="bottom" data-original-title="Reporting to"><span class="profile-userrole-report-one"></span></small>
               </div>
               <div class="margin-top-10 profile-desc-link pull-left">
                  <i class="icon-user-following tooltips" data-container="body" data-placement="bottom" data-original-title="Timing Profile"></i>
                  <span class="linkLookalike profile-user-detail"></span>
               </div>
               <!--  -->
               <div class="margin-top-10 profile-desc-link pull-left">
                  <span style="width:22px; text-align:center; float:left;" class="profile-user-attendance">
                  </span>
                  <span class="" style="float:left;margin-top:0px;margin-left:4px;font-size: 14px;font-weight: 600;color: #5b9bd1;">  
                  <span class=" tooltips" data-container="body" data-placement="top" data-original-title="10 day status">10</span> | <span class=" tooltips" data-container="body" data-placement="top" data-original-title="60 day status">60</span>
                  </span>
               </div>
            </div>
            <!-- portlet light -->
         </div>
         <!-- col-md-3 -->
         <div class="col-md-3 paddingRight0 ">
            <div class="portlet light fixedHeight3 paddingLeft10 paddingRight0 paddingTop0">
               <div class="margin-top-10 profile-desc-link pull-left width100">
                  <div class="flowidth100">
                     <span class="pull-left width20 profile-userrole-role-one-img" style="display:none"><img src="img/role.png" width="19px" class="tooltips" data-container="body" data-placement="bottom" data-original-title="Role 1" /></span>
                     <span class="pull-left width80 linkLookalike profile-userrole-role-one"></span><br />
                  </div>
                  <!-- flowidth100 -->
                  <div class="flowidth100">
                     <span class="pull-left width20">&nbsp;</span>
                     <small class="italicGray tooltips" data-container="body" data-placement="bottom" data-original-title="Reporting to"><span class="pull-left width80 profile-userrole-role-one-report"></span></small>
                  </div>
                  <!-- flowidth100 -->
               </div>
               <!--  profile-desc-link pull-left -->
               <div class="margin-top-10 profile-desc-link pull-left width100">
                  <div class="flowidth100">
                     <span class="pull-left width20 profile-userrole-role-two-img" style="display:none"><img src="img/role.png" width="19px" class="tooltips" data-container="body" data-placement="bottom" data-original-title="Role 2" /></span>
                     <span class="pull-left width80 linkLookalike profile-userrole-role-two"></span><br />
                  </div>
                  <!-- flowidth100 -->
                  <div class="flowidth100">
                     <span class="pull-left width20">&nbsp;</span>
                     <small class="italicGray tooltips" data-container="body" data-placement="bottom" data-original-title="Reporting to"><span class="pull-left width80 profile-userrole-role-two-report"></span></small>
                  </div>
                  <!-- flowidth100 -->
               </div>
               <!--  profile-desc-link pull-left -->
            </div>
            <!-- portlet light -->
         </div>
         <!-- col-md-3 -->
      </div>
      <!-- row -->
      <div class="row">
         <div class="col-md-12 paddingRight0">
            <div class="portlet light bordered padding0 marginBottom0">
               <div class="portlet-body padding20">
                  <ul class="nav nav-tabs fullWidthTabs" id="staffViewTabs">
                     <li class="active">
                        <a href="#tab_1_5" data-toggle="tab"> Stories </a>
                     </li>
                     <li class="">
                        <a href="#tab_1_1" data-toggle="tab"> TIF-B </a>
                     </li>
                     <li>
                        <a href="#tab_1_2" data-toggle="tab"> TIF-A </a>
                     </li>
                     <li>
                        <a href="#tab_1_3" data-toggle="tab"> Attendance </a>
                     </li>
                     <li>
                        <a href="#tab_1_4" data-toggle="tab"> Process </a>
                     </li>
                     <li>
                        <a href="#tab_1_6" data-toggle="tab" id="rolesRelation"> Relationships </a>
                     </li>
                  </ul>
                  <div class="tab-content">
                     <div class="tab-pane fade" id="tab_1_1">
                        <div class="tabbable-line">
                           <ul class="nav nav-tabs ">
                              <li class="active">
                                 <a href="#tab_basic" data-toggle="tab"> <span aria-hidden="true" class="icon-info"></span> Basics </a>
                              </li>
                              <li>
                                 <a href="#tab_education" data-toggle="tab"> <span aria-hidden="true" class="icon-graduation"></span> Education </a>
                              </li>
                              <li>
                                 <a href="#tab_employment" data-toggle="tab"> <span aria-hidden="true" class="icon-briefcase"></span> Employments </a>
                              </li>
                              <li class="">
                                 <a href="#tab_parent" data-toggle="tab"> <span aria-hidden="true" class="icon-users"></span> Parent / Spouse </a>
                              </li>
                              <li>
                                 <a href="#tab_children" data-toggle="tab"> <i class="fa fa-child"></i> Children </a>
                              </li>
                              <li>
                                 <a href="#tab_alternate" data-toggle="tab"> <i class="fa fa-phone"></i> Alternate Contacts </a>
                              </li>
                              <li>
                                 <a href="#tab_other" data-toggle="tab"> <span aria-hidden="true" class="icon-plus"></span> Other </a>
                              </li>
                           </ul>
                           <!-- nav -->
                           <div class="tab-content">
                              <div class="tab-pane active" id="tab_basic">
                                 <div class="form-body">
                                    <h3 class="form-section marginTop0 headingBorderBottom">Person Info</h3>
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Full Name:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-fullName"> Afsar Ilyas </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">CNIC:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-nic"> 42501-4559651-3 </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Religion:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-religion"> Islam </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Nationality:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-nationality"> PAK </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Gender:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-gender"> Male: </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">DOB <small>(as per NIC)</small>:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-dob"> 23 Feb 1977 </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Marital Status:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-maritalStatus"> Single </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <h3 class="form-section headingBorderBottom">Contact Info</h3>
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Mobile: </label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-mobilePhone"> 0332-2536406 </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Landline:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-landLine"> 021-34615130 </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Email <small>(personal)</small>:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-personalEmail"> harisola@gmail.com </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <h3 class="form-section headingBorderBottom">Address Info</h3>
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Apartment No:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-apartmentNo"> - </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Street Name:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-streetName"> - </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Building Name:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-buildingName"> - </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Plot No:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-plotNo"> E-33/1 </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Region:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-region"> Nazimabad </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Sub Region:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-subRegion"> Block 7 </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <h3 class="form-section headingBorderBottom">Official Info</h3>
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Name Code:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-nameCode"> Single </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Employment Status:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tifb-basics-empStatus"> 0 </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5 text-right paddingRight0">Tap In Campus:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold tap_in_campus"></p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                 </div>
                                 <!-- form-body -->
                              </div>
                              <!-- tab_basic -->
                              <div class="tab-pane" id="tab_education">
                                 <h4 class="form-section headingBorderBottom">Others</h4>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="portlet light bordered lowPadding">
                                          <div class="portlet-body">
                                             <div class="col-md-3 padding0">
                                                <img src="http://10.10.10.50/gsims/public/metronic/pages/img/schoolIcon.jpg" class="SchoolPlaceHolder" />
                                             </div>
                                             <!-- col-md-3 -->
                                             <div class="col-md-9 paddingRight0">
                                                <h5 class=" marginBottom0"><strong>Skill Development Council</strong></h5>
                                                <h5 class="font-grey-cascade"><strong>Certification</strong>, HRM</h5>
                                                <div class="col-md-6 padding0">
                                                   <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-graduation"></span>&nbsp;&nbsp;&nbsp;1st Division</h5>
                                                </div>
                                                <div class="col-md-6">
                                                   <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-calendar"></span>&nbsp;&nbsp;&nbsp;2010</h5>
                                                </div>
                                             </div>
                                             <!-- col-md-9 -->
                                          </div>
                                          <!-- portlet-body -->
                                       </div>
                                       <!-- portlet -->
                                    </div>
                                    <!-- col-md-6 -->
                                    <div class="col-md-6">
                                       <div class="portlet light bordered lowPadding">
                                          <div class="portlet-body">
                                             <div class="col-md-3 padding0">
                                                <img src="http://10.10.10.50/gsims/public/metronic/pages/img/schoolIcon.jpg" class="SchoolPlaceHolder" />
                                             </div>
                                             <!-- col-md-3 -->
                                             <div class="col-md-9 paddingRight0">
                                                <h5 class=" marginBottom0"><strong>Skill Development Council</strong></h5>
                                                <h5 class="font-grey-cascade"><strong>Certification</strong>, Essentials of Management</h5>
                                                <div class="col-md-6 padding0">
                                                   <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-graduation"></span>&nbsp;&nbsp;&nbsp;1st Division</h5>
                                                </div>
                                                <div class="col-md-6">
                                                   <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-calendar"></span>&nbsp;&nbsp;&nbsp;2011</h5>
                                                </div>
                                             </div>
                                             <!-- col-md-9 -->
                                          </div>
                                          <!-- portlet-body -->
                                       </div>
                                       <!-- portlet -->
                                    </div>
                                    <!-- col-md-6 -->
                                 </div>
                                 <!-- row -->
                                 <h4 class="form-section headingBorderBottom">Professional</h4>
                                 <h4 class="form-section headingBorderBottom">University</h4>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="portlet light bordered lowPadding">
                                          <div class="portlet-body">
                                             <div class="col-md-3 padding0">
                                                <img src="http://10.10.10.50/gsims/public/metronic/pages/img/uoklogo.png" class="SchoolPlaceHolder" />
                                             </div>
                                             <!-- col-md-3 -->
                                             <div class="col-md-9 paddingRight0">
                                                <h5 class=" marginBottom0"><strong>University of Karachi</strong></h5>
                                                <h5 class="font-grey-cascade"><strong>M.P.A</strong>, Public Administration</h5>
                                                <div class="col-md-6 padding0">
                                                   <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-graduation"></span>&nbsp;&nbsp;&nbsp;2nd Division</h5>
                                                </div>
                                                <div class="col-md-6">
                                                   <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-calendar"></span>&nbsp;&nbsp;&nbsp;2001</h5>
                                                </div>
                                             </div>
                                             <!-- col-md-9 -->
                                          </div>
                                          <!-- portlet-body -->
                                       </div>
                                       <!-- portlet -->
                                    </div>
                                    <!-- col-md-6 -->
                                 </div>
                                 <!-- row -->
                                 <h4 class="form-section headingBorderBottom">College</h4>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="portlet light bordered lowPadding">
                                          <div class="portlet-body">
                                             <div class="col-md-3 padding0">
                                                <img src="http://10.10.10.50/gsims/public/metronic/pages/img/schoolIcon.jpg" class="SchoolPlaceHolder" />
                                             </div>
                                             <!-- col-md-3 -->
                                             <div class="col-md-9 paddingRight0">
                                                <h5 class=" marginBottom0"><strong>P.A.F (Faisal Base)</strong></h5>
                                                <h5 class="font-grey-cascade"><strong>B.Sc</strong>, Computer Science, Economics & Maths</h5>
                                                <div class="col-md-6 padding0">
                                                   <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-graduation"></span>&nbsp;&nbsp;&nbsp;2nd Division</h5>
                                                </div>
                                                <div class="col-md-6">
                                                   <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-calendar"></span>&nbsp;&nbsp;&nbsp;1997</h5>
                                                </div>
                                             </div>
                                             <!-- col-md-9 -->
                                          </div>
                                          <!-- portlet-body -->
                                       </div>
                                       <!-- portlet -->
                                    </div>
                                    <!-- col-md-6 -->
                                 </div>
                                 <!-- row -->
                                 <h4 class="form-section headingBorderBottom">School</h4>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="portlet light bordered lowPadding">
                                          <div class="portlet-body">
                                             <div class="col-md-3 padding0">
                                                <img src="http://10.10.10.50/gsims/public/metronic/pages/img/schoolIcon.jpg" class="SchoolPlaceHolder" />
                                             </div>
                                             <!-- col-md-3 -->
                                             <div class="col-md-9 paddingRight0">
                                                <h5 class=" marginBottom0"><strong>National High School</strong></h5>
                                                <h5 class="font-grey-cascade"><strong>Matric</strong>, Science</h5>
                                                <div class="col-md-6 padding0">
                                                   <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-graduation"></span>&nbsp;&nbsp;&nbsp;1st Division</h5>
                                                </div>
                                                <div class="col-md-6">
                                                   <h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-calendar"></span>&nbsp;&nbsp;&nbsp;1991</h5>
                                                </div>
                                             </div>
                                             <!-- col-md-9 -->
                                          </div>
                                          <!-- portlet-body -->
                                       </div>
                                       <!-- portlet -->
                                    </div>
                                    <!-- col-md-6 -->
                                 </div>
                                 <!-- row -->
                                 <?php /* ?>
                                 <table width="100%" border="0" class="table table-bordered">
                                    <thead class="bg-grey">
                                       <tr>
                                          <th class="" width="40%">Institute</th>
                                          <th width="20%">Subjects</th>
                                          <th width="20%">Qualification</th>
                                          <th width="10%">Result</th>
                                          <th width="10%">Year of<br>Completion</th>
                                       </tr>
                                    </thead>
                                    <!-- thead -->
                                    <tbody>
                                       <tr class="bBottomD">
                                          <td colspan="5" class=""><strong>School</strong></td>
                                       </tr>
                                       <tr>
                                          <td>National High School</td>
                                          <td>Science</td>
                                          <td>Matric</td>
                                          <td>Ist-Div</td>
                                          <td>1992</td>
                                       </tr>
                                       <tr>
                                          <td>-</td>
                                          <td>-</td>
                                          <td>-</td>
                                          <td>-</td>
                                          <td>-</td>
                                       </tr>
                                       <tr class="bBottomD">
                                          <td colspan="5" class=""><strong>College</strong></td>
                                       </tr>
                                       <tr>
                                          <td>P.A.F (Faisl Base)</td>
                                          <td>Computer Science, Economics &amp; Maths</td>
                                          <td>B.Sc.</td>
                                          <td>IInd-Div</td>
                                          <td>1997</td>
                                       </tr>
                                       <tr>
                                          <td>-</td>
                                          <td>-</td>
                                          <td>-</td>
                                          <td>-</td>
                                          <td>-</td>
                                       </tr>
                                       <tr class="bBottomD">
                                          <td colspan="5" class=""><strong>University</strong></td>
                                       </tr>
                                       <tr>
                                          <td>University of Karachi  UoK  Karachi</td>
                                          <td>Public Administration</td>
                                          <td>M.P.A</td>
                                          <td>IInd-Div</td>
                                          <td>2001</td>
                                       </tr>
                                       <tr>
                                          <td>-</td>
                                          <td>-</td>
                                          <td>-</td>
                                          <td>-</td>
                                          <td>-</td>
                                       </tr>
                                       <tr class="bBottomD">
                                          <td colspan="5" class=""><strong>Professional</strong></td>
                                       </tr>
                                       <tr>
                                          <td>-</td>
                                          <td>-</td>
                                          <td>-</td>
                                          <td>-</td>
                                          <td>-</td>
                                       </tr>
                                       <tr>
                                          <td>-</td>
                                          <td>-</td>
                                          <td>-</td>
                                          <td>-</td>
                                          <td>-</td>
                                       </tr>
                                       <tr class="bBottomD">
                                          <td colspan="5" class=""><strong>Others</strong></td>
                                       </tr>
                                       <tr>
                                          <td>Skill Development Council</td>
                                          <td>HRM</td>
                                          <td>Certification</td>
                                          <td>Ist-Div</td>
                                          <td>2010</td>
                                       </tr>
                                       <tr>
                                          <td>Skill Development Council</td>
                                          <td>Essentials of Management</td>
                                          <td>Certification</td>
                                          <td>Ist-Div</td>
                                          <td>2011</td>
                                       </tr>
                                    </tbody>
                                    <!-- tbody -->
                                 </table>
                                 <!-- tale -->
                                 <?php */ ?>
                              </div>
                              <!-- tab_education -->
                              <div class="tab-pane" id="tab_employment">
                                 <div class="row">
                                    <div class="col-md-12">
                                       <div class="portlet light lowPadding2 onlyBorderBottom marginBottom0">
                                          <div class="portlet-body">
                                             <div class="col-md-1 padding0">
                                                <img src="http://10.10.10.50/gsims/public/metronic/pages/img/aflogo.jpg" class="SchoolPlaceHolder" />
                                             </div>
                                             <!-- col-md-3 -->
                                             <div class="col-md-11 paddingRight0">
                                                <h5 class=" marginBottom0 font-grey-mint marginTop0"><strong>IT Business Analyst</strong> at <strong>Assessment Fund</strong></h5>
                                                <h5 class="font-grey-salsa marginBottom4">
                                                   <span class="positionDetail"><i class="fa fa-money tooltips" data-container="body" data-placement="top" data-original-title="Sallary"></i> <strong>10,000</strong></span>
                                                   <span class="positionDetail"><i class="fa fa-calendar tooltips" data-container="body" data-placement="top" data-original-title="Tenure"></i> <strong>2001</strong> to <strong>2005</strong></span>
                                                   <span class="positionDetail"><img src="http://10.10.10.50/gsims/public/metronic/pages/img/blackboard.png" width="20" class="tooltips" data-container="body" data-placement="top" data-original-title="Classes Taught" /> <strong>10,000</strong></span>
                                                   <span class="positionDetail"><i class="icon-book-open tooltips" data-container="body" data-placement="top" data-original-title="Subjects Taught"></i> <strong>Islamiat, Islamiat English, Urdu</strong></span>
                                                </h5>
                                                <p class="font-grey-salsa marginBottom0">Reason for Leaving: <span class="font-grey-mint">Lorem Ipsum dolor sit amet, Lorem Ipsum dolor sit amet Lorem Ipsum dolor</span> </p>
                                             </div>
                                             <!-- col-md-9 -->
                                          </div>
                                          <!-- portlet-body -->
                                       </div>
                                       <!-- portlet -->
                                    </div>
                                    <!-- col-md-6 -->
                                 </div>
                                 <!-- row -->
                                 <div class="row">
                                    <div class="col-md-12">
                                       <div class="portlet light lowPadding2 onlyBorderBottom marginBottom0">
                                          <div class="portlet-body">
                                             <div class="col-md-1 padding0">
                                                <img src="http://10.10.10.50/gsims/public/metronic/pages/img/BriefacaseIcon.jpg" class="SchoolPlaceHolder" />
                                             </div>
                                             <!-- col-md-3 -->
                                             <div class="col-md-11 paddingRight0">
                                                <h5 class=" marginBottom0 font-grey-mint marginTop0">Formerly worked at <strong>HireLabs</strong> on the position of <strong>UI/UX Lead</strong></h5>
                                                <h5 class="font-grey-salsa marginBottom4">
                                                   <span class="positionDetail"><i class="fa fa-money tooltips" data-container="body" data-placement="top" data-original-title="Sallary"></i> <strong>10,000</strong></span>
                                                   <span class="positionDetail"><i class="fa fa-calendar tooltips" data-container="body" data-placement="top" data-original-title="Tenure"></i> <strong>2001</strong> to <strong>2005</strong></span>
                                                   <span class="positionDetail"><img src="http://10.10.10.50/gsims/public/metronic/pages/img/blackboard.png" width="20" class="tooltips" data-container="body" data-placement="top" data-original-title="Classes Taught" /> <strong>I, II, III </strong></span>
                                                   <span class="positionDetail"><i class="icon-book-open tooltips" data-container="body" data-placement="top" data-original-title="Subjects Taught"></i> <strong>Islamiat, Islamiat English, Urdu</strong></span>
                                                </h5>
                                                <p class="font-grey-salsa marginBottom0">Reason for Leaving: <span class="font-grey-mint">-</span> </p>
                                             </div>
                                             <!-- col-md-9 -->
                                          </div>
                                          <!-- portlet-body -->
                                       </div>
                                       <!-- portlet -->
                                    </div>
                                    <!-- col-md-6 -->
                                 </div>
                                 <!-- row -->
                                 <div class="row">
                                    <div class="col-md-12">
                                       <div class="portlet light lowPadding2 marginBottom0">
                                          <div class="portlet-body">
                                             <div class="col-md-1 padding0">
                                                <img src="http://10.10.10.50/gsims/public/metronic/pages/img/BriefacaseIcon.jpg" class="SchoolPlaceHolder" />
                                             </div>
                                             <!-- col-md-3 -->
                                             <div class="col-md-11 paddingRight0">
                                                <h5 class=" marginBottom0 font-grey-mint marginTop0">Web Developer at <strong>TechiBits</strong></h5>
                                                <h5 class="font-grey-salsa marginBottom4">
                                                   <span class="positionDetail"><i class="fa fa-money tooltips" data-container="body" data-placement="top" data-original-title="Sallary"></i> <strong>10,000</strong></span>
                                                   <span class="positionDetail"><i class="fa fa-calendar tooltips" data-container="body" data-placement="top" data-original-title="Tenure"></i> <strong>2001</strong> to <strong>2005</strong></span>
                                                   <span class="positionDetail"><img src="http://10.10.10.50/gsims/public/metronic/pages/img/blackboard.png" width="20" class="tooltips" data-container="body" data-placement="top" data-original-title="Classes Taught" /> <strong>10,000</strong></span>
                                                   <span class="positionDetail"><i class="icon-book-open tooltips" data-container="body" data-placement="top" data-original-title="Subjects Taught"></i> <strong>Islamiat, Islamiat English, Urdu</strong></span>
                                                </h5>
                                                <p class="font-grey-salsa marginBottom0">Reason for Leaving: <span class="font-grey-mint">Personal Growth</span> </p>
                                             </div>
                                             <!-- col-md-9 -->
                                          </div>
                                          <!-- portlet-body -->
                                       </div>
                                       <!-- portlet -->
                                    </div>
                                    <!-- col-md-6 -->
                                 </div>
                                 <!-- row -->
                                 <!-- 
                                    <table width="100%" border="0" class="table table-bordered">
                                        <thead class="bg-grey">
                                            <tr>
                                                <th class="">Institution</th>
                                                <th>Designation</th>
                                                <th>Class(s)<br>taught</th>
                                                <th>Subject(s)<br>taught</th>
                                                <th>Salary</th>
                                                <th>From<br><small>(year)</small></th>
                                                <th>To<br><small>(year)</small></th>
                                                <th>Reasons for Leaving</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Mobilink GSM (POS)</td>
                                                <td>Proprietor</td>
                                                <td></td>
                                                <td></td>
                                                <td>100000</td>
                                                <td>2001</td>
                                                <td>2009</td>
                                                <td>Security Reasons....</td>
                                            </tr>        
                                        </tbody>
                                    </table>
                                    -->
                              </div>
                              <!-- tab_employment -->
                              <div class="tab-pane " id="tab_parent">
                                 <table width="100%" border="0" class="table table-bordered">
                                    <thead class="bg-grey">
                                       <tr>
                                          <th class="text-center" width="40%">Father</th>
                                          <th class="text-center" width="20%">&nbsp;</th>
                                          <th class="text-center" width="40%">Spouse</th>
                                       </tr>
                                    </thead>
                                    <tbody id="tab_parent_table">
                                       <tr>
                                          <td class="">Ilyas Ahmed Khan (Late)</td>
                                          <td class="text-center"><strong>Name</strong></td>
                                          <td class="">Sana Afsar</td>
                                       </tr>
                                       <tr>
                                          <td>Bureaucrats</td>
                                          <td class="text-center"><strong>Profession</strong></td>
                                          <td>Housewife</td>
                                       </tr>
                                       <tr>
                                          <td></td>
                                          <td class="text-center"><strong>Qualification</strong></td>
                                          <td>Bachelors</td>
                                       </tr>
                                       <tr>
                                          <td></td>
                                          <td class="text-center"><strong>Designation</strong></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td></td>
                                          <td class="text-center"><strong>Department</strong></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td></td>
                                          <td class="text-center"><strong>Organisation</strong></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td></td>
                                          <td class="text-center"><strong>CNIC</strong></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td></td>
                                          <td class="text-center"><strong>Mobile</strong></td>
                                          <td>0300-2333365</td>
                                       </tr>
                                       <tr>
                                          <td>&nbsp;</td>
                                          <td class="text-center"><strong>Address</strong></td>
                                          <td>&nbsp;</td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                              <!-- tab_parent -->
                              <div class="tab-pane" id="tab_children">
                                 <div class="row">
                                    <div class="col-md-12">
                                       <div class="portlet light portlet-fit">
                                          <div class="portlet-body padding0">
                                             <div class="mt-element-card mt-element-overlay">
                                                <div class="row" id="tab_staff_child">
                                                   <div class="col-md-3">
                                                      <div class="mt-card-item">
                                                         <div class="mt-card-avatar mt-overlay-4">
                                                            <img src="http://10.10.10.50/gsims/public/assets/photos/sis/500x500/student/2416.jpg" />
                                                            <div class="mt-overlay">
                                                               <h2>11-C <span class="font-yellow-lemon">(Jinnah)</span></h2>
                                                               <div class="mt-info font-white">
                                                                  <div class="mt-card-content">
                                                                     <p class="mt-card-desc font-white">GF-ID: <strong>16-249</strong> (1/3)</p>
                                                                     <div class="mt-card-social">
                                                                     </div>
                                                                  </div>
                                                               </div>
                                                            </div>
                                                            <!-- mt-overlay -->
                                                         </div>
                                                         <!-- mt-card-avatar -->
                                                         <div class="mt-card-content">
                                                            <h3 class="mt-card-name">Suleman Atif</h3>
                                                            <p class="mt-card-desc font-grey-mint">GS-ID: <strong>10-102</strong> (S-CFS)</p>
                                                         </div>
                                                         <!-- mt-card-content -->
                                                      </div>
                                                      <!-- mt-card-item -->
                                                   </div>
                                                   <!-- col-md-3 -->
                                                   <div class="col-md-3">
                                                      <div class="mt-card-item alumni">
                                                         <div class="mt-card-avatar mt-overlay-4">
                                                            <img src="http://10.10.10.50/gsims/public/assets/photos/sis/500x500/student/494.jpg" />
                                                            <div class="mt-overlay">
                                                               <h2>Alumni</h2>
                                                               <div class="mt-info font-white">
                                                                  <div class="mt-card-content">
                                                                     <p class="mt-card-desc font-white">GF-ID: <strong>02-596</strong> (2/3)</p>
                                                                     <div class="mt-card-social">
                                                                     </div>
                                                                  </div>
                                                               </div>
                                                            </div>
                                                            <!-- mt-overlay -->
                                                         </div>
                                                         <!-- mt-card-avatar -->
                                                         <div class="mt-card-content">
                                                            <h3 class="mt-card-name">Mushtaq Atif</h3>
                                                            <p class="mt-card-desc font-grey-mint">GS-ID: <strong>10-102</strong> (A-GRD)</p>
                                                         </div>
                                                         <!-- mt-card-content -->
                                                      </div>
                                                      <!-- mt-card-item -->
                                                   </div>
                                                   <!-- col-md-3 -->
                                                   <div class="col-md-3">
                                                      <div class="mt-card-item">
                                                         <div class="mt-card-avatar mt-overlay-4">
                                                            <img src="http://10.10.10.50/gsims/public/assets/photos/sis/500x500/student/2416.jpg" />
                                                            <div class="mt-overlay">
                                                               <h2>11-C <span class="font-yellow-lemon">(Jinnah)</span></h2>
                                                               <div class="mt-info font-white">
                                                                  <div class="mt-card-content">
                                                                     <p class="mt-card-desc font-white">GF-ID: <strong>16-249</strong> (1/3)</p>
                                                                     <div class="mt-card-social">
                                                                     </div>
                                                                  </div>
                                                               </div>
                                                            </div>
                                                            <!-- mt-overlay -->
                                                         </div>
                                                         <!-- mt-card-avatar -->
                                                         <div class="mt-card-content">
                                                            <h3 class="mt-card-name">Suleman Atif</h3>
                                                            <p class="mt-card-desc font-grey-mint">GS-ID: <strong>10-102</strong> (S-CFS)</p>
                                                         </div>
                                                         <!-- mt-card-content -->
                                                      </div>
                                                      <!-- mt-card-item -->
                                                   </div>
                                                   <!-- col-md-3 -->
                                                   <div class="col-md-3">
                                                      <div class="mt-card-item">
                                                         <div class="mt-card-avatar mt-overlay-4">
                                                            <img src="http://10.10.10.50/gsims/public/assets/photos/sis/500x500/student/494.jpg" />
                                                            <div class="mt-overlay">
                                                               <h2>Alumni</h2>
                                                               <div class="mt-info font-white">
                                                                  <div class="mt-card-content">
                                                                     <p class="mt-card-desc font-white">GF-ID: <strong>02-596</strong> (2/3)</p>
                                                                     <div class="mt-card-social">
                                                                     </div>
                                                                  </div>
                                                               </div>
                                                            </div>
                                                            <!-- mt-overlay -->
                                                         </div>
                                                         <!-- mt-card-avatar -->
                                                         <div class="mt-card-content">
                                                            <h3 class="mt-card-name">Mushtaq Atif</h3>
                                                            <p class="mt-card-desc font-grey-mint">GS-ID: <strong>10-102</strong> (A-GRD)</p>
                                                         </div>
                                                         <!-- mt-card-content -->
                                                      </div>
                                                      <!-- mt-card-item -->
                                                   </div>
                                                   <!-- col-md-3 -->
                                                </div>
                                                <!-- row -->
                                             </div>
                                             <!-- mt-element-card -->
                                          </div>
                                          <!-- portlet-body -->
                                       </div>
                                       <!-- portlet -->
                                    </div>
                                    <!-- col-md-12 -->
                                 </div>
                                 <!-- row -->
                              </div>
                              <!-- tab_children -->
                              <div class="tab-pane" id="tab_alternate">
                                 <table width="100%" border="0" class="table table-bordered">
                                    <thead class="bg-grey">
                                       <tr>
                                          <th class="text-center" width="40%">Next of Kin</th>
                                          <th class="text-center" width="20%">&nbsp;</th>
                                          <th class="text-center" width="40%">Emergency Contact</th>
                                       </tr>
                                    </thead>
                                    <tbody id="tab_alternate_contact">
                                       <tr>
                                          <td>Mrs Farida Ilyas</td>
                                          <td class="text-center"><strong>Name</strong></td>
                                          <td>Dr Altaf Ahmed</td>
                                       </tr>
                                       <tr>
                                          <td>E-33/1, Block-7, Gulshan-e-Iqbal, Karachi</td>
                                          <td class="text-center"><strong>Address</strong></td>
                                          <td>A- , Block-2, Gulshan-e-Iqbal, Karachi</td>
                                       </tr>
                                       <tr>
                                          <td></td>
                                          <td class="text-center"><strong>Email</strong></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>0300-8226220</td>
                                          <td class="text-center"><strong>Mobile</strong></td>
                                          <td>0300-8291947</td>
                                       </tr>
                                       <tr>
                                          <td>Mother</td>
                                          <td class="text-center"><strong>Relationship</strong></td>
                                          <td>Brother-in-Law</td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                              <!-- tab_alternate -->
                              <div class="tab-pane" id="tab_other">
                                 <div class="form-body">
                                    <h3 class="form-section marginTop0 headingBorderBottom">Other Details</h3>
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5">Provident Fund :</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold"> No </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5">NTN:</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold"> 42501-4559651-3 </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5">EOBI/SESSI number: </label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold"> 0100H477722 </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <h3 class="form-section headingBorderBottom">Bank Details</h3>
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5">Bank Name : </label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold"> Meezan Bank </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5">Branch :</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold"> Block-F, North Nazimabad </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5">Account Number :</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold"> 0001-3101-0026-0704 </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <h3 class="form-section headingBorderBottom">Takaful</h3>
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5">Self :</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold"> Yes </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5">Spouse :</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold"> Yes </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5">Children :</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold"> Yes </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class="control-label col-md-5">Certificate :</label>
                                             <div class="col-md-7">
                                                <p class="form-control-static bold"> - </p>
                                             </div>
                                          </div>
                                       </div>
                                       <!--/span-->
                                    </div>
                                    <!--/row-->
                                 </div>
                                 <!-- form-body -->
                              </div>
                              <!-- tab_other -->
                           </div>
                           <!-- tab-content -->
                        </div>
                        <!-- tabbable-line -->
                     </div>
                     <!-- tab_1_1 -->
                     <div class="tab-pane fade" id="tab_1_2">
                        <div class="summarySection col-md-12">
                           <div class="col-md-6 paddingRight0">
                              <div class="col-md-6 paddingLeft0">
                                 <div class="primaryReporting">
                                    <h4 class="PrimaryName"><span class="namePrimaryCode">KNN</span><span>Khadija Noorani</span></h4>
                                    <h5 class="PrimaryTopLine">Vice Principal</h5>
                                    <h5 class="PrimaryBottomLine">Starter & Junior Section</h5>
                                 </div>
                                 <!-- primaryReporting -->
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6 paddingRight0">
                                 <div class="reportingPersonal">
                                    <h4 class="PrimaryName"><span class="namePrimaryCode">SSD</span>Shoaib Siddiqui</h4>
                                    <h5 class="PrimaryTopLine">Coordinator, Academics</h5>
                                    <h5 class="PrimaryBottomLine">Starter Section</h5>
                                 </div>
                                 <!-- primaryReporting -->
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-6 -->
                           <div class="col-md-6 paddingLeft0">
                              <div class="col-md-6 paddingLeft0 paddingRight0">
                                 <h6 class="normalFont pull-right"><span class="leftLab3">Fundamental Reportees:</span> <strong>2</strong></h6>
                                 <h6 class="normalFont pull-right"><span class="leftLab3">Primary Reportees:</span> <strong>4</strong></h6>
                                 <h6 class="normalFont pull-right"><span class="leftLab3">Total Reportees:</span> <strong>5</strong></h6>
                                 <h6 class="normalFont pull-right"><span class="leftLab3">Total Members:</span> <strong>6</strong></h6>
                              </div>
                              <!-- -->
                              <div class="col-md-6 paddingLeft0 paddingRight0">
                                 <h6 class="normalFont pull-right"><span class="leftLab3">Class Role:</span> <strong>06-070</strong></h6>
                                 <h6 class="normalFont pull-right"><span class="leftLab3"> Total Teaching Roles:</span> <strong>06-070</strong></h6>
                                 <h6 class="normalFont pull-right"><span class="leftLab3">Total Teaching Blocks:</span> <strong>06-070</strong></h6>
                                 <h6 class="normalFont pull-right"><span class="leftLab3">Total Teaching Students:</span> <strong>06-070</strong></h6>
                                 <h6 class="normalFont pull-right"><span class="leftLab3">Total Unique Students:</span> <strong>06-070</strong></h6>
                                 <h6 class="normalFont pull-right"><span class="leftLab3">Total Student Blocks:</span> <strong>06-070</strong></h6>
                              </div>
                              <!-- -->
                           </div>
                           <!-- col-md-6 -->
                        </div>
                        <!-- summarySection -->
                        <hr style="margin-top: 5px;" />
                        <div class="TimingSection col-md-12">
                           <div class="col-md-3 paddingLeft0 text-center ">
                              <h5>Timing Profile & Hours</h5>
                              <table width="100%" border="0" class="TimingSectionTable">
                                 <tr>
                                    <td colspan="2">&nbsp;</td>
                                 </tr>
                                 <tr>
                                    <td colspan="2">Timing Profile</td>
                                 </tr>
                                 <tr>
                                    <td colspan="2">
                                       <h4 style="margin:0;font-size:16px;">Heads</h4>
                                    </td>
                                 </tr>
                                 <tr>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                 </tr>
                                 <tr>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                 </tr>
                                 <tr>
                                    <td colspan="2">Average Weekly Hours</td>
                                 </tr>
                                 <tr>
                                    <td colspan="2">
                                       <h4 style="margin:0;font-size:16px;">53:00</h4>
                                    </td>
                                 </tr>
                                 <tr>
                                    <td colspan="2">&nbsp;</td>
                                 </tr>
                              </table>
                           </div>
                           <!-- col-md-3 -->
                           <div class="col-md-3 paddingLeft0 text-center">
                              <h5>Full Time Parameters</h5>
                              <table width="100%" border="0" class="TimingSectionTable">
                                 <tr>
                                    <td colspan="2">&nbsp;</td>
                                 </tr>
                                 <tr>
                                    <td class="text-left">Standard IN</td>
                                    <td class="text-right"><strong>07:30</strong></td>
                                 </tr>
                                 <tr>
                                    <td class="text-left">Standard OUT</td>
                                    <td class="text-right"><strong>15:30</strong></td>
                                 </tr>
                                 <tr>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                 </tr>
                                 <tr>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                 </tr>
                                 <tr>
                                    <td class="text-left">Friday OUT</td>
                                    <td class="text-right"><strong>14:30</strong></td>
                                 </tr>
                                 <tr>
                                    <td class="text-left">Saturday Hrs</td>
                                    <td class="text-right"><strong>5.0</strong></td>
                                 </tr>
                                 <tr>
                                    <td colspan="2">&nbsp;</td>
                                 </tr>
                              </table>
                           </div>
                           <!-- col-md-3 -->
                           <div class="col-md-3 paddingLeft0 text-center">
                              <h5>Secondary Parameters</h5>
                              <table width="100%" border="0" class="TimingSectionTable">
                                 <tr>
                                    <td colspan="2">&nbsp;</td>
                                 </tr>
                                 <tr>
                                    <td class="text-left">Sat's Working</td>
                                    <td class="text-right"><strong>2</strong></td>
                                 </tr>
                                 <tr>
                                    <td class="text-left">Sat's Off</td>
                                    <td class="text-right"><strong>-</strong></td>
                                 </tr>
                                 <tr>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                 </tr>
                                 <tr>
                                    <td class="text-left">Ext. Out</td>
                                    <td class="text-right"><strong>15:30</strong></td>
                                 </tr>
                                 <tr>
                                    <td class="text-left">Ext. FREQ</td>
                                    <td class="text-right"><strong>2</strong></td>
                                 </tr>
                                 <tr>
                                    <td class="text-left">July Category</td>
                                    <td class="text-right"><strong>W2</strong></td>
                                 </tr>
                                 <tr>
                                    <td colspan="2">&nbsp;</td>
                                 </tr>
                              </table>
                           </div>
                           <!-- col-md-3 -->
                           <div class="col-md-3 paddingLeft0 text-center">
                              <h5>Custom Timings</h5>
                              <table width="100%" border="0" class="TimingSectionTable">
                                 <tr>
                                    <td colspan="3">&nbsp;</td>
                                 </tr>
                                 <tr>
                                    <td>Mon</td>
                                    <td><strong>07:00</strong></td>
                                    <td><strong>14:00</strong></td>
                                 </tr>
                                 <tr>
                                    <td>Tue</td>
                                    <td><strong>07:00</strong></td>
                                    <td><strong>14:00</strong></td>
                                 </tr>
                                 <tr>
                                    <td>Wed</td>
                                    <td><strong>07:00</strong></td>
                                    <td><strong>14:00</strong></td>
                                 </tr>
                                 <tr>
                                    <td>Thu</td>
                                    <td><strong>07:00</strong></td>
                                    <td><strong>14:00</strong></td>
                                 </tr>
                                 <tr>
                                    <td>Fri</td>
                                    <td><strong>07:00</strong></td>
                                    <td><strong>14:00</strong></td>
                                 </tr>
                                 <tr>
                                    <td>Sat</td>
                                    <td><strong>07:00</strong></td>
                                    <td><strong>14:00</strong></td>
                                 </tr>
                                 <tr>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                 </tr>
                              </table>
                           </div>
                           <!-- col-md-3 -->
                        </div>
                        <!-- TimingSection -->
                        <hr style="margin-top: 5px;" />
                        <div class="MatrixRolesSection">
                           <h4 class="col-md-6 col-md-offset-3 text-center MatrixRoles">Matrix Role(s) <small>for Classes and Groups</small></h4>
                           <div class="col-md-12 paddingBottom40">
                              <div class="col-md-6 col-md-offset-3 paddingLeft0 paddingRight0">
                                 <table width="100%" border="0" class="FunDaMentalReporting">
                                    <tr>
                                       <td class="text-center FunRep">FR</td>
                                       <td class="text-center ClassTeach">CLT</td>
                                       <td class="text-center ClassHere">IV-G</td>
                                       <td class="text-center ClassSectionHere">IV-CLT-0-G</td>
                                       <td class="text-center StuStrength">28</td>
                                       <td class="text-center TopBottomLine">YT, Grade IV<br />Sadia Ashar</td>
                                       <td class="text-center ReportingCodeName">SAS</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap" style="border:1px solid #000;">
                                    <tr>
                                       <td class="text-center SRNO">2</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                       <td class="text-center FunRep">FR</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">14</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">3</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                       <td class="text-center FunRep White"></td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">15</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">4</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                       <td class="text-center FunRep White"></td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">16</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">5</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                       <td class="text-center FunRep White"></td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">17</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">6</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                       <td class="text-center FunRep White"></td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">18</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">7</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                       <td class="text-center FunRep White"></td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">19</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">8</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                       <td class="text-center FunRep White"></td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">20</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">9</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                       <td class="text-center FunRep White"></td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">21</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">10</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                       <td class="text-center FunRep White"></td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">22</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">11</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                       <td class="text-center FunRep White"></td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">23</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">12</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                       <td class="text-center FunRep White"></td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">24</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">13</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                       <td class="text-center FunRep White"></td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="0" class="FunDaMentalReportingChap">
                                    <tr>
                                       <td class="text-center SRNO">25</td>
                                       <td class="text-center SubjectName">X-PHYS-A-1</td>
                                       <td class="text-center StuStrength">29</td>
                                       <td class="text-center Blocks">3</td>
                                       <td class="text-center TopBottomLine">LT, Physics<br />Rukhsana Hai</td>
                                       <td class="text-center NameCodeHere">RHI</td>
                                       <td class="text-center RankHere">7</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                        </div>
                        <!-- MatrixRolesSection -->
                        <hr style="margin-top: 5px;" />
                        <div class="orgChartSection">
                           <h4 class="col-md-6 col-md-offset-3 text-center MatrixRoles">Org Chart Roles(s) <small>for Non-Classroom Roles</small> | Role 1</h4>
                           <?php /* ?><?php */ ?>
                           <div class="no-padding col-md-10 col-md-offset-1">
                              <div class="blackSolidBorder">&nbsp;</div>
                              <div class="graySolidBorder">&nbsp;</div>
                              <div class="grayDashedBorder">&nbsp;</div>
                              <div class="col-md-12 ">
                                 <div class="col-md-6 text-center">
                                    <table width="100%" border="1" class="secondLevelReporting">
                                       <tr>
                                          <td colspan="3">
                                             <h5>PRIMARY GRANDREPORTOO</h5>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td width="30%" height="40">JN-T001</td>
                                          <td width="30%">OPQ</td>
                                          <td width="30%">2</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30">Vice Principal, Junior Section</td>
                                       </tr>
                                       <tr>
                                          <td height="40">GT 10-567</td>
                                          <td colspan="2">KHN</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30">Khadija Noorani</td>
                                       </tr>
                                    </table>
                                 </div>
                                 <!-- col-md-6 -->
                                 <div class="col-md-6 text-center">
                                    <table width="100%" border="1" class="secondLevelReporting">
                                       <tr>
                                          <td colspan="3">
                                             <h5>SECONDARY GRANDREPORTOO</h5>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td width="30%" height="40">JN-T001</td>
                                          <td width="30%">OPQ</td>
                                          <td width="30%">2</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30">Vice Principal, Junior Section</td>
                                       </tr>
                                       <tr>
                                          <td height="40">GT 10-567</td>
                                          <td colspan="2">KHN</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30">Khadija Noorani</td>
                                       </tr>
                                    </table>
                                 </div>
                                 <!-- col-md-6 -->
                              </div>
                              <!-- col-md-12 -->
                              <div class="col-md-12 paddingTop50">
                                 <div class="col-md-6 text-center">
                                    <table width="100%" border="1" class="firstLevelReporting">
                                       <tr>
                                          <td colspan="3">
                                             <h5>PRIMARY REPORTOO</h5>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td width="30%" height="40" bgcolor="#e5d998">JN-T001</td>
                                          <td width="30%" bgcolor="#ffff00">OPQ</td>
                                          <td width="30%" bgcolor="#ffff00">2</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30" bgcolor="#e5d998">Vice Principal, Junior Section</td>
                                       </tr>
                                       <tr>
                                          <td height="40" bgcolor="#f4ecfd">GT 10-567</td>
                                          <td colspan="2" bgcolor="#f4ecfd">KHN</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30" bgcolor="#f4ecfd">Khadija Noorani</td>
                                       </tr>
                                    </table>
                                 </div>
                                 <!-- col-md-6 -->
                                 <div class="col-md-6 text-center">
                                    <table width="100%" border="1" class="firstLevelReporting">
                                       <tr>
                                          <td colspan="3">
                                             <h5>SECONDARY REPORTOO</h5>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td width="30%" height="40">JN-T001</td>
                                          <td width="30%">OPQ</td>
                                          <td width="30%">2</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30">Vice Principal, Junior Section</td>
                                       </tr>
                                       <tr>
                                          <td height="40">GT 10-567</td>
                                          <td colspan="2">KHN</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30">Khadija Noorani</td>
                                       </tr>
                                    </table>
                                 </div>
                                 <!-- col-md-6 -->
                              </div>
                              <!-- col-md-12 -->
                              <div class="col-md-12 paddingTop50">
                                 <div class="col-md-6 col-md-offset-3 text-center" style="background:#e2e2e2;padding:15px;">
                                    <table width="100%" border="1" bgcolor="#fff" class="firstLevelReporting" style="background:#fff;" >
                                       <tr>
                                          <td bgcolor="#ade4f2">
                                             <h5 style="color:#;">FR</h5>
                                          </td>
                                          <td colspan="2" bgcolor="#ade4f2">
                                             <h5>ROLE A</h5>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td width="30%" height="40" bgcolor="#e5d998">JN-B-01</td>
                                          <td width="30%" bgcolor="#ffff00">OPQ</td>
                                          <td width="30%" bgcolor="#ffff00">4</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30" bgcolor="#e5d998">Headmistress, Junior Section</td>
                                       </tr>
                                       <tr>
                                          <td height="40" bgcolor="#ade4f2">ZHA-A</td>
                                          <td colspan="2" bgcolor="#f4ecfd">Zillehuma Asif</td>
                                       </tr>
                                    </table>
                                 </div>
                                 <!-- col-md-6 -->
                              </div>
                              <!-- col-md-12 -->
                              <div class="col-md-12 paddingTop50">
                                 <div class="col-md-6 col-md-offset-3 text-center" style="background:none;padding:15px;">
                                    <table width="100%" border="1">
                                       <tr>
                                          <td colspan="2" width="33%" height="90">
                                             Fundamental<br />Primary<br />
                                             <h5>06</h5>
                                          </td>
                                          <td colspan="2" width="33%" height="90">
                                             Total<br />Primary<br />
                                             <h5>06</h5>
                                          </td>
                                          <td colspan="2" width="33%" height="90">
                                             Total<br />Reportee<br />
                                             <h5>06</h5>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" width="50%"  height="80">
                                             Total Staff<br />Members<br />
                                             <h5>200</h5>
                                          </td>
                                          <td colspan="3" width="50%"  height="80">
                                             Total Student<br />Members<br />
                                             <h5>1382</h5>
                                          </td>
                                       </tr>
                                    </table>
                                 </div>
                                 <!-- col-md-6 -->
                              </div>
                              <!-- col-md-12 -->
                           </div>
                           <!-- col-md-12 -->
                           <hr class="smallHR" />
                           <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td bgcolor="#f5f5f5">1</td>
                                       <td bgcolor="#f5f5f5">P</td>
                                       <td bgcolor="#f4ecfd"><strong>Rakhshanda Ovais</strong></td>
                                       <td bgcolor="#ade4f2">ROV-B</td>
                                       <td bgcolor="#ade4f2">3 (25)</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#ffff00">IND</td>
                                       <td bgcolor="#ffff00">(ARS)</td>
                                       <td bgcolor="#e5d998">Headmistress</td>
                                       <td colspan="2" bgcolor="#e5d998">N-ML-M01</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td bgcolor="#f5f5f5">1</td>
                                       <td bgcolor="#f5f5f5">P</td>
                                       <td bgcolor="#f4ecfd"><strong>Rakhshanda Ovais</strong></td>
                                       <td bgcolor="#ade4f2">ROV-B</td>
                                       <td bgcolor="#ade4f2">3 (25)</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#ffff00">IND</td>
                                       <td bgcolor="#ffff00">(ARS)</td>
                                       <td bgcolor="#e5d998">Headmistress</td>
                                       <td colspan="2" bgcolor="#e5d998">N-ML-M01</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td bgcolor="#f5f5f5">1</td>
                                       <td bgcolor="#f5f5f5">P</td>
                                       <td bgcolor="#f4ecfd"><strong>Rakhshanda Ovais</strong></td>
                                       <td bgcolor="#ade4f2">ROV-B</td>
                                       <td bgcolor="#ade4f2">3 (25)</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#ffff00">IND</td>
                                       <td bgcolor="#ffff00">(ARS)</td>
                                       <td bgcolor="#e5d998">Headmistress</td>
                                       <td colspan="2" bgcolor="#e5d998">N-ML-M01</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td bgcolor="#f5f5f5">1</td>
                                       <td bgcolor="#f5f5f5">P</td>
                                       <td bgcolor="#f4ecfd"><strong>Rakhshanda Ovais</strong></td>
                                       <td bgcolor="#ade4f2">ROV-B</td>
                                       <td bgcolor="#ade4f2">3 (25)</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#ffff00">IND</td>
                                       <td bgcolor="#ffff00">(ARS)</td>
                                       <td bgcolor="#e5d998">Headmistress</td>
                                       <td colspan="2" bgcolor="#e5d998">N-ML-M01</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                        </div>
                        <!-- orgChartSection -->
                        <hr style="margin-top: 5px;" />
                        <div class="orgChartSection">
                           <h4 class="col-md-6 col-md-offset-3 text-center MatrixRoles">Org Chart Roles(s) <small>for Non-Classroom Roles</small> | Role 2</h4>
                           <?php /* ?><?php */ ?>
                           <div class="no-padding col-md-10 col-md-offset-1">
                              <div class="blackSolidBorder">&nbsp;</div>
                              <div class="graySolidBorder">&nbsp;</div>
                              <div class="grayDashedBorder">&nbsp;</div>
                              <div class="col-md-12 ">
                                 <div class="col-md-6 text-center">
                                    <table width="100%" border="1" class="secondLevelReporting">
                                       <tr>
                                          <td colspan="3">
                                             <h5>PRIMARY GRANDREPORTOO</h5>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td width="30%" height="40">JN-T001</td>
                                          <td width="30%">OPQ</td>
                                          <td width="30%">2</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30">Vice Principal, Junior Section</td>
                                       </tr>
                                       <tr>
                                          <td height="40">GT 10-567</td>
                                          <td colspan="2">KHN</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30">Khadija Noorani</td>
                                       </tr>
                                    </table>
                                 </div>
                                 <!-- col-md-6 -->
                                 <div class="col-md-6 text-center">
                                    <table width="100%" border="1" class="secondLevelReporting">
                                       <tr>
                                          <td colspan="3">
                                             <h5>SECONDARY GRANDREPORTOO</h5>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td width="30%" height="40">JN-T001</td>
                                          <td width="30%">OPQ</td>
                                          <td width="30%">2</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30">Vice Principal, Junior Section</td>
                                       </tr>
                                       <tr>
                                          <td height="40">GT 10-567</td>
                                          <td colspan="2">KHN</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30">Khadija Noorani</td>
                                       </tr>
                                    </table>
                                 </div>
                                 <!-- col-md-6 -->
                              </div>
                              <!-- col-md-12 -->
                              <div class="col-md-12 paddingTop50">
                                 <div class="col-md-6 text-center">
                                    <table width="100%" border="1" class="firstLevelReporting">
                                       <tr>
                                          <td colspan="3">
                                             <h5>PRIMARY REPORTOO</h5>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td width="30%" height="40" bgcolor="">JN-T001</td>
                                          <td width="30%" >OPQ</td>
                                          <td width="30%" >2</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30" bgcolor="">Vice Principal, Junior Section</td>
                                       </tr>
                                       <tr>
                                          <td height="40" >GT 10-567</td>
                                          <td colspan="2" bgcolor="#d1fbfb" ><strong>KHN</strong></td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30">Khadija Noorani</td>
                                       </tr>
                                    </table>
                                 </div>
                                 <!-- col-md-6 -->
                                 <div class="col-md-6 text-center">
                                    <table width="100%" border="1" class="firstLevelReporting">
                                       <tr>
                                          <td colspan="3">
                                             <h5>SECONDARY REPORTOO</h5>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td width="30%" height="40">JN-T001</td>
                                          <td width="30%">OPQ</td>
                                          <td width="30%">2</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30">Vice Principal, Junior Section</td>
                                       </tr>
                                       <tr>
                                          <td height="40">GT 10-567</td>
                                          <td colspan="2">KHN</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30">Khadija Noorani</td>
                                       </tr>
                                    </table>
                                 </div>
                                 <!-- col-md-6 -->
                              </div>
                              <!-- col-md-12 -->
                              <div class="col-md-12 paddingTop50">
                                 <div class="col-md-6 col-md-offset-3 text-center" style="background:#e2e2e2;padding:15px;">
                                    <table width="100%" border="1" bgcolor="#fff" class="firstLevelReporting" style="background:#fff;" >
                                       <tr>
                                          <td colspan="3" bgcolor="">
                                             <h5>ROLE 2</h5>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td width="30%" height="40" bgcolor="">JN-B-01</td>
                                          <td width="30%" bgcolor="">OPQ</td>
                                          <td width="30%" bgcolor="">4</td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" height="30" bgcolor="">Headmistress, Junior Section</td>
                                       </tr>
                                       <tr>
                                          <td height="40" bgcolor="">ZHA-A</td>
                                          <td colspan="2" bgcolor="">Zillehuma Asif</td>
                                       </tr>
                                    </table>
                                 </div>
                                 <!-- col-md-6 -->
                              </div>
                              <!-- col-md-12 -->
                              <div class="col-md-12 paddingTop50">
                                 <div class="col-md-6 col-md-offset-3 text-center" style="background:none;padding:15px;">
                                    <table width="100%" border="1">
                                       <tr>
                                          <td colspan="2" width="33%" height="90">
                                             Fundamental<br />Primary<br />
                                             <h5>06</h5>
                                          </td>
                                          <td colspan="2" width="33%" height="90">
                                             Total<br />Primary<br />
                                             <h5>06</h5>
                                          </td>
                                          <td colspan="2" width="33%" height="90">
                                             Total<br />Reportee<br />
                                             <h5>06</h5>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td colspan="3" width="50%"  height="80">
                                             Total Staff<br />Members<br />
                                             <h5>200</h5>
                                          </td>
                                          <td colspan="3" width="50%"  height="80">
                                             Total Student<br />Members<br />
                                             <h5>1382</h5>
                                          </td>
                                       </tr>
                                    </table>
                                 </div>
                                 <!-- col-md-6 -->
                              </div>
                              <!-- col-md-12 -->
                           </div>
                           <!-- col-md-12 -->
                           <hr class="smallHR" />
                           <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                           <div class="col-md-12 paddingLeft0 paddingRight0 paddingBottom20">
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                              <div class="col-md-6">
                                 <table width="100%" border="1" class="text-center" style="height:70px;color:#000;">
                                    <tr>
                                       <td width="15%" bgcolor="#f5f5f5">1</td>
                                       <td width="15%" bgcolor="#f5f5f5">P</td>
                                       <td width="15%" bgcolor="">INDIR</td>
                                       <td width="15%" bgcolor="">ARS</td>
                                       <td width="40%" bgcolor="#f5f5f5">Admin Coordinator</td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="#e1e1e1" colspan="2">MULTI(4)</td>
                                       <td bgcolor="#e1e1e1">16 (300)</td>
                                       <td bgcolor="#f5f5f5"><strong>MNH</strong></td>
                                       <td colspan="" bgcolor="#f5f5f5">Mehmood Hussain</td>
                                    </tr>
                                 </table>
                              </div>
                              <!-- col-md-6 -->
                           </div>
                           <!-- col-md-12 -->
                        </div>
                        <!-- orgChartSection -->
                     </div>
                     <!-- tab_1_2 -->
                     <?php /* ?>
                     <div class="tab-pane fade" id="tab_1_3">
                        <h4 class="text-center bold marginTop20"><i class="icon-user-following"></i>&nbsp;&nbsp; Admin/SIS/Tamkeen</h4>
                        <div class="row list-separated profile-stat" style="padding-top:12px;">
                           <div class="col-md-2 col-sm-2 col-xs-6">
                              <div class="uppercase profile-stat-title"> 07:00 AM </div>
                              <div class="uppercase profile-stat-text"> Standard IN </div>
                           </div>
                           <div class="col-md-2 col-sm-2 col-xs-6">
                              <div class="uppercase profile-stat-title"> 04:00 PM </div>
                              <div class="uppercase profile-stat-text"> Standard OUT </div>
                           </div>
                           <div class="col-md-2 col-sm-2 col-xs-6">
                              <div class="uppercase profile-stat-title"> 04:00 PM </div>
                              <div class="uppercase profile-stat-text"> Friday OUT </div>
                           </div>
                           <div class="col-md-2 col-sm-2 col-xs-6">
                              <div class="uppercase profile-stat-title"> 4.5 </div>
                              <div class="uppercase profile-stat-text"> Saturday Hours </div>
                           </div>
                           <div class="col-md-2 col-sm-2 col-xs-6">
                              <div class="uppercase profile-stat-title"> 2 </div>
                              <div class="uppercase profile-stat-text"> Off Saturdays </div>
                           </div>
                           <div class="col-md-2 col-sm-2 col-xs-6">
                              <div class="uppercase profile-stat-title"> 4.5 </div>
                              <div class="uppercase profile-stat-text"> Saturday Hours </div>
                           </div>
                        </div>
                        <h4 class="text-center marginTop20 bold">For the Month of July</h4>
                        <div class="row list-separated profile-stat" style="padding-top:12px;">
                           <div class="col-md-3 col-sm-3 col-xs-6">
                              <div class="uppercase profile-stat-title"> 2 </div>
                              <div class="uppercase profile-stat-text"> Late(s) </div>
                           </div>
                           <div class="col-md-3 col-sm-3 col-xs-6">
                              <div class="uppercase profile-stat-title"> 1 </div>
                              <div class="uppercase profile-stat-text"> Casual Leaves </div>
                           </div>
                           <div class="col-md-3 col-sm-3 col-xs-6">
                              <div class="uppercase profile-stat-title"> 0 </div>
                              <div class="uppercase profile-stat-text"> Short Leaves </div>
                           </div>
                           <div class="col-md-3 col-sm-3 col-xs-6">
                              <div class="uppercase profile-stat-title"> 1 </div>
                              <div class="uppercase profile-stat-text"> Half Day </div>
                           </div>
                        </div>
                        <h4 class="text-center marginTop20 bold">Attendance Policy</h4>
                        <div class="row list-separated profile-stat" style="padding-top:12px;">
                           <div class="col-md-12">
                              <div class="contentArea">
                                 <div class="text-center col-md-12">
                                    <h4>Regularity & Punctuality</h4>
                                 </div>
                                 <div class="col-md-12">
                                    <ul class="policyList">
                                       <li>
                                          <strong>Late</strong>: Late time period = <a nref="#" class="editable">15</a> minutes from time In. Accumulation of <a nref="#" class="editable">4</a> late(s) in a <a nref="#" class="editable">quarter</a> is equivalent to one day ABSENCE
                                       </li>
                                       <li>
                                          <strong>Short Leave</strong> SL time period = <a href="#" class="editable">2</a> hours from time In or Out. Accumulation of <a nref="#" class="editable">3</a> SL is equivalent to <a nref="#" class="editable">1</a> day ABSENCE
                                       </li>
                                       <li>
                                          <strong>Half Day</strong>: HD period = More the <a href="#" class="editable">2</a> hours from time In or Out. Half day deduction / half CL will be adjusted.
                                       </li>
                                       <li>In  case of late arrival or absence, staff member needs to inform HR office,  respective Section Head/ HOD prior to <a href="#" class="editable">7:30am</a>.</li>
                                    </ul>
                                 </div>
                              </div>
                              <!-- contentArea -->
                           </div>
                           <!-- -->
                        </div>
                     </div>
                     <!-- tab_1_3 -->
                     <?php */ ?>
                     <div class="tab-pane fade" id="tab_1_3">
                        <div class="tabbable-line">
                           <ul class="nav nav-tabs" id="">
                              <li class="active">
                                 <a href="#tab_1_3_1" data-toggle="tab"> Policy </a>
                              </li>
                              <li>
                                 <a href="#tab_1_3_2" data-toggle="tab"> Absentia </a>
                              </li>
                              <li>
                                 <a href="#tab_1_3_3" data-toggle="tab"> Attendance Breakdown </a>
                              </li>
                              <li>
                                 <a href="#tab_1_3_4" data-toggle="tab"> Leave Applications </a>
                              </li>
                              <li>
                                 <a href="#tab_1_3_5" data-toggle="tab"> Exceptional Adjustments </a>
                              </li>
                              <li>
                                 <a href="#tab_1_3_6" data-toggle="tab"> Missed Tap Event </a>
                              </li>
                           </ul>
                           <div class="tab-content">
                              <div class="tab-pane fade active in" id="tab_1_3_1">
                                 <h4 class="text-center bold marginTop20"><i class="icon-user-following"></i>&nbsp;&nbsp; Admin/SIS/Tamkeen</h4>
                                 <div class="row list-separated profile-stat" style="padding-top:12px;">
                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                       <div class="uppercase profile-stat-title"> 07:00 AM </div>
                                       <div class="uppercase profile-stat-text"> Standard IN </div>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                       <div class="uppercase profile-stat-title"> 04:00 PM </div>
                                       <div class="uppercase profile-stat-text"> Standard OUT </div>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                       <div class="uppercase profile-stat-title"> 04:00 PM </div>
                                       <div class="uppercase profile-stat-text"> Friday OUT </div>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                       <div class="uppercase profile-stat-title"> 4.5 </div>
                                       <div class="uppercase profile-stat-text"> Saturday Hours </div>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                       <div class="uppercase profile-stat-title"> 2 </div>
                                       <div class="uppercase profile-stat-text"> Off Saturdays </div>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                       <div class="uppercase profile-stat-title"> 4.5 </div>
                                       <div class="uppercase profile-stat-text"> Saturday Hours </div>
                                    </div>
                                 </div>
                                 <h4 class="text-center marginTop20 bold">For the Month of July</h4>
                                 <div class="row list-separated profile-stat" style="padding-top:12px;">
                                    <div class="col-md-3 col-sm-3 col-xs-6">
                                       <div class="uppercase profile-stat-title"> 2 </div>
                                       <div class="uppercase profile-stat-text"> Late(s) </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-6">
                                       <div class="uppercase profile-stat-title"> 1 </div>
                                       <div class="uppercase profile-stat-text"> Casual Leaves </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-6">
                                       <div class="uppercase profile-stat-title"> 0 </div>
                                       <div class="uppercase profile-stat-text"> Short Leaves </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-6">
                                       <div class="uppercase profile-stat-title"> 1 </div>
                                       <div class="uppercase profile-stat-text"> Half Day </div>
                                    </div>
                                 </div>
                                 <h4 class="text-center marginTop20 bold">Attendance Policy</h4>
                                 <div class="row list-separated profile-stat" style="padding-top:12px;">
                                    <div class="col-md-12">
                                       <div class="contentArea">
                                          <div class="text-center col-md-12">
                                             <h4>Regularity & Punctuality</h4>
                                          </div>
                                          <div class="col-md-12">
                                             <ul class="policyList">
                                                <li>
                                                   <strong>Late</strong>: Late time period = <a nref="#" class="editable">15</a> minutes from time In. Accumulation of <a nref="#" class="editable">4</a> late(s) in a <a nref="#" class="editable">quarter</a> is equivalent to one day ABSENCE
                                                </li>
                                                <li>
                                                   <strong>Short Leave</strong> SL time period = <a href="#" class="editable">2</a> hours from time In or Out. Accumulation of <a nref="#" class="editable">3</a> SL is equivalent to <a nref="#" class="editable">1</a> day ABSENCE
                                                </li>
                                                <li>
                                                   <strong>Half Day</strong>: HD period = More the <a href="#" class="editable">2</a> hours from time In or Out. Half day deduction / half CL will be adjusted.
                                                </li>
                                                <li>In  case of late arrival or absence, staff member needs to inform HR office,  respective Section Head/ HOD prior to <a href="#" class="editable">7:30am</a>.</li>
                                             </ul>
                                          </div>
                                       </div>
                                       <!-- contentArea -->
                                    </div>
                                    <!-- -->
                                 </div>
                              </div>
                              <!-- tab_1_3_1 -->
                              <div class="tab-pane" id="tab_1_3_2">
                                 <div class="portlet light bordered padding0 marginBottom0">
                                    <div class="portlet-title">
                                       <div class="caption">
                                          <i class="icon-users font-dark"></i>
                                          <span class="caption-subject font-dark sbold uppercase">Absentia </span>
                                       </div>
                                       <div class="actions">
                                          <div class="btn-group btn-group-devided" data-toggle="buttons">
                                             <!-- <input type="radio" name="options" class="toggle" id="profileDefinationAdd">Add New Profile</label> -->
                                             <button class="tooltips btn btn-transparent dark btn-outline btn-circle btn-sm" data-placement="bottom" data-original-title="Add Absentia" data-toggle="modal" href="#AddAIA" id="">Add Absentia</button>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- portlet-title -->
                                    <div class="portlet-body" style="padding:15px;">
                                       <table width="100%" border="0" class="table table-striped table-hover table-bordered" id="absentia_table">
                                          <thead>
                                             <tr>
                                                <th width="15%">Title</th>
                                                <th width="15%">Date</th>
                                                <th width="15%">From <small>(time)</small></th>
                                                <th width="15%">To <small>(time)</small></th>
                                                <th width="30%">Description</th>
                                                <th width="30%">Action</th>
                                             </tr>
                                          </thead>
                                          <tbody>
                                          </tbody>
                                       </table>
                                    </div>
                                    <!-- portlet-body -->
                                    <div class="modal fade" id="AddAIA" tabindex="-1" role="basic" aria-hidden="true">
                                       <div class="modal-dialog">
                                          <div class="modal-content">
                                             <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                                <h3 class="modal-title">Add Absentia</h3>
                                             </div>
                                             <div class="modal-body" style="float:left;width:100%;">
                                                <div class="portlet box blue-hoki">
                                                   <div class="portlet-title">
                                                      <div class="caption">
                                                         <i class="fa fa-user"></i><font id="selected_individuals">Attendance in Absentia form</font>
                                                      </div>
                                                   </div>
                                                   <!-- portlet-title -->
                                                   <div class="headRightDetailsInner">
                                                      <table>
                                                         <tbody>
                                                            <tr id="">
                                                               <td class="" style="padding-right:10px;">
                                                                  <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
                                                               </td>
                                                               <td class="staffView_StaffName">
                                                                  <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
                                                               </td>
                                                            </tr>
                                                         </tbody>
                                                      </table>
                                                      <!-- col-md-4 -->
                                                   </div>
                                                   <div class="portlet-body fixedHeightmodalPortlet">
                                                      <div class="form-body">
                                                         <div class="row">
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Title:</label>
                                                                  <div class="">
                                                                     <input type="text" class="form-control" name="" id="absentia_title" data-id="">
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Date:</label>
                                                                  <div class="">
                                                                     <input type="date" class="form-control" name="" id="absentia_date" data-id="">
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                         <div class="row">
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Start Time:</label>
                                                                  <div class="">
                                                                     <input type="time" class="form-control" name="" id="absentia_startTime" data-id="">
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">End Time:</label>
                                                                  <div class="">
                                                                     <input type="time" class="form-control" name="" id="absentia_endTime" data-id="">
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                         <div class="row">
                                                            <div class="col-md-12 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Description:</label>
                                                                  <div class="">
                                                                     <textarea id="absentia_description" cols="85" rows="5"></textarea>
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                      </div>
                                                      <!-- form-body -->
                                                   </div>
                                                   <!-- portlet-body fixedHeightmodalPortlet-->
                                                </div>
                                             </div>
                                             <div class="modal-footer text-center" style="text-align:center;">
                                                <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
                                                <button onclick="addAbsentia()" type="button" class="btn dark btn-outline active" data-dismiss="">Add</button>
                                                <!--button type="button" class="btn green">Add Badge</button -->
                                             </div>
                                          </div>
                                          <!-- /.modal-content -->
                                       </div>
                                       <!-- /.modal-dialog -->
                                    </div>
									
									
											
									<!-- Start Edit Absenia_id -->
									
									<div class="modal fade" id="AddAIAE" tabindex="-1" role="basic" aria-hidden="true">
										<input type="hidden" name="Edit_Absentia_id_hidden" id="Edit_Absentia_id_hidden" value="0" />
										<input type="hidden" name="Edit_Absentia_id_staff_id_hidden" id="Edit_Absentia_id_staff_id_hidden" value="0" />
										
										
                                       <div class="modal-dialog">
                                          <div class="modal-content">
                                             <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                                <h3 class="modal-title">Edit Absentia</h3>
                                             </div>
                                             <div class="modal-body" style="float:left;width:100%;">
                                                <div class="portlet box blue-hoki">
                                                   <div class="portlet-title">
                                                      <div class="caption">
                                                         <i class="fa fa-user"></i><font id="selected_individuals">Attendance in Absentia form</font>
                                                      </div>
                                                   </div>
                                                   <!-- portlet-title -->
                                                   <div class="headRightDetailsInner">
                                                      <table>
                                                         <tbody>
                                                            <tr id="">
                                                               <td class="" style="padding-right:10px;">
                                                                  <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
                                                               </td>
                                                               <td class="staffView_StaffName">
                                                                  <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
                                                               </td>
                                                            </tr>
                                                         </tbody>
                                                      </table>
                                                      <!-- col-md-4 -->
                                                   </div>
                                                   <div class="portlet-body fixedHeightmodalPortlet">
                                                      <div class="form-body" id="Absenia_Contents"> </div>
                                                      <!-- form-body -->
                                                   </div>
                                                   <!-- portlet-body fixedHeightmodalPortlet-->
                                                </div>
                                             </div>
                                             <div class="modal-footer text-center" style="text-align:center;">
                                                <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
                                                <button onclick="addAbsentiaE()" type="button" class="btn dark btn-outline active" data-dismiss="">Update</button>
                                                <!--button type="button" class="btn green">Add Badge</button -->
                                             </div>
                                          </div>
                                          <!-- /.modal-content -->
                                       </div>
                                       <!-- /.modal-dialog -->
                                    </div>
									
									
									
									<!-- End Edit Absenia_id-->
									
                                
									
                                 </div>
                                 <!-- portlet -->
                              </div>
                              <!-- tab_1_3_2 -->
                              <div class="tab-pane" id="tab_1_3_3">
                                <div class="portlet-body">
                                    
                                      <div class="row">
                                      <div id="datepaginator"> </div>
                                          <div class="col-md-12">
                                          
                                             <!-- BEGIN PORTLET-->
                                             <div class="portlet light form-fit bordered">
                                                <div class="portlet-title">
                                                   <div class="caption">
                                                      <i class="icon-settings font-dark"></i>
                                                      <span class="caption-subject font-dark sbold uppercase date_label">Attendance for <?php echo date('D F,d Y') ?></span>
                                                   </div>
                                                </div><!-- portlet-title -->
                                                <div class="portlet-body form">
                                                	<div class="opardiv"></div>
                                                   <form role="form" class="form-horizontal form-bordered">
                                                      <div class="form-body">
                                                         <div class="form-group">
                                                            <div class="col-md-3">
                                                               Expected Time
                                                            </div>
                                                            <div class="col-md-9" style="height: 84px;">
                                                               <!-- <input id="range_3" type="text" value="" /> -->
                                                               <div id="weeklySlider"></div>
                                                            </div>
                                                         </div>
                                                         <!-- form-group -->
                                                         <div class="form-group">
                                                            <div class="col-md-3">
                                                               Tap IN/OUT Attendance
                                                            </div>
                                                            <div class="col-md-9">
                                                               <div id="tapSlider"></div>
                                                               <!-- <input id="range_3_1" type="text" value="" /> -->
                                                            </div>
                                                         </div>
                                                         <!-- form-group -->
                                                         <div class="form-group">
                                                            <div class="col-md-3">
                                                               Absentia Attendance
                                                            </div>
                                                            <div class="col-md-9">
                                                               <!-- <input id="range_3_2" type="text" value="" /> -->
                                                               <div id="AiAabsentia"></div>
                                                            </div>
                                                         </div>
                                                         <!-- form-group -->
                                                         <div class="form-group">
                                                            <div class="col-md-3">
                                                               Buffer Time Utilization
                                                            </div>
                                                            <div class="col-md-9">
                                                               <!-- <input id="range_3_3" type="text" value="" /> -->
                                                               <div id="bufferTime"></div>
                                                            </div>
                                                         </div>
                                                         <!-- form-group -->
                                                         <div class="form-group">
                                                            <div class="col-md-3">
                                                               Payroll Attendance
                                                            </div>
                                                            <div class="col-md-9">
                                                               <!-- <input id="range_3_4" type="text" value="" /> -->
                                                               <div id="PayrollAttendance"></div>
                                                            </div>
                                                         </div>
                                                         <!-- form-group -->
                                                         <div class="form-group">
                                                            <div class="col-md-3">
                                                               Complaince
                                                            </div>
                                                            <div class="col-md-9">
                                                               <div class="col-md-2 text-center">
                                                                  <img src="img/complaint.png" width="24" class="compliance_one_img" /><br /><small>In Compliance</small>
                                                               </div>
                                                               <div class="col-md-8 text-center">
                                                                  <img src="img/noncomplaint.png" width="24" class="compliance_duration_img" /><br /><small>Duration Compliance</small>
                                                               </div>
                                                               <div class="col-md-2 text-center">
                                                                  <img src="img/complaint.png" width="24" class="compliance_two_img"  /><br /><small>Out Compliance</small>
                                                               </div>
                                                            </div>
                                                         </div>
                                                      </div>
                                                      <!-- form-body -->
                                                   </form>
                                                   <!-- form-horizontal -->
                                                   <div style="padding:10px 20px;">
                                                   <h4 class="text-center">Compensation & Proportion details</h4>
                                                   <table class="table table-striped table-hover table-bordered">
                                                      <thead style="background: #efefef;">
                                                         <tr>
                                                             <!--  <th width="25%" class="text-center">Attendance Complaince<br />Proportion</th> -->
                                                              <th width="33%" class="text-center">Non Compliant<br />Adjustment Factor</th>
                                                              <th width="33%" class="text-center">Attendance Compensation<br />Proportion</th>
                                                              <th width="34%" class="text-center">Attendance Deduction<br />Proportion</th>
                                                          </tr>
                                                      </thead>
                                                      <tbody>
                                                         <tr>
                                                            <!-- <td class="text-center">0.89</td> -->
                                                              <td class="text-center">0.8</td>
                                                              <td class="text-center factor_remaining_deduction"></td>
                                                              <td class="text-center factor_deduction_from"></td>
                                                          </tr>
                                                      </tbody>
                                                   </table>
                                                   
                                                   <h4 class="text-center">Leaves status & Buffer details</h4>
                                                   <table class="table table-striped table-hover table-bordered">
                                                      <thead style="background: #efefef;">
                                                         <tr>
                                                              <th width="25%" class="text-center">Previous EL<br />Balance</th>
                                                              <th width="25%" class="text-center">Current EL<br />Balance</th>
                                                              <th width="25%" class="text-center">Daily Buffer Used<br /><small class="daily_buffer_assign"></small></th>
                                                              <th width="25%" class="text-center">Monthly Buffer Used<br /><small class="monthly_buffer_assign"></small></th>
                                                          </tr>
                                                      </thead>
                                                      <tbody>
                                                         <tr>
                                                            <td class="text-center previous_el_balance"></td>
                                                              <td class="text-center current_el_balance"></td>
                                                              <td class="text-center daily_buffer_used" ><strong>0 min</strong> <small>/</small> <strong>5 min</strong></td>
                                                              <td class="text-center monthly_buffer_used"><strong>0 min</strong> <small>/</small> <strong>15 min</strong></td>
                                                          </tr>
                                                      </tbody>
                                                   </table>
                                                   </div>
                                                </div><!-- portlet-body -->
                                             </div><!-- portlet -->
                                             <!-- END PORTLET-->
                                          </div><!-- col-md-12 -->
                                      </div><!-- row -->
                                </div>
                              </div>
                              <!-- tab_1_3_3 -->
                              <div class="tab-pane" id="tab_1_3_4">
                                 <div class="portlet light bordered padding0">
                                    <div class="portlet-title">
                                       <div class="caption">
                                          <i class="icon-users font-dark"></i>
                                          <span class="caption-subject font-dark sbold uppercase"> Leave Applications </span>
                                       </div>
                                       <div class="actions">
                                          <div class="btn-group btn-group-devided" data-toggle="buttons">
                                             <!-- <input type="radio" name="options" class="toggle" id="profileDefinationAdd">Add New Profile</label> -->
                                             <button class="tooltips btn btn-transparent dark btn-outline btn-circle btn-sm" data-placement="bottom" data-original-title="Leave Application" data-toggle="modal" href="#LeaveApp" onClick="clearLeave()">Apply for Leave</button>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- portlet-title -->
                                    <div class="portlet-body" style="padding:15px;">
                                       <table width="100%" border="0" class="table table-striped table-hover table-bordered" id="leave_table">
                                          <thead>
                                             <tr>
                                                <th width="15%">Title <small>(type)</small></th>
                                                <th width="12%">Compensation</th>
                                                <th width="15%">From </th>
                                                <th width="13%">To </th>
                                                <th width="30%">Additional Comments</th>
                                                <th width="9%" class="text-center">Action</th>
                                             </tr>
                                          </thead>
                                          <tbody class="font-grey-mint">
										  
                                          </tbody>
                                       </table>
                                    </div>
									
                                    <!-- portlet-body -->
                                    <div class="modal fade" id="LeaveApproval" tabindex="-1" role="basic" aria-hidden="true">
                                       <div class="modal-dialog">
                                          <div class="modal-content">
                                             <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                                <h3 class="modal-title">Leave Application Approval</h3>
                                             </div>
                                             <div class="modal-body" style="float:left;width:100%;">
                                                <div class="portlet box blue-hoki">
                                                   <div class="portlet-title">
                                                      <div class="caption">
                                                         <i class="fa fa-user"></i><font id="">Leave Approval</font>
                                                      </div>
                                                   </div>
                                                   <!-- portlet-title -->
                                                   <div class="headRightDetailsInner">
                                                      <table>
                                                         <tbody>
                                                            <tr id="">
                                                               <td class="" style="padding-right:10px;">
                                                                  <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
                                                               </td>
                                                               <td class="staffView_StaffName">
                                                                  <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
                                                               </td>
                                                            </tr>
                                                         </tbody>
                                                      </table>
                                                      <!-- col-md-4 -->
                                                   </div>
                                                   <!-- headRightDetailsInner -->
                                                   <div class="portlet-body fixedHeightmodalPortlet">
                                                      <div class="form-body">
                                                         <div class="row">
                                                            <div class="col-md-12 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Leave Status</label>
                                                                  <div class="">
                                                                     <span class="switch-box">
                                                                     <input type="checkbox" data-on-text="Approve" data-off-text="Disapprove" id="change-color-switch" class="ck-in switch-box a1">
                                                                     </span>
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                         <div class="row">
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Leave Title:</label>
                                                                  <div class="">
                                                                     <input type="hidden" id="leave_title_id"/>
                                                                     <input type="text" class="form-control" id="leave_title_update"  disabled="disabled">
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Leave Type:</label>
                                                                  <div class="">
                                                                     <select class="form-control" id="leave_type_update">
                                                                     <option selected disabled value="0">Select Leave Type</option>
                                                                     @foreach($leaveType as $type)
                                                                        <option value="{{$type->id}}">{{$type->leave_type_name}}</option>
                                                                     @endforeach
                                                                     </select>
                                                                     <!-- select -->
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                         <div class="row">
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">From:</label>
                                                                  <div class="">
                                                                     <input type="date" class="form-control"  id="leave_from_update" data-id="" disabled="disabled">
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">To:</label>
                                                                  <div class="">
                                                                     <input type="date" class="form-control"  id="leave_to_update" data-id="" disabled="disabled">
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                         <div class="no-padding" id="approvedformShow" style="display:none;">
                                                            <div class="row">
                                                               <div class="col-md-6 paddingBottom10">
                                                                  <div class="form-group">
                                                                     <label class="">Approved From:</label>
                                                                     <div class="">
                                                                        <input type="date" class="form-control" id="approve_from">
                                                                     </div>
                                                                  </div>
                                                                  <!-- form-group -->
                                                               </div>
                                                               <!-- col-md-6 -->
                                                               <div class="col-md-6 paddingBottom10">
                                                                  <div class="form-group">
                                                                     <label class="">Approved To:</label>
                                                                     <div class="">
                                                                        <input type="date" class="form-control" id="approve_to">
                                                                     </div>
                                                                  </div>
                                                                  <!-- form-group -->
                                                               </div>
                                                               <!-- col-md-6 -->
                                                            </div>
                                                            <!-- row -->
                                                            <div class="row">
                                                               <div class="col-md-6 paddingBottom10">
                                                                  <div class="form-group">
                                                                     <label class="">Paid Compensation:</label>
                                                                     <div class="">
                                                                        <span class="switch-box">
                                                                        <input type="checkbox" data-on-text="Yes" data-off-text="No" id="changeSwitch" class="ck-in switch-box a1">
                                                                        </span>
                                                                     </div>
                                                                  </div>
                                                                  <!-- form-group -->
                                                               </div>
                                                               <!-- col-md-6 -->
                                                               <div class="col-md-6 paddingBottom10" id="paidField" style="display:none;">
                                                                  <div class="form-group">
                                                                     <label class="">Paid Percent:</label>
                                                                     <div class="input-group">
                                                                        <input type="number" class="form-control" id="paid_compensation_percentage">
                                                                        <span class="input-group-addon">
                                                                        <i class="fa fa-percent"></i>
                                                                        </span>
                                                                     </div>
                                                                  </div>
                                                                  <!-- form-group -->
                                                               </div>
                                                               <!-- col-md-6 -->
                                                            </div>
                                                            <!-- row -->
                                                         </div>
                                                         <div class="row">
                                                            <div class="col-md-12 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Additional Comments <small>(if any)</small>:</label>
                                                                  <div class="">
                                                                     <textarea id="leave_comment_update" cols="85" rows="5"></textarea>
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                      </div>
                                                      <!-- form-body -->
                                                   </div>
                                                   <!-- portlet-body fixedHeightmodalPortlet-->
                                                </div>
                                             </div>
                                             <div class="modal-footer text-center" style="text-align:center;">
                                                <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
                                                <button onClick="LeaveUpdateById()" type="button" class="btn dark btn-outline active" data-dismiss="">Submit</button>
                                                <!--button type="button" class="btn green">Add Badge</button -->
                                             </div>
                                          </div>
                                          <!-- /.modal-content -->
                                       </div>
                                       <!-- /.modal-dialog -->
                                    </div>
                                    
									
									<div class="modal fade" id="LeaveApp" tabindex="-1" role="basic" aria-hidden="true">
                                       <div class="modal-dialog">
                                          <div class="modal-content">
                                             <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                                <h3 class="modal-title">Leave Application</h3>
                                             </div>
                                             <div class="modal-body" style="float:left;width:100%;">
                                                <div class="portlet box blue-hoki">
                                                   <div class="portlet-title">
                                                      <div class="caption">
                                                         <i class="fa fa-user"></i><font id="">Leave form</font>
                                                      </div>
                                                   </div>
                                                   <!-- portlet-title -->
                                                   <div class="headRightDetailsInner">
                                                      <table>
                                                         <tbody>
                                                            <tr id="">
                                                               <td class="" style="padding-right:10px;">
                                                                  <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
                                                               </td>
                                                               <td class="staffView_StaffName">
                                                                  <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
                                                               </td>
                                                            </tr>
                                                         </tbody>
                                                      </table>
                                                      <!-- col-md-4 -->
                                                   </div>
                                                   <!-- headRightDetailsInner -->
                                                   <div class="portlet-body fixedHeightmodalPortlet">
                                                      <div class="form-body">
                                                         <div class="row">
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Leave Title:</label>
                                                                  <div class="">
                                                                     <input type="text" class="form-control" name="" id="leave_title" >
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Leave Type:</label>
                                                                  <div class="leave_type">
                                                                     <select class="form-control">
                                                                     <option selected disabled value="0">Select Leave Type</option>
                                                                     @foreach($leaveType as $type)
                                                                        <option value="{{$type->id}}">{{$type->leave_type_name}}</option>
                                                                     @endforeach
                                                                     </select>
                                                                     <!-- select -->
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                         <div class="row">
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">From:</label>
                                                                  <div class="">
                                                                     <input type="date" class="form-control" name="" id="leave_from">
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">To:</label>
                                                                  <div class="">
                                                                     <input type="date" class="form-control" name="" id="leave_to">
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                         <div class="row">
                                                            <div class="col-md-12 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Additional Comments <small>(if any)</small>:</label>
                                                                  <div class="">
                                                                     <textarea id="leave_comment" cols="85" rows="5"></textarea>
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                         <div class="row">
                                                            <div class="col-md-12 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Request for a paid Compensation</label>
                                                                  <div class="">
                                                                     <input type="checkbox" class="make-switch" data-on-text="Yes" data-off-text="No" id="limit">
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                      </div>
                                                      <!-- form-body -->
                                                   </div>
                                                   <!-- portlet-body fixedHeightmodalPortlet-->
                                                </div>
                                             </div>
                                             <div class="modal-footer text-center" style="text-align:center;">
                                                <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
                                                <button onClick="add_leave()" type="button" class="btn dark btn-outline active" data-dismiss="">Add</button>
                                                <!--button type="button" class="btn green">Add Badge</button -->
                                             </div>
                                          </div>
                                          <!-- /.modal-content -->
                                       </div>
                                       <!-- /.modal-dialog -->
                                    </div>
                                
		 <!-- Kashif Solangi Leave Application Edit Functionality Modal-->
								 
								 
								     <div class="modal fade" id="LeaveAppForEdit" tabindex="-1" role="basic" aria-hidden="true">
                                       <div class="modal-dialog">
                                          <div class="modal-content">
                                             <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                                <h3 class="modal-title">Leave Application</h3>
                                             </div>
                                             <div class="modal-body" style="float:left;width:100%;">
                                                <div class="portlet box blue-hoki">
                                                   <div class="portlet-title">
                                                      <div class="caption">
                                                         <i class="fa fa-user"></i><font id="">Leave form</font>
                                                      </div>
                                                   </div>
                                                   <!-- portlet-title -->
                                                   <div class="headRightDetailsInner">
                                                      <table>
                                                         <tbody>
                                                            <tr id="">
                                                               <td class="" style="padding-right:10px;">
                                                                  <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
                                                               </td>
                                                               <td class="staffView_StaffName">
                                                                  <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
                                                               </td>
                                                            </tr>
                                                         </tbody>
                                                      </table>
                                                      <!-- col-md-4 -->
                                                   </div>
                                                   <!-- headRightDetailsInner -->
                                                   <div class="portlet-body fixedHeightmodalPortlet">
                                                      <div class="form-body" id="Leave_main_containter">
                                                     </div>
                                                      <!-- form-body -->
                                                   </div>
                                                   <!-- portlet-body fixedHeightmodalPortlet-->
                                                </div>
                                             </div>
                                             <div class="modal-footer text-center" style="text-align:center;">
                                                <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
                                                <button onClick="edit_leave()" type="button" class="btn dark btn-outline active" data-dismiss=""> Update </button>
                                                <!--button type="button" class="btn green">Add Badge</button -->
                                             </div>
                                          </div>
                                          <!-- /.modal-content -->
                                       </div>
                                       <!-- /.modal-dialog -->
                                    </div>
									
									
									
									
								 <!-- End Kashi Solangi Leave Applicaiton Modal -->



								</div>
                                 <!-- portlet -->
                                 <div class="portlet light bordered padding0">
                                    <div class="portlet-title">
                                       <div class="caption">
                                          <i class="icon-users font-dark"></i>
                                          <span class="caption-subject font-dark sbold uppercase"> Unauthorized Leave Penalties </span>
                                       </div>
                                       <div class="actions">
                                          <div class="btn-group btn-group-devided" data-toggle="buttons">
                                             <!-- <input type="radio" name="options" class="toggle" id="profileDefinationAdd">Add New Profile</label> -->
                                             <button class="tooltips btn btn-transparent dark btn-outline btn-circle btn-sm" data-placement="bottom" data-original-title="Unauthorized Leave Penalty" data-toggle="modal" href="#UnAuthLeavePen" id="">Penalty</button>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- portlet-title -->
                                    <div class="portlet-body" style="padding:15px;">
                                       <table width="100%" border="0" class="table table-striped table-hover table-bordered" id="penaltyTable">
                                          <thead>
                                             <tr>
                                                 <th width="15%">Penalty Title</th>
                                                <th width="10%" scope="row">Penalty <br /> (no of days)</th>
                                                <th width="15%">From - To </th>
                                                <th width="15%">Timestamp </th>
                                                <th width="22%">Additional Comments</th>
												<th width="10%">Action</th>
                                             </tr>
                                          </thead>
                                          <tbody class="font-grey-mint">

                                          </tbody>
                                       </table>
                                    </div>
                                    <!-- portlet-body -->
                                    <div class="modal fade" id="UnAuthLeavePen" tabindex="-1" role="basic" aria-hidden="true">
                                       <div class="modal-dialog">
                                          <div class="modal-content">
                                             <!-- <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                                <h3 class="modal-title">Leave Application Approval</h3>
                                                </div> -->
                                             <div class="modal-body" style="float:left;width:100%;">
                                                <div class="portlet box blue-hoki">
                                                   <div class="portlet-title">
                                                      <div class="caption">
                                                         <i class="fa fa-user"></i><font id="">Penalty</font>
                                                      </div>
                                                   </div>
                                                   <!-- portlet-title -->
                                                   <div class="headRightDetailsInner">
                                                      <table>
                                                         <tbody>
                                                            <tr id="">
                                                               <td class="" style="padding-right:10px;">
                                                                  <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
                                                               </td>
                                                               <td class="staffView_StaffName">
                                                                  <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
                                                               </td>
                                                            </tr>
                                                         </tbody>
                                                      </table>
                                                      <!-- col-md-4 -->
                                                   </div>
                                                   <!-- headRightDetailsInner -->
                                                   <div class="portlet-body fixedHeightmodalPortlet">
                                                      <div class="form-body">
                                                         <div class="row">
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Penalty Title:</label>
                                                                  <div class="">
                                                                     <input type="text" class="form-control" name="" id="penalty_title">
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Penalty for <small>(no of days)</small>:</label>
                                                                  <div class="input-group">
                                                                     <input type="number" class="form-control" id="penalty_day">
                                                                     <span class="input-group-addon">
                                                                     <i class="fa fa-hashtag"></i>
                                                                     </span>
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                         <div class="row">
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Penalty from:</label>
                                                                  <div class="">
                                                                     <input type="date" class="form-control"  id="penalty_from">
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Penalty to:</label>
                                                                  <div class="">
                                                                     <input type="date" class="form-control" id="penalty_to">
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                         <div class="row">
                                                            <div class="col-md-12 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Information regarding Penalty:</label>
                                                                  <div class="">
                                                                     <textarea cols="85" rows="5" id="penalty_description"></textarea>
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                      </div>
                                                      <!-- form-body -->
                                                   </div>
                                                   <!-- portlet-body fixedHeightmodalPortlet-->
                                                </div>
                                             </div>
                                             <div class="modal-footer text-center" style="text-align:center;">
                                                <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
                                                <button onCLick="addPenalty()" type="button" class="btn dark btn-outline active" data-dismiss="">Submit</button>
                                                <!--button type="button" class="btn green">Add Badge</button -->
                                             </div>
                                          </div>
                                          <!-- /.modal-content -->
                                       </div>
                                       <!-- /.modal-dialog -->
                                    </div>
                                 
								 
								 
								 
								 
<!-- Edit Penalties -->
							<div class="modal fade" id="UnAuthLeavePenEdit" tabindex="-1" role="basic" aria-hidden="true">
							   <div class="modal-dialog">
								  <div class="modal-content">
									<div class="modal-body" style="float:left;width:100%;">
										<div class="portlet box blue-hoki">
										   <div class="portlet-title">
											  <div class="caption">
												 <i class="fa fa-user"></i><font id="">Penalty</font>
											  </div>
										   </div>
										   <div class="headRightDetailsInner">
											  <table>
												 <tbody>
													<tr id="">
													   <td class="" style="padding-right:10px;">
														  <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
													   </td>
													   <td class="staffView_StaffName">
														  <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
													   </td>
													</tr>
												 </tbody>
											  </table>
											  <!-- col-md-4 -->
										   </div>
										   <!-- headRightDetailsInner -->
										   <div class="portlet-body fixedHeightmodalPortlet">
											  <div class="form-body" id="Penalties_Contents">
												
											  </div>
										   </div>
										</div>
									 </div>
									 <div class="modal-footer text-center" style="text-align:center;">
										<button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
										<button onCLick="editPenalty()" type="button" class="btn dark btn-outline active" data-dismiss=""> Update </button>
									 </div>
								  </div>
							   </div>
							</div>
<!-- End Penalties -->							
								 

								 
								 
								 
								 </div>
                                 <!-- portlet -->
                              </div>
                              <!-- tab_1_3_4 -->
                              <div class="tab-pane" id="tab_1_3_5">
                                 <div class="portlet light bordered padding0">
                                    <div class="portlet-title">
                                       <div class="caption">
                                          <i class="icon-users font-dark"></i>
                                          <span class="caption-subject font-dark sbold uppercase"> Exceptional Adjustments </span>
                                       </div>
                                       <div class="actions">
                                          <div class="btn-group btn-group-devided" data-toggle="buttons">
                                             <!-- <input type="radio" name="options" class="toggle" id="profileDefinationAdd">Add New Profile</label> -->
                                             <button class="tooltips btn btn-transparent dark btn-outline btn-circle btn-sm" data-placement="bottom" data-original-title="Add Exceptional Adjustment" data-toggle="modal" href="#ExceptionalAdjustmentForm" onClick="clearAdjustment()">Adjustments</button>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- portlet-title -->
                                    <div class="portlet-body" style="padding:15px;">
                                       <table width="100%" border="0" class="table table-striped table-hover table-bordered" id="adjustment_table">
                                          <thead>
                                             <tr>
                                               <th width="15%">Adjustment Title</th>
                                                <th width="10%">Adjustment <br />(no of days)</th>
                                                <th width="15%">Timestamp </th>
                                                <th width="22%">Additional Comments</th>
												<th width="10%">Action</th>
                                             </tr>
                                          </thead>
                                          <tbody class="font-grey-mint">
										</tbody>
                                       </table>
                                    </div>
                                    <!-- portlet-body -->
                                    <div class="modal fade" id="ExceptionalAdjustmentForm" tabindex="-1" role="basic" aria-hidden="true">
                                       <div class="modal-dialog">
                                          <div class="modal-content">
                                             <!-- <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                                <h3 class="modal-title">Leave Application Approval</h3>
                                                </div> -->
                                             <div class="modal-body" style="float:left;width:100%;">
                                                <div class="portlet box blue-hoki">
                                                   <div class="portlet-title">
                                                      <div class="caption">
                                                         <i class="fa fa-user"></i><font id="">Adjustments</font>
                                                      </div>
                                                   </div>
                                                   <!-- portlet-title -->
                                                   <div class="headRightDetailsInner">
                                                      <table>
                                                         <tbody>
                                                            <tr id="">
                                                               <td class="" style="padding-right:10px;">
                                                                  <img class="user-pic rounded  absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="assets/photos/hcm/150x150/staff/782.png" width="42">
                                                               </td>
                                                               <td class="staffView_StaffName">
                                                                  <a href="javascript:;" class="primary-link absentia_staff_name tooltips" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="tooltips absentia_name_code" data-container="body" data-placement="top" data-original-title="a.hussain"></small><br><small class="shortHeight"><span class="tooltips absentia_bottom_line" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
                                                               </td>
                                                            </tr>
                                                         </tbody>
                                                      </table>
                                                      <!-- col-md-4 -->
                                                   </div>
                                                   <!-- headRightDetailsInner -->
                                                   <div class="portlet-body fixedHeightmodalPortlet">
                                                      <div class="form-body">
                                                         <div class="row">
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Title:</label>
                                                                  <div class="">
                                                                     <input type="text" class="form-control" name="" id="adjustment_title" >
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Adjustment for <small>(no of days)</small>:</label>
                                                                  <div class="input-group">
                                                                     <input type="number" class="form-control" id="adjustment_no">
                                                                     <span class="input-group-addon">
                                                                     <i class="fa fa-hashtag"></i>
                                                                     </span>
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                         <div class="row">
                                                            <div class="col-md-12 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Information regarding Adjustments:</label>
                                                                  <div class="">
                                                                     <textarea id="adjustment_description" cols="85" rows="5"></textarea>
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                      </div>
                                                      <!-- form-body -->
                                                   </div>
                                                   <!-- portlet-body fixedHeightmodalPortlet-->
                                                </div>
                                             </div>
                                             <div class="modal-footer text-center" style="text-align:center;">
                                                <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
                                                <button onClick="addAdjustment()" type="button" class="btn dark btn-outline active">Submit</button>
                                                <!--button type="button" class="btn green">Add Badge</button -->
                                             </div>
                                          </div>
                                          <!-- /.modal-content -->
                                       </div>
                                       <!-- /.modal-dialog -->
                                    </div>
                                 
								 
								 	
								     <!-- portlet-body -->
                                    <div class="modal fade" id="ExceptionalAdjustmentFormEdit" tabindex="-1" role="basic" aria-hidden="true">
                                       <div class="modal-dialog">
                                          <div class="modal-content">
                                            
                                             <div class="modal-body" style="float:left;width:100%;">
                                                <div class="portlet box blue-hoki">
                                                   <div class="portlet-title">
                                                      <div class="caption">
                                                         <i class="fa fa-user"></i><font id="">Adjustments</font>
                                                      </div>
                                                   </div>
                                                   <!-- portlet-title -->
                                                   <div class="headRightDetailsInner">
                                                      <table>
                                                         <tbody>
                                                            <tr id="">
                                                               <td class="" style="padding-right:10px;">
                                                                  <img class="user-pic rounded  absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="assets/photos/hcm/150x150/staff/782.png" width="42">
                                                               </td>
                                                               <td class="staffView_StaffName">
                                                                  <a href="javascript:;" class="primary-link absentia_staff_name tooltips" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="tooltips absentia_name_code" data-container="body" data-placement="top" data-original-title="a.hussain"></small><br><small class="shortHeight"><span class="tooltips absentia_bottom_line" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
                                                               </td>
                                                            </tr>
                                                         </tbody>
                                                      </table>
                                                      <!-- col-md-4 -->
                                                   </div>
                                                   <!-- headRightDetailsInner -->
                                                   <div class="portlet-body fixedHeightmodalPortlet">
                                                      <div class="form-body" id="Adjustment_Contents">
													  
                                                      
													  </div>
                                                      <!-- form-body -->
                                                   </div>
                                                   <!-- portlet-body fixedHeightmodalPortlet-->
                                                </div>
                                             </div>
                                             <div class="modal-footer text-center" style="text-align:center;">
                                                <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
                                                <button onClick="editAdjustment()" type="button" class="btn dark btn-outline active">Update</button>
                                                <!--button type="button" class="btn green">Add Badge</button -->
                                             </div>
                                          </div>
                                          <!-- /.modal-content -->
                                       </div>
                                       <!-- /.modal-dialog -->
                                    </div>
                                




								 
								 
								 </div>
                                 <!-- portlet -->
                              </div>
                              <!-- tab_1_3_5 -->
                              <div class="tab-pane" id="tab_1_3_6">
                                 <div class="portlet light bordered padding0">
                                    <div class="portlet-title">
                                       <div class="caption">
                                          <i class="icon-users font-dark"></i>
                                          <span class="caption-subject font-dark sbold uppercase"> Missed Tap Event </span>
                                       </div>
                                       <div class="actions">
                                          <div class="btn-group btn-group-devided" data-toggle="buttons">
                                             <!-- <input type="radio" name="options" class="toggle" id="profileDefinationAdd">Add New Profile</label> -->
                                             <button class="tooltips btn btn-transparent dark btn-outline btn-circle btn-sm" data-placement="bottom" data-original-title="Add Exceptional Adjustment" data-toggle="modal" href="#ManualAttendanceForm" onClick="clearManual()">Attendance</button>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- portlet-title -->
                                    <div class="portlet-body" style="padding:15px;">
									
									<input type="hidden" name="Missed_id" id="Missed_id" value="0" />
									<input type="hidden" name="Table_name" id="Table_name" value="0" />
									
                                       <table width="100%" border="0" class="table table-striped table-hover table-bordered" id="manual_table">
                                          <thead>
                                            
                                             <tr>
                                                <th width="15%">Attendance Date </th>
                                                <th width="12%">Tap</th>
                                                <th width="15%">Timestamp </th>
                                                <th width="23%">Additional Comments</th>
												<th width="10%">Action</th>
                                             </tr>
                                          </thead>
                                       
                                          <tbody class="font-grey-mint">
                                             <!-- <tr class="">
                                                <td>
                                                   Mon Oct 09, 2017
                                                </td>
                                                <td>
                                                   07:23 am
                                                </td>
                                                <td>
                                                   04:05 pm
                                                </td>
                                                <td>
                                                   <strong>Mon Oct 09, 2017</strong> at <strong>07:23 am</strong>
                                                </td>
                                                <td>
                                                   Lorem ipsum dolor sit amet
                                                </td>
                                             </tr>
                                             <tr class="">
                                                <td>
                                                   Mon Oct 09, 2017
                                                </td>
                                                <td>
                                                   07:23 am
                                                </td>
                                                <td>
                                                   04:05 pm
                                                </td>
                                                <td>
                                                   <strong>Mon Oct 09, 2017</strong> at <strong>07:23 am</strong>
                                                </td>
                                                <td>
                                                   Lorem ipsum dolor sit amet
                                                </td>
                                             </tr>
                                             <tr class="">
                                                <td>
                                                   Mon Oct 09, 2017
                                                </td>
                                                <td>
                                                   07:23 am
                                                </td>
                                                <td>
                                                   04:05 pm
                                                </td>
                                                <td>
                                                   <strong>Mon Oct 09, 2017</strong> at <strong>07:23 am</strong>
                                                </td>
                                                <td>
                                                   Lorem ipsum dolor sit amet
                                                </td>
                                             </tr> -->
                                          </tbody>
                                       </table>
                                    </div>
                                    <!-- portlet-body -->
                                    <div class="modal fade" id="ManualAttendanceForm" tabindex="-1" role="basic" aria-hidden="true">
                                       <div class="modal-dialog">
                                         <div class="modal-content">
                                             <div class="modal-body" style="float:left;width:100%;">
                                                <div class="portlet box blue-hoki">
                                                   <div class="portlet-title">
                                                      <div class="caption">
                                                         <i class="fa fa-user"></i><font id="">Manual</font>
                                                      </div>
                                                   </div>
                                                   <!-- portlet-title -->
                                                   <div class="headRightDetailsInner">
                                                      <table>
                                                         <tbody>
                                                            <tr id="">
                                                               <td class="" style="padding-right:10px;">
                                                                  <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
                                                               </td>
                                                               <td class="staffView_StaffName">
                                                                  <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
                                                               </td>
                                                            </tr>
                                                         </tbody>
                                                      </table>
                                                      <!-- col-md-4 -->
                                                   </div>
                                                   <!-- headRightDetailsInner -->
                                                   <div class="portlet-body fixedHeightmodalPortlet">
                                                      <div class="form-body">
                                                         <div class="row">
                                                            <div class="col-md-12 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Attendance Date:</label>
                                                                  <div class="">
                                                                     <input type="date" class="form-control"  id="manual_attendance">
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                         <div class="row">
                                                            <div class="col-md-6 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Tap :</label>
                                                                  <div class="">
                                                                     <input type="time" class="form-control" name="" id="manual_missTap" data-id="">
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                  
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                         <div class="row">
                                                            <div class="col-md-12 paddingBottom10">
                                                               <div class="form-group">
                                                                  <label class="">Information regarding missed tap event:</label>
                                                                  <div class="">
                                                                     <textarea id="manual_description" cols="85" rows="5"></textarea>
                                                                  </div>
                                                               </div>
                                                               <!-- form-group -->
                                                            </div>
                                                            <!-- col-md-6 -->
                                                         </div>
                                                         <!-- row -->
                                                      </div>
                                                      <!-- form-body -->
                                                   </div>
                                                   <!-- portlet-body fixedHeightmodalPortlet-->
                                                </div>
                                             </div>
                                             <div class="modal-footer text-center" style="text-align:center;">
                                                <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
                                                <button type="button" class="btn dark btn-outline active" data-dismiss="" onClick="insert_manual()">Submit</button>
                                                <!--button type="button" class="btn green">Add Badge</button -->
                                             </div>
                                          </div>
                                          <!-- /.modal-content -->
                                       </div>
                                       <!-- /.modal-dialog -->
                                    </div>
                                 
								 
								 		
									
									 <div class="modal fade" id="ManualAttendanceFormEdit" tabindex="-1" role="basic" aria-hidden="true">
                                       <div class="modal-dialog">
                                         <div class="modal-content">
                                             <div class="modal-body" style="float:left;width:100%;">
                                                <div class="portlet box blue-hoki">
                                                   <div class="portlet-title">
                                                      <div class="caption">
                                                         <i class="fa fa-user"></i><font id="">Manual</font>
                                                      </div>
                                                   </div>
                                                   <!-- portlet-title -->
                                                   <div class="headRightDetailsInner">
                                                      <table>
                                                         <tbody>
                                                            <tr id="">
                                                               <td class="" style="padding-right:10px;">
                                                                  <img class="user-pic rounded absentia_staff_img tooltips" data-container="body" data-placement="top" data-original-title="12-045" src="" width="42">
                                                               </td>
                                                               <td class="staffView_StaffName">
                                                                  <a href="javascript:;" class="primary-link tooltips absentia_staff_name" data-container="body" data-placement="top" data-original-title="AHK" data-staffid="289" data-staffgtid="12-045"></a> - <small class="absentia_name_code tooltips" data-container="body" data-placement="top" data-original-title="" ></small><br><small class="shortHeight"><span class="absentia_bottom_line tooltips" data-container="body" data-placement="top" data-original-title="Manager, Operations"></span></small>
                                                               </td>
                                                            </tr>
                                                         </tbody>
                                                      </table>
                                                      <!-- col-md-4 -->
                                                   </div>
                                                   <!-- headRightDetailsInner -->
                                                   <div class="portlet-body fixedHeightmodalPortlet">
                                                      <div class="form-body" id="Manual_Form_Entry">
                                                      </div>
                                                      <!-- form-body -->
                                                   </div>
                                                   <!-- portlet-body fixedHeightmodalPortlet-->
                                                </div>
                                             </div>
                                             <div class="modal-footer text-center" style="text-align:center;">
                                                <button type="button" class="btn dark btn-outline" data-dismiss="modal">Cancel</button>
                                                <button type="button" class="btn dark btn-outline active" data-dismiss="" onClick="edit_manual()"> Update </button>
                                                <!--button type="button" class="btn green">Add Badge</button -->
                                             </div>
                                          </div>
                                          <!-- /.modal-content -->
                                       </div>
                                       <!-- /.modal-dialog -->
                                    </div> <!-- End ManualAttendanceFormEdit modal -->
									
									
									
									
                               
								 </div>
                                 <!-- portlet -->
                              </div>
                              <!-- tab_1_3_6 -->
                           </div>
                           <!-- tab-content -->
                        </div>
                        <!-- tabbable-line -->
                     </div>
                     <!-- tab_1_3 -->
                     <div class="tab-pane fade" id="tab_1_4">
                        <div class="portlet box light">
                           <div class="portlet-body padding0">
                              <div class="panel-group accordion" id="accordion3">
                                 <div class="panel panel-default">
                                    <div class="panel-heading">
                                       <h4 class="panel-title">
                                          <a class="accordion-toggle accordion-toggle-styled" data-toggle="collapse" data-parent="#accordion3" href="#collapse_3_1"> Admission </a>
                                       </h4>
                                    </div>
                                    <div id="collapse_3_1" class="panel-collapse in">
                                       <div class="panel-body">
                                          <table width="100%" border="0" class="table bordered accessTable">
                                             <thead>
                                                <tr>
                                                   <th></th>
                                                   <th width="10%" class="text-center">Create</th>
                                                   <th width="10%" class="text-center">Read</th>
                                                   <th width="10%" class="text-center">Update</th>
                                                </tr>
                                             </thead>
                                             <tr>
                                                <td>Issuance Form</td>
                                                <td class="text-center"><i class="icon-plus font-green-jungle fontSize20"></i></td>
                                                <td class="text-center"><i class="icon-eye font-green-jungle fontSize20"></i></td>
                                                <td class="text-center"><i class="icon-reload font-green-jungle fontSize20"></i></td>
                                             </tr>
                                             <tr>
                                                <td>Submission Form</td>
                                                <td class="text-center"><i class="icon-plus font-green-jungle fontSize20"></i></td>
                                                <td class="text-center"><i class="icon-eye font-green-jungle fontSize20"></i></td>
                                                <td class="text-center"><i class="icon-reload font-green-jungle fontSize20"></i></td>
                                             </tr>
                                             <tr>
                                                <td>Followup Form</td>
                                                <td class="text-center"><i class="icon-plus font-green-jungle fontSize20"></i></td>
                                                <td class="text-center"><i class="icon-eye font-green-jungle fontSize20"></i></td>
                                                <td class="text-center"><i class="icon-reload font-red-thunderbird fontSize20"></i></td>
                                             </tr>
                                             <tr>
                                                <td>AnD Process Form</td>
                                                <td class="text-center"><i class="icon-plus font-green-jungle fontSize20"></i></td>
                                                <td class="text-center"><i class="icon-eye font-red-thunderbird fontSize20"></i></td>
                                                <td class="text-center"><i class="icon-reload font-red-thunderbird fontSize20"></i></td>
                                             </tr>
                                             <tr>
                                                <td>Admin Authority Form</td>
                                                <td class="text-center"><i class="icon-plus font-red-thunderbird fontSize20"></i></td>
                                                <td class="text-center"><i class="icon-eye font-red-thunderbird fontSize20"></i></td>
                                                <td class="text-center"><i class="icon-reload font-red-thunderbird fontSize20"></i></td>
                                             </tr>
                                          </table>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="panel panel-default">
                                    <div class="panel-heading">
                                       <h4 class="panel-title">
                                          <a class="accordion-toggle accordion-toggle-styled collapsed" data-toggle="collapse" data-parent="#accordion3" href="#collapse_3_2"> HR </a>
                                       </h4>
                                    </div>
                                    <div id="collapse_3_2" class="panel-collapse collapse">
                                       <div class="panel-body" style="height:200px; overflow-y:auto;">
                                          <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                          <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                             eiusmod. 
                                          </p>
                                          <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                          <p>
                                             <a class="btn blue" href="ui_tabs_accordions_navs.html#collapse_3_2" target="_blank"> Activate this section via URL </a>
                                          </p>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="panel panel-default">
                                    <div class="panel-heading">
                                       <h4 class="panel-title">
                                          <a class="accordion-toggle accordion-toggle-styled collapsed" data-toggle="collapse" data-parent="#accordion3" href="#collapse_3_3"> Finance </a>
                                       </h4>
                                    </div>
                                    <div id="collapse_3_3" class="panel-collapse collapse">
                                       <div class="panel-body">
                                          <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                             eiusmod. Brunch 3 wolf moon tempor. 
                                          </p>
                                          <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                          <p>
                                             <a class="btn green" href="ui_tabs_accordions_navs.html#collapse_3_3" target="_blank"> Activate this section via URL </a>
                                          </p>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="panel panel-default">
                                    <div class="panel-heading">
                                       <h4 class="panel-title">
                                          <a class="accordion-toggle accordion-toggle-styled collapsed" data-toggle="collapse" data-parent="#accordion3" href="#collapse_3_4"> SIS </a>
                                       </h4>
                                    </div>
                                    <div id="collapse_3_4" class="panel-collapse collapse">
                                       <div class="panel-body">
                                          <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                          <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                             eiusmod. Brunch 3 wolf moon tempor. 
                                          </p>
                                          <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                          <p>
                                             <a class="btn red" href="ui_tabs_accordions_navs.html#collapse_3_4" target="_blank"> Activate this section via URL </a>
                                          </p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- tab_1_4 -->
                     <div class="tab-pane fade active in" id="tab_1_5">
                        <div class="portlet box light">
                           <div class="portlet-body padding0">
                              <div class="chat-form">
                                 <div class="pull-left commentBox width100">
                                    <input type="text" class="form-control borderRight0 width78" placeholder="Type a comment here..." id="commentText" />
                                    <div class="rightpullAbsolutes">
                                       <div class="pull-right commentType" id="">
                                          <button type="button" class="btn-default btn dropdown-toggle borderRight0 show_show" data-toggle="dropdown" tabindex="-1" aria-expanded="false" id="show" onClick="show_dropdown()">
                                          Category &nbsp;<i class="fa fa-angle-down"></i>
                                          </button>
                                          <div class="dropdown-menuu pull-right" role="menu" style="display:none;">
                                             <h4 class="bbottom">Comment Category</h4>
                                             @foreach($staffCategory as $category)
                                             <label class="mt-checkbox">
                                             <input type="checkbox"  data-name="{{$category->name}}" value="{{$category->id}}" class="CheckBox_Category" /> {{$category->name}}
                                             <span></span>
                                             </label><br />
                                             @endforeach
                                          </div>
                                       </div>
                                       <!-- commnetType -->
                                       <div class="pull-left commentButton">
                                          <button type="button"  class="btn uppercase green-jungle borderRight0" id="" tabindex="-1" onClick="insertComment()">Comment</button>
                                       </div>
                                       <!-- commentButton -->
                                       <div class="theme-panel hidden-xs hidden-sm">
                                          <div class="toggler4"> </div>
                                          <div class="toggler4-close"> </div>
                                          <div class="theme-options4">
                                             <div class="theme-option">
                                                <span> Source </span>
                                                <select id="filter_user" class="layout-option form-control input-sm">
                                                   <option value="" disabled selected>Select source</option>
                                                   <option value="user">User</option>
                                                   <option value="system">System</option>
                                                </select>
                                             </div>
                                             <div class="theme-option">
                                                <span style="padding-bottom:10px;"> Category</span>
                                                <span style="width:100%;">
                                                <label class="mt-checkbox">
                                                <input type="checkbox" name="Search_Cat[]" value="Accounts" /> Finance
                                                <span></span>
                                                </label>
                                                <label class="mt-checkbox">
                                                <input type="checkbox" name="Search_Cat[]" value="Academic" /> Academic
                                                <span></span>
                                                </label>
                                                <label class="mt-checkbox">
                                                <input type="checkbox" name="Search_Cat[]" value="Etab" /> E-TAB
                                                <span></span>
                                                </label>
                                                <label class="mt-checkbox">
                                                <input type="checkbox" name="Search_Cat[]" value="SIS" /> SIS
                                                <span></span>
                                                </label>
                                                <label class="mt-checkbox">
                                                <input type="checkbox" name="Search_Cat[]" value="Family" /> Family
                                                <span></span>
                                                </label>
                                                <label class="mt-checkbox">
                                                <input type="checkbox" name="Search_Cat[]" value="SMS" /> SMS
                                                <span></span>
                                                </label>
                                                </span>
                                             </div>
                                             <div class="theme-option">
                                                <div class="input-group date-picker input-daterange" data-date="10/11/2012" data-date-format="mm/dd/yyyy">
                                                   <input type="date" class="form-control" name="from" id="from_date" min="" />
                                                   <span class="input-group-addon"> to </span>
                                                   <input type="date" class="form-control" name="to" id="to_date" /> 
                                                </div>
                                                <!-- /input-group -->
                                                <span class="help-block"> Select date range </span>
                                             </div>
                                             <div class="theme-option text-center" id="">
                                                <a href="javascript:;" class="btn uppercase green-jungle applySearch">Apply Filter</a>
                                                <a href="javascript:;" class="btn uppercase grey-salsa clearSearch" onClick="clearSearch()">Clear Filter</a>
                                             </div>
                                          </div>
                                          <!-- theme-options -->
                                       </div>
                                    </div>
                                    <!-- rightpullAbsolute -->
                                 </div>
                                 <!-- commentBox -->
                              </div>
                              <!-- chat-form -->
                              <div class="col-md-12" style="" data-always-visible="1" data-rail-visible1="1" id="">
                                 <ul class="chats" id="stories">
                                 </ul>
                                 <!-- chats -->
                              </div>
                              <!-- col-md-12  -->
                           </div>
                           <!-- portlet-body-->
                        </div>
                        <!-- portlet -->
                     </div>
                     <!-- tab_1_5 -->
<style>
.padRight1 {
	padding-right:1%;	
	text-align:right;
	width:49%;
}
.padLeft1 {
	padding-left:1%;
	width:49%;	
}
.currentStaff tbody {
	background:#f5eba3;	
}
.innerTbodyStaff {
	text-align: left;
    padding: 4px;
    float: left;
    width: 100%;
	border: 1px solid #e0dfdf;
	height: 55px;
	background: #efefef;
}
.innerTbodyStaff .user-pic {
    height: 43px !important;
}
.rolesTable tr.pBottom10 {
    width: 100%;
	height: 60px;
}
.rolesTable td.staffView_StaffName {
    padding-left: 6px;
	width:100%;
}
.innerTbodyStaff .row td {
	float:left;	
}
.innerTbodyStaff .row tdLlast-child {
	float:right;
	width:15%;
		
}
.leftInformationRoleStaff {
	float:left;
}
.rightInformationRoleStaff {
    float: right;
    padding: 12px 10px;
    font-weight: bold;
    color: #717171;
    font-size: 14px;
    border: 1px solid #c3c3c3;
    background: #d0d0d0;
}
</style>                     
                     <div class="tab-pane fade" id="tab_1_6">
                        <div class="portlet box light">
                           <div class="portlet-body padding0">
                             	<table width="100%" class="rolesTable">
                                	<tr class="pBottom10">
                                    	<td class="padRight1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padRight1 -->
                                        <td class="padLeft1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="VP/HM" data-department="Principal, Generation's School" style="display: table-row;">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="90-001" src="assets/photos/hcm/150x150/staff/973.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                         	<span class="leftInformationRoleStaff">
                                                                <a class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="DGS" data-staffid="19" data-staffgtid="90-001" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Ghazala Siddiqui</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="g.siddiqui">DGS</small><br>
                                                                <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">20 B</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Principal, Generation's School">Generation's School: Principal</span></small>
                                                            </span><!-- leftInformation -->
                                                            <span class="rightInformationRoleStaff">
                                                                <span class="rolesRelations">
                                                                    20 B
                                                                </span>  
                                                         	</span><!-- rightInformationRoleStaff -->                                                             
                                                         </td>
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padLeft1 -->
                                    </tr>
                                    <!-- -->
                                    <tr class="pBottom10">
                                    	<td width="50%" class="padRight1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="VP/HM" data-department="Principal, Generation's School" style="display: table-row;">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="90-001" src="assets/photos/hcm/150x150/staff/973.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                         	<span class="leftInformationRoleStaff">
                                                                <a class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="DGS" data-staffid="19" data-staffgtid="90-001" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Ghazala Siddiqui</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="g.siddiqui">DGS</small><br>
                                                                <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">20 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Principal, Generation's School">Generation's School: Principal</span></small>
                                                            </span><!-- leftInformation -->
                                                            <span class="rightInformationRoleStaff">
                                                                <span class="rolesRelations">
                                                                    20 A
                                                                </span>  
                                                         	</span><!-- rightInformationRoleStaff --> 
                                                         </td>
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padRight1 -->
                                        <td width="50%" class="padLeft1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="VP/HM" data-department="Director, Generation's School" style="display: table-row;">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="90-003" src="assets/photos/hcm/150x150/staff/299.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                         	<span class="leftInformationRoleStaff">
                                                                <a class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="SSD" data-staffid="15" data-staffgtid="90-003" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Shoaib Siddiqui</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="s.siddiqui">SSD</small><br>
                                                                <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">20 B</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Director, Generation's School">Generation's School: Director</span></small>
                                                            </span><!-- leftInformation -->
                                                            <span class="rightInformationRoleStaff">
                                                                <span class="rolesRelations">
                                                                    20 B
                                                                </span>  
                                                         	</span><!-- rightInformationRoleStaff -->
                                                         </td>
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padLeft1 -->
                                    </tr>
                                    <!-- -->
                                    <tr class="pBottom10">
                                    	<td width="50%" class="padRight1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="VP/HM" data-department="Director, Generation's School" style="display: table-row;">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="90-003" src="assets/photos/hcm/150x150/staff/299.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                         	<span class="leftInformationRoleStaff">
                                                                <a class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="SSD" data-staffid="15" data-staffgtid="90-003" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Shoaib Siddiqui</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="s.siddiqui">SSD</small><br>
                                                                <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Director, Generation's School">Generation's School: Director</span></small>
                                                            </span><!-- leftInformation -->
                                                            <span class="rightInformationRoleStaff">
                                                                <span class="rolesRelations">
                                                                    10 A
                                                                </span>  
                                                         	</span><!-- rightInformationRoleStaff -->
                                                         </td>
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padRight1 -->
                                        <td width="50%" class="padLeft1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="" data-department="Senior General Manager, Generation's School">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="15-067" src="assets/photos/hcm/150x150/staff/1010.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                         	<span class="leftInformationRoleStaff">
                                                                <a class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="KSM" data-staffid="606" data-staffgtid="15-067" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Kashif Shamim</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="k.shamim">KSM</small><br>
                                                                <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 B</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Senior General Manager, Generation's School">Generation's School: Senior General Manager</span></small>
                                                            </span><!-- leftInformation -->
                                                            <span class="rightInformationRoleStaff">
                                                                <span class="rolesRelations">
                                                                    10 B
                                                                </span>  
                                                         	</span><!-- rightInformationRoleStaff -->
                                                         </td>
                                                     
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padLeft1 -->
                                    </tr>
                                    <!-- -->
                                    <tr class="pBottom10 currentStaff">
                                    	<td width="50%" class="padRight1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row " data-attendance="Absent" data-campus="South" data-profile="Software Team" data-department="Head, Digital Systems, Digital Infrastructures">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="15-076" src="assets/photos/hcm/150x150/staff/1014.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                            <a href="" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="MHF" data-staffid="615" data-staffgtid="15-076" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Muhammad Faisal</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="m.faisal2">MHF</small><br>
                                                            <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">R</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Head, Digital Systems, Digital Infrastructures">Digital Infrastructures: Head, Digital Systems</span></small>
                                                         </td>
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padRight1 -->
                                        <td width="50%" class="padLeft1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row " data-attendance="Absent" data-campus="South" data-profile="Software Team" data-department="Head, Digital Systems, Digital Infrastructures">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="15-076" src="assets/photos/hcm/150x150/staff/1014.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                            <a href="" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="MHF" data-staffid="615" data-staffgtid="15-076" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Muhammad Faisal</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="m.faisal2">MHF</small><br>
                                                            <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">R</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Head, Digital Systems, Digital Infrastructures">Digital Infrastructures: Head, Digital Systems</span></small>
                                                         </td>
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padLeft1 -->
                                    </tr>
                                    <!-- -->
                                    <tr class="pBottom10">
                                    	<td width="50%" class="padRight1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="Software test Profile" data-department="Software, Team Lead, Software">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="09-008" src="assets/photos/hcm/150x150/staff/298.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                       		<span class="leftInformationRoleStaff">
                                                                <a href="" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="ANA" data-staffid="1" data-staffgtid="09-008" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Atif Naseem Ahmed</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="a.naseem">ANA</small><br>
                                                                <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Software, Team Lead, Software">Software: Software, Team Lead</span></small>
                                                            </span>
                                                            <span class="rightInformationRoleStaff">
                                                            	<span class="rolesRelations">
                                                                    10 A
                                                                </span>   
                                                         	</span><!-- rightInformationRoleStaff -->
                                                         </td>
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padRight1 -->
                                        <td width="50%" class="padLeft1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="DI" data-department="IT Incharge, Digital Infrastructures">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="12-043" src="assets/photos/hcm/150x150/staff/714.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                         	<span class="leftInformationRoleStaff">
                                                                <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="SAA" data-staffid="287" data-staffgtid="12-043" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Syed Asder Ahmed</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="s.a.ahmed">SAA</small><br>
                                                                <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="IT Incharge, Digital Infrastructures">Digital Infrastructures: IT Incharge</span></small>
                                                            </span>
                                                            <span class="rightInformationRoleStaff">
                                                            	<span class="rolesRelations">
                                                                    10 A
                                                                </span>   
                                                         	</span><!-- rightInformationRoleStaff -->
                                                         </td>
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padLeft1 -->
                                    </tr>
                                    <!-- -->
                                    <tr class="pBottom10">
                                    	<td width="50%" class="padRight1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="Software test Profile" data-department="Software Developer, Software" style="display: table-row;">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="16-009" src="assets/photos/hcm/150x150/staff/1103.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                         	<span class="leftInformationRoleStaff">
                                                                <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="KMS" data-staffid="774" data-staffgtid="16-009" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Kashif Mustafa</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="k.mustafa">KMS</small><br>
                                                                <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Software Developer, Software">Software: Software Developer</span></small>
                                                            </span><!-- leftInformation -->
                                                            <span class="rightInformationRoleStaff">
                                                                <span class="rolesRelations">
                                                                    10 A
                                                                </span>  
                                                         	</span><!-- rightInformationRoleStaff -->
                                                         </td>
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padRight1 -->
                                        <td width="50%" class="padLeft1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="" data-department="CCTV Technician, Digital Infrastructures">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="15-195" src="assets/photos/hcm/150x150/staff/1076.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                         	<span class="leftInformationRoleStaff">
                                                                <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="MAV" data-staffid="737" data-staffgtid="15-195" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Amin Vohra</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="a.vohra">MAV</small><br>
                                                                <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">13 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="CCTV Technician, Digital Infrastructures">Digital Infrastructures: CCTV Technician</span></small>
                                                            </span><!-- leftInformation -->
                                                            <span class="rightInformationRoleStaff">
                                                                <span class="rolesRelations">
                                                                    13 A
                                                                </span>  
                                                         	</span><!-- rightInformationRoleStaff -->     
                                                         </td>
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padLeft1 -->
                                    </tr>
                                    <!-- -->
                                    <tr class="pBottom10">
                                    	<td width="50%" class="padRight1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="Digital Infrastructure" data-department="Software Developer, Software" style="display: table-row;">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="16-070" src="assets/photos/hcm/150x150/staff/1159.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                         	<span class="leftInformationRoleStaff">
                                                                <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="HOL" data-staffid="835" data-staffgtid="16-070" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Muhammad Haris Ola</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="h.ola">HOL</small><br>
                                                                <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Software Developer, Software">Software: Software Developer</span></small>
                                                            </span><!-- leftInformation -->
                                                            <span class="rightInformationRoleStaff">
                                                                <span class="rolesRelations">
                                                                    10 A
                                                                </span>  
                                                         	</span><!-- rightInformationRoleStaff -->  
                                                         </td>
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padRight1 -->
                                        <td width="50%" class="padLeft1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="Digital Infrastructure" data-department="IT Administrator, Digital Infrastructures">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="13-025" src="assets/photos/hcm/150x150/staff/818.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                         	<span class="leftInformationRoleStaff">
                                                                <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="RHA" data-staffid="350" data-staffgtid="13-025" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">M Rehan Akhtar</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="r.akhtar">RHA</small><br>
                                                                <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">13 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="IT Administrator, Digital Infrastructures">Digital Infrastructures: IT Administrator</span></small>
                                                            </span><!-- leftInformation -->
                                                            <span class="rightInformationRoleStaff">
                                                                <span class="rolesRelations">
                                                                    13 A
                                                                </span>  
                                                         	</span><!-- rightInformationRoleStaff --> 
                                                         </td>
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padLeft1 -->
                                    </tr>
                                    <!-- -->
                                    <tr class="pBottom10">
                                    	<td width="50%" class="padRight1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="Lead Teachers SC" data-department="Software Developer, Software" style="display: table-row;">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="16-008" src="assets/photos/hcm/150x150/staff/1104.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                         	<span class="leftInformationRoleStaff">
                                                                <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="ROA" data-staffid="773" data-staffgtid="16-008" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Rohail Aslam</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="r.aslam">ROA</small><br>
                                                                <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Software Developer, Software">Software: Software Developer</span></small>
                                                            </span><!-- leftInformation -->
                                                            <span class="rightInformationRoleStaff">
                                                                <span class="rolesRelations">
                                                                    10 A
                                                                </span>  
                                                         	</span><!-- rightInformationRoleStaff -->  
                                                         </td>
                                                     
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padRight1 -->
                                        <td width="50%" class="padLeft1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="Digital Infrastructure" data-department="IT Administrator, Digital Infrastructures" style="display: table-row;">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="16-010" src="assets/photos/hcm/150x150/staff/1105.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                         	<span class="leftInformationRoleStaff">
                                                                <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="NAB" data-staffid="775" data-staffgtid="16-010" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Mirza Numair</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="m.numair">NAB</small><br>
                                                                <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">13 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="IT Administrator, Digital Infrastructures">Digital Infrastructures: IT Administrator</span></small>
                                                            </span><!-- leftInformation -->
                                                            <span class="rightInformationRoleStaff">
                                                                <span class="rolesRelations">
                                                                    13 A
                                                                </span>  
                                                         	</span><!-- rightInformationRoleStaff -->  
                                                         </td>
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padLeft1 -->
                                    </tr>
                                    <!-- -->
                                    <tr class="pBottom10">
                                    	<td width="50%" class="padRight1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="Software Team" data-department="SIS Officer, Coordination">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="13-035" src="assets/photos/hcm/150x150/staff/878.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                       	   <span class="leftInformationRoleStaff">
                                                                <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="MSQ" data-staffid="2" data-staffgtid="13-035" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Muhammad Saqib</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="m.saqib">MSQ</small><br>
                                                               <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 C</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="SIS Officer, Coordination">Coordination: SIS Officer</span></small>
                                                           </span><!-- leftInformation -->
                                                            <span class="rightInformationRoleStaff">
                                                                <span class="rolesRelations">
                                                                    10 C
                                                                </span>  
                                                         	</span><!-- rightInformationRoleStaff -->   
                                                         </td>
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padRight1 -->
                                        <td width="50%" class="padLeft1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row" data-attendance="Absent" data-campus="North" data-profile="" data-department="IT Administrator, Digital Infrastructures" style="display: table-row;">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="12-034" src="assets/photos/hcm/150x150/staff/718.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                         	<span class="leftInformationRoleStaff">
                                                                <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="KAM" data-staffid="278" data-staffgtid="12-034" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Khurram Majeed</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="k.a.majeed">KAM</small><br>
                                                                <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-CPM: Permanent">C</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">13 C</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="IT Administrator, Digital Infrastructures">Digital Infrastructures: IT Administrator</span></small>
                                                            </span><!-- leftInformation -->
                                                            <span class="rightInformationRoleStaff">
                                                                <span class="rolesRelations">
                                                                    13 C
                                                                </span>  
                                                         	</span><!-- rightInformationRoleStaff -->  
                                                         </td>
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padLeft1 -->
                                    </tr>
                                    <!-- -->
                                    <tr class="pBottom10">
                                    	<td width="50%" class="padRight1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    <tr class="Row" data-attendance="Absent" data-campus="South" data-profile="Software test Profile" data-department="Software Developer, Software" style="display: table-row;">
                                                         <td class="">
                                                            <img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="17-066" src="assets/photos/hcm/150x150/staff/male.png">
                                                         </td>
                                                         <td class="staffView_StaffName">
                                                         	<span class="leftInformationRoleStaff">
                                                                <a href="javascript:;" class="primary-link tooltips profile_StaffName" data-container="body" data-placement="top" data-original-title="ABL" data-staffid="933" data-staffgtid="17-066" data-src="http://10.10.10.50/gsims/public/metronic/pages/img/AbsentIcon.png" data-content="Tap In awaited" data-title="Absent">Asim Bilal</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="a.bilal2">ABL</small><br>
                                                                <small class="shortHeight"><span class="staffStatus T tooltips" data-container="body" data-placement="top" data-original-title="T-TPB: Probation">T</span> <span class="staffStatus A tooltips" data-container="body" data-placement="top" data-original-title="Reporting To">10 A</span> <span class="tooltips" data-container="body" data-placement="top" data-original-title="Software Developer, Software">Software: Software Developer</span></small>
                                                            </span><!-- leftInformation -->
                                                            <span class="rightInformationRoleStaff">
                                                                <span class="rolesRelations">
                                                                    10 A
                                                                </span>  
                                                         	</span><!-- rightInformationRoleStaff -->  
                                                         </td>
                                                  	</tr>
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padRight1 -->
                                        <td width="50%" class="padLeft1">
                                        	<table width="100%">
                                            	<tbody class="innerTbodyStaff">
                                                    
                                                </tbody><!-- tbody .innerTbodyStaff -->
                                            </table><!-- table -->
                                        </td><!-- padLeft1 -->
                                    </tr>
                                    
                                    <!-- -->
                                </table>
                           </div>
                           <!-- portlet-body-->
                        </div>
                        <!-- portlet -->
                     </div>
                     <!-- tab_1_6 -->
                  </div>
                  <!-- tab-content -->
               </div>
               <!-- portlet-body -->
            </div>
            <!-- portlet -->
         </div>
         <!-- col-md-12 v-->
      </div>
      <!-- row -->
   </div>
   <!-- col-md-8 -->
</div>
<!-- row -->
<!-- END USE PROFILE -->
<!--================================================== -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<script type="text/javascript">
   $('.toggler4').show();
   $('.toggler4-close').hide();
   $('.theme-panel > .theme-options4').hide();
   $('#staffView_StaffList_Search').val('');
   
   
   //Show total count of table records
   var totalRow =  $('#staffView_Table_StaffList tr:visible').length - 1;
   $('#staffView_StaffList_Total').text('STAFF LIST - ' + totalRow); 
   
   //Create all select box to multi select with checkbox 
   $('#StaffView_Filter_Profile').multiselect({ numberDisplayed: 1 });
   $('#StaffView_Filter_Department').multiselect({ numberDisplayed: 1 });
   $('#StaffView_Filter_Campus').multiselect({ numberDisplayed: 1 });
   $('#StaffView_Filter_AtdStd').multiselect({ numberDisplayed: 1 });
   $('#StaffView_Filter_StaffStd').multiselect({ numberDisplayed: 1 });
   
   //Assign table rows to tableRecords
   var tableRecords = $('#staffView_Table_StaffList').find('.Row');
   
   //Multi Filter prototype
   String.prototype.replaceAll = function(search, replacement) {
       var target = this;
       return target.replace(new RegExp(search, 'g'), replacement);
   };
   
   //Add css class selected when click on table row
   $("tbody tr").click(function() {
   
       $(this).addClass('selected').siblings().removeClass("selected");
   });
   

   $(".saveMultipleLeave").click(function() {

       var staff_ids = $('.leaveSelect').val();

       for (var i = 0; i < staff_ids.length; i++) {

           $("#multiple_limit").bootstrapSwitch();
           var paid_compensation = $('#multiple_limit').bootstrapSwitch('state'); //returns true or false
           if (paid_compensation == true) {
               paid_compensation = 1;
           } else {
               paid_compensation = 0;
           }

           var staffID = staff_ids[i];

           var leave_title = $('#multiple_leave_title').val();
           var leave_type = $('.multiple_leave_type option:selected').val();
           var leave_from = $('#multiple_leave_from').val();
           var leave_to = $('#multiple_leave_to').val();
           var leave_comment = $('#multiple_leave_comment').val();

           var paid_compensation_display;
           if (paid_compensation == 1) {
               paid_compensation_display = 'Yes';
           } else {
               paid_compensation_display = 'No';
           }


           if (leave_type != '' && leave_title != '' && leave_from != '' && leave_to != '') {

               $.ajax({
                   type: "POST",
                   cache: true,
                   url: "{{url('/masterLayout/staff/addLeave')}}",
                   data: {
                       "staff_id": staffID,
                       "leave_title": leave_title,
                       "leave_type": leave_type,
                       "leave_from": leave_from,
                       "leave_to": leave_to,
                       "leave_comment": leave_comment,
                       "paid_compensation": paid_compensation,
                       "_token": "{{ csrf_token() }}"
                   },
                   success: function(result) {

                       $('#leave_table').append('<tr class="PendingapprovedBorder" data-id=' + result + '><td>' + leave_title + '</td><td><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested Compensation"></i> &nbsp; ' + paid_compensation_display + '</td></tr></table></td><td><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested From"></i> &nbsp; ' + formatDate(leave_from) + ' </td></tr></table></td><td><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested till"></i> &nbsp; ' + formatDate(leave_to) + '</td></tr></table></td><td>' + leave_comment + '</td><td class="text-center"><a href="#" data-container="body" data-placement="bottom" data-original-title="Print Leave Application" class="tooltips" ><span aria-hidden="true" class="icon-printer"></span></a> | <a href="#LeaveApproval"  data-toggle="modal" data-container="body" data-placement="bottom" data-original-title="Leave Approval" class="tooltips" onClick="updateLeave(' + result + ')"><i class="fa fa-check"></i></a></td></tr>');
                   }

               });
           }
       }

       $('#ProcessEntry').modal('toggle');

   });
   $(".saveMultipleAbsentia").click(function() {

       var staff_ids = $('.absentiaSelect').val();

       for (var i = 0; i < staff_ids.length; i++) {


           var date = $("#multiple_absentia_date").val();
           var title = $("#multiple_absentia_title").val();
           var start_time = $("#multiple_absentia_startTime").val();
           var end_time = $("#multiple_absentia_endTime").val();
           var description = $("#multiple_absentia_description").val();
           var staffID = staff_ids[i];
           if (date !== '' && title !== '' && start_time !== '' && end_time !== '') {

               $.ajax({
                   type: "POST",
                   cache: true,
                   url: "{{url('/masterLayout/staff/addAbsentia')}}",
                   data: {
                       "staff_id": staffID,
                       "date": date,
                       "title": title,
                       "start_time": start_time,
                       "end_time": end_time,
                       "description": description,
                       "_token": "{{ csrf_token() }}"
                   },
                   success: function(result) {
					   
					   var data = jQuery.parseJSON(result);
				  var Edit_Absentia_id_hidden = data["Last_id"];
					//var Edit_Absentia_id_hidden = data.Last_id;
				
					$('#absentia_table').append('<tr class="absentia_table_row" id="absentia_table_row_'+Edit_Absentia_id_hidden+'"> <td>'+ title +'</td> <td>'+ formatDate(date) +'</td> <td>'+ changeTimeFormat(start_time) +'<br /></td> <td>'+ changeTimeFormat(end_time) +'</td> <td>'+ description +'</td><td><a onClick="Edit_Absentia('+Edit_Absentia_id_hidden+','+staffID+')"><i class="fa fa-edit"></i></a> | <a onClick="delete_Absentia('+Edit_Absentia_id_hidden+','+staffID+')"><i class="fa fa-close"></i></a></td> </tr>');

                   $("#multiple_absentia_date").val('');
                   $("#multiple_absentia_title").val('');
                   $("#multiple_absentia_startTime").val('');
                   $("#multiple_absentia_endTime").val('');
                   $("#multiple_absentia_description").val('');
				   
				   $('#ProcessEntry').modal('toggle');
				   

                       /*$('#absentia_table').append('<tr> <td>' + title + '</td> <td>' + formatDate(date) + '</td> <td>' + changeTimeFormat(start_time) + '<br /></td> <td>' + changeTimeFormat(end_time) + '</td> <td>' + description + '</td><td><a href="#">Edit</a> | <a href="#">Delete</a></td> </tr>');
                       $("#multiple_absentia_date").val('');
                       $("#multiple_absentia_title").val('');
                       $("#multiple_absentia_startTime").val('');
                       $("#multiple_absentia_endTime").val('');
                       $("#multiple_absentia_description").val(''); */
                   }
               });
           }
       }

       //$('#ProcessEntry').modal('toggle');
   });


   $(".saveMultiplePenalty").click(function() {

       var staff_ids = $('.selectPenalty').val();

       for (var i = 0; i < staff_ids.length; i++) {

           var penalty_title = $('#multiple_penalty_title').val();
           var penalty_day = $('#multiple_penalty_day').val();
           var penalty_from = $('#multiple_penalty_from').val();
           var penalty_to = $('#multiple_penalty_to').val();
           var penalty_description = $('#multiple_penalty_description').val();
           var staff_id = staff_ids[i];
           // console.log(penalty_to);

           if (staff_id != '' && penalty_title != '' && penalty_from != '' && penalty_to != '' && penalty_day != '') {
               $.ajax({
                   type: "POST",
                   cache: true,
                   url: "{{url('/masterLayout/addPenalty')}}",
                   data: {
                       "penalty_title": penalty_title,
                       "penalty_day": penalty_day,
                       "penalty_from": penalty_from,
                       "penalty_to": penalty_to,
                       "penalty_description": penalty_description,
                       "staff_id": staff_id,
                       "_token": "{{ csrf_token() }}"
                   },
                   success: function(e) {
                       var curdate = new Date();
                       var hours = AddZeroDate(curdate.getHours());
                       var min = AddZeroDate(curdate.getMinutes());
                       var time = changeTimeFormat(hours + ":" + min);
					   
					    //var Last_id = e.id;
					  var data = JSON.parse(e);
					  var Last_id = data.id;
					  
				  
				  $('#penaltyTable').append('<tr class="penaltyRowClass" data-id="'+Last_id+'"><td>'+penalty_title+'</td><td>'+penalty_day+'</td><td>'+formatDate(penalty_from)+'-'+formatDate(penalty_to)+'</td><td>'+formatDate(curdate)+'<span> at <span>'+changeTimeFormat(time)+'</td><td>'+penalty_description+'</td> <td class="text-center"><a onClick="ReWriteLeavePenalties('+Last_id+')"><i class="fa fa-edit"></i></a> | <a onClick="delectLeavePenalties('+Last_id+')"><i class="fa fa-close"></i></a> </td>  </tr>'); 
                  $('#multiple_penalty_title').val('');
                  $('#multiple_penalty_day').val('');
                  $('#multiple_penalty_from').val('');
                  $('#multiple_penalty_to').val('');
                  $('#multiple_penalty_description').val('');
                  $('#ProcessEntry').modal('toggle');
				  
                       /*$('#penaltyTable').append('<tr><td>' + penalty_title + '</td><td>' + penalty_day + '</td><td>' + formatDate(penalty_from) + '-' + formatDate(penalty_to) + '</td><td>' + formatDate(curdate) + '<span> at <span>' + changeTimeFormat(time) + '</td><td>' + penalty_description + '</td></tr>');
                       $('#multiple_penalty_title').val('');
                       $('#multiple_penalty_day').val('');
                       $('#multiple_penalty_from').val('');
                       $('#multiple_penalty_to').val('');
                       $('#multiple_penalty_description').val('');*/

                   }
               });
           }
       }
       $('#ProcessEntry').modal('toggle');

   });

   $(".saveMultipleAdjustment").click(function() {

       var staff_ids = $('.selectPenalty').val();

       for (var i = 0; i < staff_ids.length; i++) {
           var adjustment_title = $('#multiple_adjustment_title').val();
           var adjustment_no = $('#multiple_adjustment_no').val();
           var adjustment_description = $('#multiple_adjustment_description').val();
           var staff_id = staff_ids[i];
           if (adjustment_title != '' && adjustment_no != '') {
               $.ajax({
                   type: "POST",
                   cache: true,
                   data: {
                       "adjustment_title": adjustment_title,
                       "adjustment_no": adjustment_no,
                       "adjustment_description": adjustment_description,
                       "staff_id": staff_id,
                       "_token": "{{csrf_token()}}"
                   },
                   url: "{{url('/masterLayout/addAdjustment')}}",
                   success: function(e) {

                       var date = new Date();
                       var hours = AddZeroDate(date.getHours());
                       var min = AddZeroDate(date.getMinutes());
                       var time = changeTimeFormat(hours + ":" + min);
					   
					   var data = JSON.parse(e);
						var Last_id = data.id;
				
                       /*var adjustmentHTML = '';
                       adjustmentHTML = '<tr><td>' + adjustment_title + '</td><td>' + adjustment_no + 'days</td><td>' + formatDate(date) + '<span> at </span>' + time + '</td><td>' + adjustment_description + '</td></tr>';
                       $('#adjustment_table tbody').append(adjustmentHTML); */
					   
					   
					    var adjustmentHTML = '';
				adjustmentHTML = '<tr class="AddAdjustment" data-id="'+Last_id+'" ><td>'+adjustment_title+'</td><td>'+adjustment_no+'days</td><td>'+formatDate(date)+'<span> at </span>'+time+'</td><td>'+adjustment_description+'</td> <td class="text-center"><a onClick="ReWriteAdjustment('+Last_id+')"><i class="fa fa-edit"></i></a> | <a onClick="deleteAdjustment('+Last_id+')"><i class="fa fa-close"></i></a>  </tr>';
                $('#ProcessEntry').modal('toggle');                 
                $('#adjustment_table tbody').append(adjustmentHTML);
				
				
                   }

               });
           }
       }
       $('#ProcessEntry').modal('toggle');

   });


   $(".saveMultipleManual").click(function() {

       var staff_ids = $('.selectManual').val();

       for (var i = 0; i < staff_ids.length; i++) {
           var date = $("#multiple_manual_attendance").val();
           var missTap = $("#multiple_manual_tap").val();

           var description = $("#multiple_manual_description").val();
           var staffID = staff_ids[i];

           if (date != '' && missTap != '' && staffID != '') {
               $.ajax({
                   type: "POST",
                   cache: true,
                   url: "{{url('/masterLayout/staff/addManual')}}",
                   data: {
                       "staff_id": staffID,
                       "date": date,
                       "missTap": missTap,
                       "description": description,
                       "_token": "{{ csrf_token() }}"
                   },
                   success: function(result) {
                       var time = new Date();
                       var hours = AddZeroDate(time.getHours());
                       var min = AddZeroDate(time.getMinutes());
                       time = changeTimeFormat(hours + ":" + min);
                       if (missTap == '') {
                           missTap = 'no tap in';
                       } else {
                           missTap = changeTimeFormat(missTap);
                       }
					   
					   // var r = JSON.parse(result);
						//var Last_id = r.id;
				  


                       /*var userData = result['userInfo']['info'];
                       $('#manual_table').append('<tr><td>' + formatDate(date) + '</td><td>' + missTap + '</td><td><strong>' + '<small class="tooltips" data-original-title="' + userData[0]['abridged_name'] + '">' + userData[0]['name_code'] + '</small> - ' + formatDate(result['date']) + '</strong> at <strong>' + time + '</strong></td><td>' + description + '</td></tr>');

                       $("#multiple_manual_attendance").val('');
                       $("#multiple_manual_tap").val('');
                       $("#multiple_manual_description").val(''); */
					   
					   
					        
                 
				 var userData = result['userInfo']['info'];
				 var Last_id = result['Last_id'];
				var Missed_id= result['Missed_id'];
				var Table_name= result['Table_name'];
				$('#manual_table').append('<tr class="missedTapEven" data-id="'+Last_id+'"><td>'+formatDate(date)+'</td><td>'+missTap+'</td><td><strong>'+ '<small class="tooltips" data-original-title="' + userData[0]['abridged_name'] + '"> ' + userData[0]['name_code'] + ' </small> - ' + formatDate(result['date']) + '</strong> at <strong>'+time+'</strong></td><td>'+description+'</td><td><a onClick="editAddManual('+Last_id+','+Missed_id+',\''+Table_name+'\')"><i class="fa fa-edit"></i></a> | <a onClick="deleteAddManual('+Last_id+','+Missed_id+',\''+Table_name+'\')"><i class="fa fa-close"></i></a></td> </tr>'); 
				$("#multiple_manual_attendance").val('');
                $("#multiple_manual_tap").val('');
                $("#multiple_manual_description").val('');
				  
				  $('#ProcessEntry').modal('toggle');
				  
					   
					   
                   }

               });
           }
       }
       $('#ProcessEntry').modal('toggle');

   });
   /*
   * Name: Set Not Acceptable
   * Description: Used to set N/A on json object values if they are empty or null
   *
   */
   
   var setNotAcceptable = function setNotAcceptable(jsonObj){
       for (var key in jsonObj) {
         if (jsonObj.hasOwnProperty(key)) {
           if( jsonObj[key] === '' || jsonObj[key] === null) 
               jsonObj[key] = 'N/A';
         }
       }
       return jsonObj;
   }
   
   /***** BEGIN - Search Result Highlight Function *****
   * Author: Atif Naseem (Thu Jul 20, 2017)
   * Email: atif.naseem22@gmail.com
   * Cel: +92-313-5521122
   * Description: Highlight all the search text
   *              in table columns.
   ****************************************************/
   
   var highlightSearchResult = function() {
   
   var search = $('#staffView_StaffList_Search'),
       content = $('#staffView_Table_StaffList'),
       matches = $(), index = 0;
   // Listen for the text input event
   search.on('input', function(e) {
       // Only search for strings 2 characters or more
       if (search.val().length >= 2) {
           // Use the highlight plugin
           content.highlight(search.val(), function(found) {                
               //found.parent().parent().css('background','yellow');
           });
       }
       else {
           content.highlightRestore();
       }
   });
   
   var termPattern;
   $.fn.highlight = function(term, callback) {
       return this.each(function() {
           var elem = $(this);
           if (!elem.data('highlight-original')) {
               // Save the original element content
               elem.data('highlight-original', elem.html());
           } else {
               // restore the original content
               elem.highlightRestore();
           }
           termPattern = new RegExp('(' + term + ')', 'ig');
           // Search the element's contents
           walk(elem);
           // Trigger the callback
           callback && callback(elem.find('.match'));
       });
   };
   
   
   $.fn.highlightRestore = function() {
       return this.each(function() {
           var elem = $(this);
           elem.html(elem.data('highlight-original'));
       });
   };
   
   
   
   function walk(elem) {
       elem.contents().each(function() {
           if (this.nodeType == 3) { // text node
               if (termPattern.test(this.nodeValue)) {
                   $(this).replaceWith(this.nodeValue.replace(termPattern, '<span class="match">$1</span>'));
               }
           } else {
               walk($(this));
           }
       });
   }
   };
   /***** END - Search Result Highlight Function *****/
   
   
   
   
   var clearStaffInfo = function() {
   $('.profile-userpic img').attr("src", '');
   $('.profile-usertitle-name').text('');
   $('.profile-usertitle-job').text('');
   $('.profile-usertitle-gtid').text('');
   $('.profile-usertitle-email').text('');
   $('.profile-usertitle-campus').text('');
   $('.currentLeave').text('0/10');
   $('.profile-usertitle-mobilePhone').text('');
   $('.profile-usertitle-bottomline').text('');
   
   /***** TIF-B: Personal Info *****/
   $('.tifb-basics-fullName').html('');
   $('.tifb-basics-religion').html('');
   $('.tifb-basics-gender').html('');
   $('.tifb-basics-maritalStatus').html('');
   $('.tifb-basics-nic').html('');
   $('.tifb-basics-nationality').html('');
   $('.tifb-basics-dob').html('');
   
   /***** TIF-B: Contact Info *****/
   $('.tifb-basics-mobilePhone').html('');
   $('.tifb-basics-landLine').html('');
   $('.tifb-basics-personalEmail').html('');
   
   /***** TIF-B: Address Info ****/
   $('.tifb-basics-apartmentNo').html('');
   $('.tifb-basics-buildingName').html('');
   $('.tifb-basics-region').html('');
   $('.tifb-basics-streetName').html('');
   $('.tifb-basics-plotNo').html('');
   $('.tifb-basics-subRegion').html('');
   
   /***** TIF-B: Official Info ****/
   $('.tifb-basics-nameCode').html('');
   $('.tifb-basics-empStatus').html('');
   
   /****** Roles ******************/
   $('.profile-userrole-report-one').html('');
   
   /********* Role 1 **************/
   $('.profile-userrole-role-one-img').css('display','none');
   $('.profile-userrole-role-one').html('');
   $('.profile-userrole-role-one-report').html('');
   
   /************ Role 2 **********/
   $('.profile-userrole-role-two-img').css('display','none');
   $('.profile-userrole-role-two').html('');
   $('.profile-userrole-role-two-report').html('');
   
   /*********** Profile Description ***********/
   
   $('.profile-user-detail').html('');
   
   /********* Attendance Status ****************/
   
   $('.profile-user-attendance img').attr('src','');
   
   
   
   
   /***** TIF-A: Clear All ****/
   $('#tab_1_2').html('');
   };
   
   
   
   
   
   /***** BEGIN - Tab Information - TIF-B *****/
   var get_Staff_TIFB = function(staffID) {
   var html = '';
   var educationSections = ['Others', 'Professional', 'University', 'College', 'School'];
   var educationNumbers = [5, 4, 3, 2, 1]
   
   $.ajax({
       type:"POST",
       cache:true,
       url:"{{url('/masterLayout/staff/getStaff_tifB')}}",
       data:{
           staff_id:staffID,
           "_token": "{{ csrf_token() }}",
       },
       success:function(result){
   
           var data = jQuery.parseJSON(result);
   
   
   
           for(var j=0; j < educationSections.length; j++) {
               html = html+'<h4 class="form-section headingBorderBottom">'+educationSections[j]+'</h4><div class="row">';
               for (var i = 0; i < data['education'].length; i++) {
                   if(data['education'][i]['level'] === educationNumbers[j]) {
                       data['education'][i] = setNotAcceptable(data['education'][i]);
                       html = html+'<div class="col-md-6"><div class="portlet light bordered lowPadding"><div class="portlet-body"><div class="col-md-3 padding0"><img src="{{ url("/metronic/pages/img/schoolIcon.jpg") }}" class="SchoolPlaceHolder" /></div><!-- col-md-3 --><div class="col-md-9 paddingRight0"><h5 class=" marginBottom0"><strong>'+data['education'][i]['institute']+'</strong></h5><h5 class="font-grey-cascade"><strong>'+data['education'][i]['qualification']+'</strong>, '+data['education'][i]['subjects']+'</h5><div class="col-md-6 padding0"><h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-graduation"></span>&nbsp;&nbsp;&nbsp;'+data['education'][i]['result']+'</h5></div><div class="col-md-6"><h5 class="marginBottom0 font-grey-cascade marginTop0"><span aria-hidden="true" class="icon-calendar"></span>&nbsp;&nbsp;&nbsp;'+data['education'][i]['year_of_completion']+'</h5></div></div><!-- col-md-9 --></div><!-- portlet-body --></div><!-- portlet --></div><!-- col-md-6 -->';
                   }
               }
               html = html+'</div>';
           }
           $('#tab_education').html(html);
   
   
   
   
           html = '';
           if(data['employment'][0]['organization'] != null){
               for (var i = 0; i < data['employment'].length; i++) {
                   data['employment'][i] = setNotAcceptable(data['employment'][i]);
                   html = html+'<div class="row">';
                   html = html+'<div class="col-md-12"><div class="portlet light lowPadding2 onlyBorderBottom marginBottom0"><div class="portlet-body"><div class="col-md-1 padding0"><img src="{{ url("/metronic/pages/img/BriefacaseIcon.jpg") }}" class="SchoolPlaceHolder" /></div><!-- col-md-3 --><div class="col-md-11 paddingRight0"><h5 class=" marginBottom0 font-grey-mint marginTop0"><strong>'+data['employment'][i]['organization']+'</strong> on the position of <strong>'+data['employment'][i]['designation']+'</strong></h5><h5 class="font-grey-salsa marginBottom4"><span class="positionDetail"><i class="fa fa-money tooltips" data-container="body" data-placement="top" data-original-title="Sallary"></i> <strong>'+data['employment'][i]['salary']+'</strong></span><span class="positionDetail"><i class="fa fa-calendar tooltips" data-container="body" data-placement="top" data-original-title="Tenure"></i> <strong>'+data['employment'][i]['from_year']+'</strong> to <strong>'+data['employment'][i]['to_year']+'</strong></span><span class="positionDetail"><img src="http://10.10.10.50/gsims/public/metronic/pages/img/blackboard.png" width="20" class="tooltips" data-container="body" data-placement="top" data-original-title="Classes Taught" /> <strong>'+data['employment'][i]['classes_taught']+' </strong></span><span class="positionDetail"><i class="icon-book-open tooltips" data-container="body" data-placement="top" data-original-title="Subjects Taught"></i> <strong>'+data['employment'][i]['subject_taught']+'</strong></span></h5><p class="font-grey-salsa marginBottom0">Reason for Leaving: <span class="font-grey-mint">'+data['employment'][i]['reason_for_leaving']+'</span> </p></div><!-- col-md-9 --></div><!-- portlet-body --></div><!-- portlet --></div><!-- col-md-6 -->';
                   html = html+'</div><!-- row -->';
               }
           }
           $('#tab_employment').html(html);
   
   
   
   
   
           html = '';
           if(data['fs'][0]['name'] != null){
   
               data['fs'][0] = setNotAcceptable(data['fs'][0]);
               data['fs'][1] = setNotAcceptable(data['fs'][1]);
   
               html = '<tr><td class="">'+data['fs'][0]['name']+'</td><td class="text-center"><strong>Name</strong></td><td class="">'+data['fs'][1]['name']+'</td></tr><tr><td>'+data['fs'][0]['profession']+'</td><td class="text-center"><strong>Profession</strong></td><td>'+data['fs'][1]['profession']+'</td></tr><tr><td>'+data['fs'][0]['qualification']+'</td><td class="text-center"><strong>Qualification</strong></td><td>'+data['fs'][1]['qualification']+'</td></tr><tr><td>'+data['fs'][0]['designation']+'</td><td class="text-center"><strong>Designation</strong></td><td>'+data['fs'][1]['designation']+'</td></tr><tr><td>'+data['fs'][0]['department']+'</td><td class="text-center"><strong>Department</strong></td><td>'+data['fs'][1]['department']+'</td></tr><tr><td>'+data['fs'][0]['company']+'</td><td class="text-center"><strong>Organisation</strong></td><td>'+data['fs'][1]['company']+'</td></tr><tr><td>'+data['fs'][0]['nic']+'</td><td class="text-center"><strong>CNIC</strong></td><td>'+data['fs'][1]['nic']+'</td></tr><tr><td>'+data['fs'][0]['mobile_phone']+'</td><td class="text-center"><strong>Mobile</strong></td><td>'+data['fs'][1]['mobile_phone']+'</td></tr><tr><td>'+data['fs'][0]['address']+'</td><td class="text-center"><strong>Address</strong></td><td>'+data['fs'][1]['address']+'</td></tr>';
           }
           $('#tab_parent_table').html(html);
   
   
   
   
   
           html = '';
           if(data['sc'][0]['gs_id'] != null){
               for (var i = 0; i < data['sc'].length; i++) {
                   data['sc'][i] = setNotAcceptable(data['sc'][i]);
                   html = html+'<div class="col-md-3"><div class="mt-card-item '+data['sc'][i]['html_class']+'"><div class="mt-card-avatar mt-overlay-4"><img src="{{ url("") }}/'+data['sc'][i]['photo500']+'" /><div class="mt-overlay"><h2>'+data['sc'][i]['class']+' <span class="font-yellow-lemon">('+data['sc'][i]['house_name']+')</span></h2><div class="mt-info font-white"><div class="mt-card-content"><p class="mt-card-desc font-white">GF-ID: <strong>'+data['sc'][i]['gfid']+'</strong> ('+(i+1)+'/'+data['sc'].length+')</p><div class="mt-card-social"></div></div></div></div><!-- mt-overlay --></div><!-- mt-card-avatar --><div class="mt-card-content"><h3 class="mt-card-name">'+data['sc'][i]['abridged_name']+'</h3><p class="mt-card-desc font-grey-mint">GS-ID: <strong>'+data['sc'][i]['gs_id']+'</strong> ('+data['sc'][i]['std_status_code']+')</p></div><!-- mt-card-content --></div><!-- mt-card-item --></div><!-- col-md-3 -->';
               }
           }
           $('#tab_staff_child').html(html);
   
   
   
   
   
           html = '';
           if(data['ac'][0]['name'] != null){
               data['ac'][0] = setNotAcceptable(data['ac'][0]);
               data['ac'][1] = setNotAcceptable(data['ac'][1]);
               html = '<tr><td>'+data['ac'][0]['name']+'</td><td class="text-center"><strong>Name</strong></td><td>'+data['ac'][1]['name']+'</td></tr><tr><td>'+data['ac'][0]['address']+'</td><td class="text-center"><strong>Address</strong></td><td>'+data['ac'][1]['address']+'</td></tr><tr><td>'+data['ac'][0]['email']+'</td><td class="text-center"><strong>Email</strong></td><td>'+data['ac'][1]['email']+'</td></tr><tr><td>'+data['ac'][0]['phone']+'</td><td class="text-center"><strong>Mobile</strong></td><td>'+data['ac'][1]['phone']+'</td></tr><tr><td>'+data['ac'][0]['relationships']+'</td><td class="text-center"><strong>Relationship</strong></td><td>'+data['ac'][1]['relationships']+'</td></tr>';
           }
           $('#tab_alternate_contact').html(html);
   
   
   
           data['other'][0] = setNotAcceptable(data['other'][0]);
           html = '<div class="form-body"><h3 class="form-section marginTop0 headingBorderBottom">Other Details</h3><div class="row"><div class="col-md-6"><div class="form-group"><label class="control-label col-md-5">Provident Fund :</label><div class="col-md-7"><p class="form-control-static bold"> '+data['other'][0]['pf']+' </p></div></div></div><!--/span--><div class="col-md-6"><div class="form-group"><label class="control-label col-md-5">NTN:</label><div class="col-md-7"><p class="form-control-static bold"> '+data['other'][0]['ntn']+' </p></div></div></div><!--/span--></div><!--/row--><div class="row"><div class="col-md-6"><div class="form-group"><label class="control-label col-md-5">EOBI/SESSI number: </label><div class="col-md-7"><p class="form-control-static bold"> '+data['other'][0]['eobi']+' / '+data['other'][0]['sessi']+'</p></div></div></div><!--/span--></div><!--/row--><h3 class="form-section headingBorderBottom">Bank Details</h3><div class="row"><div class="col-md-6"><div class="form-group"><label class="control-label col-md-5">Bank Name : </label><div class="col-md-7"><p class="form-control-static bold"> '+data['other'][0]['bank_name']+' </p></div></div></div><!--/span--><div class="col-md-6"><div class="form-group"><label class="control-label col-md-5">Branch :</label><div class="col-md-7"><p class="form-control-static bold"> '+data['other'][0]['bank_branch']+' </p></div></div></div><!--/span--></div><!--/row--><div class="row"><div class="col-md-6"><div class="form-group"><label class="control-label col-md-5">Account Number :</label><div class="col-md-7"><p class="form-control-static bold"> '+data['other'][0]['account_number']+' </p></div></div></div><!--/span--></div><!--/row--><h3 class="form-section headingBorderBottom">Takaful</h3><div class="row"><div class="col-md-6"><div class="form-group"><label class="control-label col-md-5">Self :</label><div class="col-md-7"><p class="form-control-static bold"> '+data['other'][0]['takaful_self']+' </p></div></div></div><!--/span--><div class="col-md-6"><div class="form-group"><label class="control-label col-md-5">Spouse :</label><div class="col-md-7"><p class="form-control-static bold"> '+data['other'][0]['takaful_spouse']+' </p></div></div></div><!--/span--></div><!--/row--><div class="row"><div class="col-md-6"><div class="form-group"><label class="control-label col-md-5">Children :</label><div class="col-md-7"><p class="form-control-static bold"> '+data['other'][0]['takaful_children']+' </p></div></div></div><!--/span--><div class="col-md-6"><div class="form-group"><label class="control-label col-md-5">Certificate :</label><div class="col-md-7"><p class="form-control-static bold"> '+data['other'][0]['takaful_crt']+' </p></div></div></div><!--/span--></div><!--/row--></div><!-- form-body -->';
           $('#tab_other').html(html);
       }
   });
   };
   /***** END - Tab Information - TIF-B *****/
   
   
   
   
   /***** BEGIN - Tab Information - TIF-B *****/
   var get_Staff_TIFA = function(GTID) {
   /***** Posting GT-ID and retrieving data ****/
   $.ajax({
       url: "{{url('/masterLayout/staff/getStaff_tifA')}}",
       type:"POST",
       cache:true,
       data: {
         GTID: GTID,
         "_token": "{{ csrf_token() }}",
       },
       success: function (response) {
           $('#tab_1_2').html(response);
       },
       error: function(jqXHR, textStatus, errorThrown) {
           console.log('Something wrong! error: ' + textStatus);
       }
   });
   };
   /***** END - Tab Information - TIF-B *****/
   
   
   
   
   
   
   
   
   
   
   var sortTable = function (f,n){
   var rows = $('#staffView_Table_StaffList tbody  tr').get();
   rows.sort(function(a, b) {
       var A = getVal(a);
       var B = getVal(b);
   
       if(A < B) {
           return -1*f;
       }
       if(A > B) {
           return 1*f;
       }
       return 0;
   });
   
   function getVal(elm){
       var v = $(elm).children('td').eq(n).text().toUpperCase();
       if($.isNumeric(v)){
           v = parseInt(v,10);
       }
       return v;
   }
   
   $.each(rows, function(index, row) {
       $('#staffView_Table_StaffList').children('tbody').append(row);
   });
   }
   
   



   var PayRollUpdate = function(id){
      var slider = document.getElementById(id);
         slider.noUiSlider.updateOptions({
         start: [0, 0, 0, 0],
         connect: [false, false, false, false, false],
         step: 2,
         tooltips: [false, false, false, false],
         disabled: true,
         range: {
           'min': 360,
           'max': 990
            },
      });
   }
   
   

   
   var pagefunction = function() {
   Demo.init();
   App.init();

      // Weekly Slider Intialize
   var slider = document.getElementById('weeklySlider');
       noUiSlider.create(slider, {
         start: [36, 100],
         connect: [false,true,false],
         range: {
           'min': 360,
           'max': 1000
         },
         tooltips:true,
         pips: {
           mode: 'steps',
           //values: [0, 720, 1439],
           filter: function filter(value, type) {
           //  console.log(type, value, value % 60);
             return value % (60 * 2) === 0 ? 1 : value % 60 === 0 ? 2 : 0;
           },
           //density: 2,
           format: {
             to: function to(value) {
               if (value % (60 * 2) === 0) {
                 return moment().startOf('day').add(value, 'minutes').format('HH:mm');
               }
               return '';
             },
             from: function from(value) {
               return value;
             }
           }
         },
         format: {
           to: function to(value) {
             //return value + ',-';
             return moment().startOf('day').add(value, 'minutes').format('HH:mm');
           },
           from: function from(value) {
             return value;
           }
         }
   });

       // Tap Slider Intailize
   var tapSlider = document.getElementById('tapSlider');
         noUiSlider.create(tapSlider, {
         start: [0,0],
         connect:true,
         range: {
           'min': 360,
           'max': 1000
         },
                  pips: {
           mode: 'steps',
           //values: [0, 720, 1439],
           filter: function filter(value, type) {
           //  console.log(type, value, value % 60);
             return value % (60 * 2) === 0 ? 1 : value % 60 === 0 ? 2 : 0;
           },
           //density: 2,
           format: {
             to: function to(value) {
               if (value % (60 * 2) === 0) {
                 return moment().startOf('day').add(value, 'minutes').format('HH:mm');
               }
               return '';
             },
             from: function from(value) {
               return value;
             }
           }
         },
         format: {
           to: function to(value) {
             //return value + ',-';
             return moment().startOf('day').add(value, 'minutes').format('HH:mm');
           },
           from: function from(value) {
             return value;
           }
         }

   });

   // Intaialize Absentia Slider      
   var AiAabsentia = document.getElementById('AiAabsentia');
         noUiSlider.create(AiAabsentia, {
         start: [0,0,0,0],
         tooltips: true,
         connect:[false,false,false,false,false],
         range: {
           'min': 360,
           'max': 1000
         },
         format: {
            to: function to(value) {
             //return value + ',-';
             return moment().startOf('day').add(value, 'minutes').format('HH:mm');
            },
            from: function from(value) {
             return value;
            }
      }
   });

      // Buffer In and Buffer Out Intializer
    var BufferSlider = document.getElementById('bufferTime');
       noUiSlider.create(BufferSlider, {
       start: [0],
       tooltips: true,
       connect:false,
       range: {
         'min': 360,
         'max': 1000,
       },
       format: {
          to: function to(value) {
           //return value + ',-';
           return moment().startOf('day').add(value, 'minutes').format('HH:mm');
          },
          from: function from(value) {
           return value;
          }
       }
    });


          // Payroll Attendance Intializer
    window.payrollSlider = document.getElementById('PayrollAttendance');
         noUiSlider.create(payrollSlider, {
         start: [0],
         tooltips: true,
         connect:false,
         range: {
           'min': 360,
           'max': 1000,
         },
         format: {
            to: function to(value) {
             //return value + ',-';
             return moment().startOf('day').add(value, 'minutes').format('HH:mm');
            },
            from: function from(value) {
             return value;
            }
         }
      });
   
   $('#staffView_StaffInfo').hide();
   
   /***** BEGIN - OnClick of Staff Name *****/
   $('.staffView_StaffName a').click(function(e) {

       e.preventDefault();
       clearStaffInfo();



       
       $('#staffView_StaffInfo').show();

   
   
       /***** Further Requests of AJAX *****/
       var me = $(this);
       if ( me.data('staffView_staffInfo_requestRunning') ) {
           return;
       }
       me.data('staffView_staffInfo_requestRunning', true);


       /***** Stop Further Request of AJAX *****/
   
   
       var staffID = $(this).attr('data-staffID');
       var staffGTID = $(this).attr('data-staffGTID');
       var staffAtd_detail = $(this).attr('data-src');
       var staffAtd_status = $(this).attr('data-title');
       var staffAtd_content = $(this).attr('data-content');
       $('#tab_1_3').data('staffID',staffID);

      var option = {
         'width':'980'
      }
      $('#datepaginator').datepaginator(option);
      $('#datepaginator').on('selectedDateChanged', function(event, date) {


         // $('.factor_remaining_deduction').text('0');
         // $('.factor_deduction_from').text('0');

         // $('.daily_buffer_used').text('0mins/10mins');
            


         var dateReport = new Date(date);
         var month = dateReport.getMonth()+1;
         var day = dateReport.getDate();
         var month_char = AddZeroDate(month);
         var day_char = AddZeroDate(day);
         dateReport = dateReport.getFullYear() +'-'+month_char+'-'+day_char;
         var dateLabel = formatDate(dateReport);
         $('.date_label').text('ATTENDANCE FOR '+dateLabel);
         //getWeeklySheet(dateReport,staffID);
         dailyReport(dateReport,staffID);         
      });
       
       $('.profile-userpic img').attr("src", "<?php echo url('/assets/img/loading.png'); ?>");
       $.ajax({
           type:"POST",
           cache:true,
           url:"{{url('/masterLayout/staff/getStaffInfo')}}",
           data:{
               staff_id:staffID,
               "_token": "{{ csrf_token() }}",
           },
           success:function(result){
               var data = jQuery.parseJSON(result);
               data['info'][0] = setNotAcceptable(data['info'][0]);


               
               // (1) display staff information


               $('.profile-userpic img').attr("src", data['info'][0]['photo500']);
               $('.profile-usertitle-name').text(data['info'][0]['abridged_name']);
               $('.profile-usertitle-job').text(data['info'][0]['c_topline']);
               $('.profile-usertitle-gtid').html(data['info'][0]['gt_id'] + " (" + data['info'][0]['status_code'] + ")");
               $('.profile-usertitle-email').html(data['info'][0]['email']);
                   $('.profile-usertitle-email').prop("href", 'mailto:'+data['info'][0]['email']+'@generations.edu.pk');
               $('.profile-usertitle-campus').html(data['info'][0]['campus']);
               $('.currentLeave').text(data['current_leave'][0]['currentLeave']);
               $('.profile-usertitle-mobilePhone').html(data['info'][0]['mobile_phone']);
               $('.profile-usertitle-bottomline').html(data['info'][0]['c_bottomline']+':<br>'+data['info'][0]['c_topline']+'</br>');
               $('.tap_in_campus').text(data['info'][0]['campus']);
               $('.absentia_staff_img').attr("src", data['info'][0]['photo500']);
               $('.absentia_staff_name').text(data['info'][0]['abridged_name']);
               $('.absentia_name_code').text(data['info'][0]['name_code']);
               $('.absentia_bottom_line').html(data['info'][0]['c_bottomline']+' & '+data['info'][0]['c_topline']);
   
   
   
   
               /***** TIF-B: Personal Info *****/
               $('.tifb-basics-fullName').html(data['info'][0]['name']);
               $('.tifb-basics-religion').html(data['info'][0]['religion']);
               $('.tifb-basics-gender').html(data['info'][0]['gender']);
               $('.tifb-basics-maritalStatus').html(data['info'][0]['marital_status']);
               $('.tifb-basics-nic').html(data['info'][0]['nic']);
               $('.tifb-basics-nationality').html(data['info'][0]['nationality']);
               $('.tifb-basics-dob').html(data['info'][0]['dob']);
   
   
               /***** TIF-B: Contact Info *****/
               $('.tifb-basics-mobilePhone').html(data['info'][0]['mobile_phone']);
               $('.tifb-basics-landLine').html(data['info'][0]['land_line']);
               $('.tifb-basics-personalEmail').html(data['info'][0]['emailpersonal']);
   
               /***** TIF-B: Official Info ****/
               $('.tifb-basics-nameCode').html(data['info'][0]['name_code']);
               $('.tifb-basics-empStatus').html(data['info'][0]['staff_status_name']);
   
               /***** TIF-B: Address Info ****/
               $('.tifb-basics-apartmentNo').html(data['info'][0]['apartment_no']);
               $('.tifb-basics-buildingName').html(data['info'][0]['building_name']);
               $('.tifb-basics-region').html(data['info'][0]['region']);
               $('.tifb-basics-streetName').html(data['info'][0]['street_name']);
               $('.tifb-basics-plotNo').html(data['info'][0]['plot_no']);
               $('.tifb-basics-subRegion').html(data['info'][0]['sub_region']);
   
   
   
               /***** Processor Bar *****/
               $('#staffView_ProcessorBar').html('');
               var html = '<td class="" style="padding-right:10px;"><img class="user-pic rounded tooltips" data-container="body" data-placement="top" data-original-title="'+data['info'][0]['gt_id']+'" src="'+data['info'][0]['photo150']+'" width="42"></td><td class="staffView_StaffName"><a href="javascript:;" class="primary-link tooltips" data-container="body" data-placement="top" data-original-title="'+data['info'][0]['name_code']+'" data-staffid="'+data['info'][0]['staff_id']+'" data-staffgtid="'+data['info'][0]['gt_id']+'">'+data['info'][0]['abridged_name']+'</a> - <small class="tooltips" data-container="body" data-placement="top" data-original-title="'+data['info'][0]['email']+'">'+data['info'][0]['name_code']+'</small><br><small class="shortHeight"><span class="tooltips" data-container="body" data-placement="top" data-original-title="'+data['info'][0]['c_topline']+'">'+data['info'][0]['c_bottomline']+': '+data['info'][0]['c_topline']+'</span></small></td>';
               $('#staffView_ProcessorBar').html(html);
   
               /***** Roles *******/
               if(data['roles'][0]['pm_report_to']){
   
                   data['reporting1'][0] = setNotAcceptable(data['reporting1'][0]);
                   data['roles'][0] = setNotAcceptable(data['roles'][0]);
   
                   if(data['reporting1'][0]['abridged_name']){
                       $('.profile-userrole-report-one').html('&#8594;'+data['reporting1'][0]['abridged_name']);
                   }else{
                       $('.profile-userrole-report-one').html('N/A');
                   }      
               }else{
                   $('.profile-userrole-report-one').html('&#8594;'+'N/A');
               }
               /***** Role 1 *******/
               
               if(data['reporting1']){
                   
                   data['reporting1'][0] = setNotAcceptable(data['reporting1'][0]);
                   data['roles'][0] = setNotAcceptable(data['roles'][0]);
                   
                   $('.profile-userrole-role-one-img').css('display','');
                   $('.profile-userrole-role-one').html(data['roles'][0]['role_title_tl']+' '+data['roles'][0]['role_title_bl']);
                   /**
                      Description: IF abridge Name is Null 
                   **/
                   if(data['reporting1'][0]['abridged_name']){
                       $('.profile-userrole-role-one-report').html('&#8594;'+data['reporting1'][0]['abridged_name']);
                   }else{
                       $('.profile-userrole-role-one-report').html('N/A');
                   } // end if else abridged Name
                   
               } // End if of reporting 1
   
   
               /**********Role 2**********/
               
               if(data['reporting2']){
                   
                   data['reporting2'][0] = setNotAcceptable(data['reporting2'][0]);
                   data['roles'][1] = setNotAcceptable(data['roles'][1]);
                   
                   $('.profile-userrole-role-two-img').css('display','');
                   $('.profile-userrole-role-two').html(data['roles'][1]['role_title_tl']+' '+data['roles'][1]['role_title_bl']);
                   /**
                      Description: IF abridge Name is Null 
                   **/
                   if(data['reporting2'][0]['abridged_name']){
                       $('.profile-userrole-role-two-report').html('&#8594;'+data['reporting2'][0]['abridged_name']);
                   }else{
                       $('.profile-userrole-role-two-report').html('');
                   } // End if else abridged Name
                   
               } // End if of reporting 2
   
               
               /************ Profile Details ***************/
   
               if(data['profile_description']){
                   data['profile_description'][0] = setNotAcceptable(data['profile_description'][0]);
                   $('.profile-user-detail').html(data['profile_description'][0]['time_profile']);
               }else{
                   $('.profile-user-detail').html('N/A');
               }
   
               /**************** User Attendance ********************/
               if(staffAtd_detail){
                   
                   $('.profile-user-attendance').html('<img style="margin-top: 0px;" src="'+staffAtd_detail+'" class="popovers" data-container="body" data-trigger="hover" data-placement="top" data-content="Tap In '+staffAtd_content+'" data-original-title="'+staffAtd_status+'" width="20" />');
   
                   $('.popovers').popover({
                       container: 'body'
                   });
               }
   
                  // Absentia Response
               if(data['absentia']){

                   var absentiaHTML = '';
   
                   for(var i=0; i< data['absentia'].length; i++){
					   
            
            
						absentiaHTML = absentiaHTML + '<tr class="absentia_table_row" id="absentia_table_row_'+data['absentia'][i].Absenia_id+'"><td>'+data['absentia'][i].title +'</td><td>'+data['absentia'][i].date +'</td><td>'+
                    changeTimeFormat(data['absentia'][i].From_time)  +'</td><td>'+changeTimeFormat(data['absentia'][i].to_time) +'</td><td>'+data['absentia'][i].description +'</td><td><a onClick="Edit_Absentia('+data['absentia'][i].Absenia_id +','+data['absentia'][i].Staff_id +')"><i class="fa fa-edit"></i></a> | <a onClick="delete_Absentia('+data['absentia'][i].Absenia_id +','+data['absentia'][i].Staff_id +')"><i class="fa fa-close"></i></a></td></tr>';

				   }
				
				 $('#absentia_table tbody').html(absentiaHTML);
               }

               // Manual Response
               if(data['manual']){


                   var manualHTML = '';
                   var fromTime;
                   var toTime;
				    var Tablename='';
   
                   for(var i=0; i< data['manual'].length; i++){
					   
					var Missedid=data['manual'][i].Missed_id;
						
					if( data['manual'][i].Table_name == 'In_Table' ){
						var Tablename='In_Table';
					}else{
						var Tablename='Out_Table';
					}
					var Manual_id=data['manual'][i].Manual_id;
					manualHTML = manualHTML + '<tr class="missedTapEven" data-missed_id="'+Missedid+'" data-table_name="'+Tablename+'" data-id="'+data['manual'][i].Manual_id+'"><td>'+data['manual'][i].date +'</td><td>'+data['manual'][i].manual_time 
                         +'</td><td><small class="tooltips" data-original-title="'+data['info'][0]['abridged_name']+'">'+data['info'][0]['name_code']+' </small> - '+data['manual'][i].created_time +'</td><td>'+(data['manual'][i].description === null ? '': data['manual'][i].description) +'</td> <td><a onClick="editAddManual('+Manual_id+','+Missedid+',\''+Tablename+'\')"><i class="fa fa-edit"></i></a> | <a onClick="deleteAddManual('+Manual_id+','+Missedid+',\''+Tablename+'\')"><i class="fa fa-close"></i></a></td> </tr>';
                   }
				   
  				$('#Missed_id').val(Missedid);
  				$('#Table_name').val(Tablename);
                  $('#manual_table tbody').html(manualHTML);
               }


               // Comments Response
               if(data['comments']){
                   var commentsHTML = '';
   
                   for(var i=0; i< data['comments'].length; i++){
                       
                       if(data['comments'][i].flag == 'system' && data['comments'][i].thresholdTapIN == 'Threshold Tap In' ){
   
                           commentsHTML = commentsHTML + '<li class="in commentsLI" data-val='+data['comments'][i].date+'><img class="avatar" alt="" src="assets/photos/hcm/150x150/staff/gs_logo.png"><div class="message"><span class="arrow"> </span><a href="javascript:;" class="name"> Threshold  </a><span class="datetime"> at <strong>'+ data['comments'][i].time_12hr+ '</strong> on <strong>'+ data['comments'][i].date_format +'</strong> </span><span class="body"> '+data['comments'][i].title +'. ' + data['comments'][i].name +' '+ data['comments'][i].date_format +' Threshold tap-in '+ data['comments'][i].time_12hr +'</span><input type="hidden" class="dateSearch" value='+data['comments'][i].date+' /></div></li>';
                       } else if(data['comments'][i].flag == 'system' && data['comments'][i].thresholdTapOut == 'Threshold Tap Out' ){
                           commentsHTML = commentsHTML + '<li class="in commentsLI"><img class="avatar" alt="" src="assets/photos/hcm/150x150/staff/gs_logo.png"><div class="message"><span class="arrow"> </span><a href="javascript:;" class="name"> Threshold  </a><span class="datetime"> at <strong>'+ data['comments'][i].time_12hr+ '</strong> on <strong>'+data['comments'][i].date_format + '</strong> </span><span class="body"> '+data['comments'][i].title +'. ' + data['comments'][i].name +' '+ data['comments'][i].date_format +' Threshold tap-out '+ data['comments'][i].time_12hr +'</span><input type="hidden" class="dateSearch" value='+data['comments'][i].date+' /></div></li>';
                       } else if(data['comments'][i].flag == 'system' && data['comments'][i].poTapIn == 'Po Tap In' ){
                           commentsHTML = commentsHTML + '<li class="in commentsLI"><img class="avatar" alt="" src="assets/photos/hcm/150x150/staff/gs_logo.png"><div class="message"><span class="arrow"> </span><a href="javascript:;" class="name"> Principal Office  </a><span class="datetime"> at <strong>'+ data['comments'][i].time_12hr+ '</strong> on <strong>'+data['comments'][i].date_format + '</strong> </span><span class="body"> '+data['comments'][i].title +'. ' + data['comments'][i].name +' '+ data['comments'][i].date_format +' Principal Office tap-in '+ data['comments'][i].time_12hr +'</span><input type="hidden" class="dateSearch" value='+data['comments'][i].date+' /></div></li>';
                       } else if(data['comments'][i].flag == 'system' && data['comments'][i].poTapOut == 'Po Tap out' ){
                           commentsHTML = commentsHTML + '<li class="in commentsLI"><img class="avatar" alt="" src="assets/photos/hcm/150x150/staff/gs_logo.png"><div class="message"><span class="arrow"> </span><a href="javascript:;" class="name"> Principal Office  </a><span class="datetime"> at <strong>'+ data['comments'][i].time_12hr+ '</strong> on <strong>'+ data['comments'][i].date_format + '</strong> </span><span class="body"> '+data['comments'][i].title +'. ' + data['comments'][i].name +' '+ data['comments'][i].date_format+' Principal Office tap-out '+ data['comments'][i].time_12hr +'</span><input type="hidden" class="dateSearch" value='+data['comments'][i].date+' /></div></li>';
                       } else if(data['comments'][i].flag == 'system' && data['comments'][i].vehicleTap == 'vehicle Tap IN' ){
                           commentsHTML = commentsHTML + '<li class="in commentsLI"><img class="avatar" alt="" src="assets/photos/hcm/150x150/staff/gs_logo.png"><div class="message"><span class="arrow"> </span><a href="javascript:;" class="name"> Vehicle  </a><span class="datetime"> at <strong>'+ data['comments'][i].time_12hr+ '</strong> on <strong>'+ data['comments'][i].date_format + '</strong> </span><span class="body"> '+data['comments'][i].title +'. ' + data['comments'][i].name +' '+ data['comments'][i].date_format +' Vehicle tap-in '+ data['comments'][i].time_12hr +'</span><input type="hidden" class="dateSearch" value='+data['comments'][i].date+' /></div></li>';
                       } else if(data['comments'][i].flag == 'system' && data['comments'][i].vehicleTap == 'vehicle Tap Out' ){
                           commentsHTML = commentsHTML + '<li class="in commentsLI"><img class="avatar" alt="" src="assets/photos/hcm/150x150/staff/gs_logo.png"><div class="message"><span class="arrow"> </span><a href="javascript:;" class="name"> Vehicle  </a><span class="datetime"> at <strong>'+ data['comments'][i].time_12hr+ '</strong> on <strong>'+ data['comments'][i].date_format + '</strong> </span><span class="body"> '+data['comments'][i].title +'. ' + data['comments'][i].date_format +' Vehicle tap-out '+ data['comments'][i].time_12hr +'</span><input type="hidden" class="dateSearch" value='+data['comments'][i].date+' /></div></li>';
                       } else if (data['comments'][i].flag == 'user' && data['comments'][i].comments != '') {
   
                           commentsHTML = commentsHTML + '<li class="out commentsLI"> <img class="avatar" alt="" src="assets/photos/hcm/150x150/staff/'+ data['comments'][i].emp_id+'.png"><div class="message"><span class="arrow"> </span><a href="javascript:;" class="name"> <strong>'+data['comments'][i].title +'. ' + data['comments'][i].name +'</strong> </a><span class="datetime"> at <strong>'+ data['comments'][i].time_12hr + '</strong> on <strong>'+ data['comments'][i].date_format +'</strong> </span><span class="body">' + data['comments'][i].comments + '</span><span class="commentCat"> '+data['comments'][i].comments_categories+' </span><input type="hidden" class="dateSearch" value='+data['comments'][i].date+' /></div></li>';
                       }
                       
                                                         
                   }
   
                   $('#stories').html(commentsHTML);
               }

               
			   
			    // leave Response
              
               if(data['leave_description']){
                    
                  var leaveHTML = '';

                  for(var i = 0 ;i < data['leave_description'].length;i++){
					if(data['leave_description'][i].leave_approve_status==1){ 
						var tr = 'approvedBorder'; 
					}  else{
						var tr = 'PendingapprovedBorder'; 
					}
                  leaveHTML = leaveHTML + '<tr  class="'+tr+'" data-id='+data['leave_description'][i].id+'><td>'+data['leave_description'][i].leave_title+'</small></td><td class=""><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested Compensation"></i> &nbsp; '+data['leave_description'][i].paid_compensation+' </td></tr>';
                  if(data['leave_description'][i].leave_approve_status==1){
                     leaveHTML = leaveHTML + '<tr><td class="font-green-jungle "><i class="fa fa-check tooltips" data-placement="bottom" data-original-title="Approved Compensation"></i> &nbsp; '+data['leave_description'][i].paid_percentage+'</td></tr>';
                  }

                  leaveHTML = leaveHTML + '</table></td><td><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested From"></i> &nbsp;'+data['leave_description'][i].leave_from+'</td></tr>';

                  if(data['leave_description'][i].leave_approve_date_from){
                     leaveHTML = leaveHTML + '<tr><td class="font-green-jungle "><i class="fa fa-check tooltips" data-placement="bottom" data-original-title="Approved From"></i> &nbsp; '+data['leave_description'][i].leave_approve_date_from+' </td></tr>';
                  }

                  leaveHTML = leaveHTML + '</table></td><td><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested till"></i> &nbsp; '+data['leave_description'][i].leave_to+'</td></tr>';

                  if(data['leave_description'][i].leave_approve_date_to){
                     leaveHTML = leaveHTML + '<tr><td class="font-green-jungle "><i class="fa fa-check tooltips" data-placement="bottom" data-original-title="Approved till"></i> &nbsp;'+data['leave_description'][i].leave_approve_date_to+' </td> </tr>';
                  }

                  leaveHTML = leaveHTML + '</table></td><td>'+data['leave_description'][i].leave_description+'</td><td class="text-center"><a onClick="ReWriteLeave('+data['leave_description'][i].id+')"><i class="fa fa-edit"></i></a> | <a href="#" data-container="body" data-placement="bottom" data-original-title="Print Leave Application" class="tooltips" ><span aria-hidden="true" class="icon-printer"></span></a> | <a href="#LeaveApproval" data-toggle="modal" data-container="body" data-placement="bottom" data-original-title="Leave Approval" class="tooltips" onClick="updateLeave('+data['leave_description'][i].id+')" ><i class="fa fa-check"></i></a> | <a onClick="delectLeave('+data['leave_description'][i].id+')"><i class="fa fa-close"></i></a></td></tr>';

                  }

                  $('#leave_table tbody').html(leaveHTML);
               }

               // Penalty Response
               if(data['penalty']){
                  var penaltyHTML = '';
                  for(var i = 0 ; i < data['penalty'].length; i++){
                     penaltyHTML = penaltyHTML + '<tr class="penaltyRowClass" data-id="'+data['penalty'][i].id+'"><td>'+data['penalty'][i].penalty_title+'</td><td>'+data['penalty'][i].penalty_day+'</td><td><strong>'+data['penalty'][i].penalty_date+'</td><td>'+data['penalty'][i].timestamp+'</td><td>'+data['penalty'][i].penalty_description+'</td> <td class="text-center"><a onClick="ReWriteLeavePenalties('+data['penalty'][i].id+')"><i class="fa fa-edit"></i></a> | <a onClick="delectLeavePenalties('+data['penalty'][i].id+')"><i class="fa fa-close"></i></a> </td> </tr>';
                  }

                  $('#penaltyTable tbody').html(penaltyHTML);   
               }

               // Exception Adjustment

               if(data['exception_adjustment']){
               var exception_adjustment = '';
				for (var i = 0 ; i < data['exception_adjustment'].length; i++){
					exception_adjustment = exception_adjustment + '<tr class="AddAdjustment" data-id="'+data['exception_adjustment'][i].id+'"><td>'+data['exception_adjustment'][i].adjustment_title+'</td><td>'+data['exception_adjustment'][i].adjustment_day+'days</td><td>'+data['exception_adjustment'][i].created+'</td><td>'+data['exception_adjustment'][i].adjustment_description+'</td> <td class="text-center"><a onClick="ReWriteAdjustment('+data['exception_adjustment'][i].id+')"><i class="fa fa-edit"></i></a> | <a onClick="deleteAdjustment('+data['exception_adjustment'][i].id+')"><i class="fa fa-close"></i></a> </td> </tr>';
                }

                  $('#adjustment_table tbody').html(exception_adjustment);
               }
			   
			   
               // Daily Attendance Report
               //console.log(data['daily_report_attendance']);
               // if(data['daily_report_attendance'].length > 0){

               //    $('.previous_el_balance').text(data['daily_report_attendance'][0].remaining_leave);
               //    $('.current_el_balance').text('0');
               // }
       
               var activeTab = $.trim($('#staffViewTabs li.active').text());
               $("a[href='#tab_1_1']").attr('data-staff',staffID);

               if(activeTab === 'TIF-B'){
                   get_Staff_TIFB(staffID);
                   $('#tab_1_1').data('staffID',staffID);
               }
               else if(activeTab === 'TIF-A'){
                   get_Staff_TIFA(staffGTID);
               
               }



            },


               
           /***** Further Requests of AJAX *****/
           complete: function() {
               me.data('staffView_staffInfo_requestRunning', false);
           }
           /***** Stop Further Request of AJAX *****/
   
       });
   });
   /***** END - OnClick of Staff Name *****/    
   
   
   
   
   
   
   
   
   
   
   
   
   
   /***** BEGIN - on Tab Change *****/
   $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
       var selectedTab = $.trim($(e.target).text()); // activated tab
       var GTID = $('.profile-usertitle-gtid').html().substr(0, 6); // getting staff GT-ID
       if(selectedTab === 'TIF-A'){
           get_Staff_TIFA(GTID);
       }if(selectedTab === 'TIF-B'){
           var staffID = $('a[href="#tab_1_1"]').attr('data-staff');
           get_Staff_TIFB(staffID);
       }
   });
   /***** END - on Tab Change *****/
   
   
   $("#staffView_StaffList_Search").keyup(function(){
       
       var searchText = $("#staffView_StaffList_Search").val();
   
       //First letter of each word should be capital
       var arr = searchText.split(' ');
       var result = "";
       for (var x=0; x<arr.length; x++)
           result+=arr[x].substring(0,1).toUpperCase()+arr[x].substring(1)+' ';
       searchText = result.substring(0, result.length-1);
   
       $(tableRecords).each(function(){
           var lineStr = $(this).text();
           if( lineStr.indexOf(searchText) === -1 ){
               $(this).hide();
           } else {
   
               //Get Html of profile_StaffName
               var src_str = $(this).find('.profile_StaffName').html();
               //Remove mark if html already contains
               src_str = src_str.replace("<mark>", "" );
               src_str = src_str.replace("</mark>", "" );
               //Add mark on search words 
               if(searchText !== ""){
                   src_str = src_str.replace(searchText, "<mark>" + searchText + "</mark>");
   
               }
               //Update new html with mark on it
               $(this).find('.profile_StaffName').html(src_str)               
               $(this).show();
           }
       });
       var totalRow =  $('#staffView_Table_StaffList tr:visible').length - 1;
       $('#staffView_StaffList_Total').text('STAFF LIST - ' + totalRow); 
   
   })
   
   
   $("#sparkline_bar").sparkline([8, 9, 10, 11, 10, 10, 12, 10, 10, 11, 9, 12], {
       type: 'bar',
       width: '100',
       barWidth: 5,
       height: '55',
       barColor: '#f36a5b',
       negBarColor: '#e02222'
   });
   
   $("#sparkline_bar2").sparkline([9, 11, 12, 11, 12, 10, 10, 14, 12, 11, 11, 12], {
       type: 'bar',
       width: '100',
       barWidth: 5,
       height: '55',
       barColor: '#5c9bd1',
       negBarColor: '#e02222'
   });
   
   /*
   * Function Name : removeMark
   * Description:  remove Mark is used to remove highlight from staff name
   */
   
   var removeMark = function removeMark() {
   
       var b = document.getElementsByTagName('mark');
   
       while(b.length) {
           var parent = b[ 0 ].parentNode;
           while( b[ 0 ].firstChild ) {
               parent.insertBefore(  b[ 0 ].firstChild, b[ 0 ] );
           }
            parent.removeChild( b[ 0 ] );
       }
   }
   
   /*
   * Function Name : multiFilter
   * Description:  Multiple select checkbox filter function used to filter data on table using multiple values from one or more select checkboxes
   */
   var multiFilter = function multiFilter(){
   
       var ddlFilterTableRow = $('select.ddlFilterTableRow');
   
   
       ddlFilterTableRow.attr('disabled', 'disabled');
   
       var records = $('#staffView_Table_StaffList').find('.Row');
       records.hide();
   
       var critriaAttributes = [];
       ddlFilterTableRow.each(function() {
           var $this = $(this),
               $selectedLength = $this.find(':selected').length,
               $critriaAttribute = '';
   
           if ($selectedLength > 0 && $this.val() != '0') {
               if ($selectedLength == 1) {
                   $critriaAttribute += '[data-' + $this.data('attribute') + '*="' + $this.val() + '"]';
               } else {
                   var $startDataAttribute = '[data-' + $this.data('attribute') + '*="',
                       $endDataAttribute = '"]',
                       $selectedValues = $this.val().toString();
   
                   $critriaAttribute += $startDataAttribute + $selectedValues.replaceAll(',', ($endDataAttribute + ',' + $startDataAttribute)) + $endDataAttribute;
               }
               critriaAttributes.push($critriaAttribute);
           }
       });
                   
   
       var $showRecords = records;
       if (critriaAttributes.length > 0) {
           $.each(critriaAttributes, function(i, filterValue) {
               $showRecords = $showRecords.filter(filterValue);
           });
       }
   
       tableRecords = $showRecords.show();
   
       ddlFilterTableRow.removeAttr('disabled');
   }
   
   /***** BEGIN - Apply filter searching *****/
   $('#staffView_filter_btn .applyFilter').click(function() {
       //Remove mark
       removeMark();
       multiFilter();
   
       $('.toggler').show();
       $('.toggler-close').hide();
       $('.theme-panel > .theme-options').hide();
       $('#staffView_StaffList_Search').val('');
   
       $('.toggler2').show();
       $('.toggler2-close').hide();
       $('.theme-panel > .theme-options2').hide();
       $('#staffView_StaffList_Search').val('');
   
       var totalRow =  $('#staffView_Table_StaffList tr:visible').length - 1;
       $('#staffView_StaffList_Total').text('STAFF LIST - ' + totalRow);
   });
   /***** END - Apply filter searching *****/
   
   
   
   
   /***** BEGIN - Cancel filter searching *****/
   $('#staffView_filter_btn .clearFilter').click(function() {
       
       //Remove mark
       removeMark();
   
       //Deselect all if selected 
       $('#StaffView_Filter_Profile').multiselect("deselectAll", false).multiselect("refresh");
       $('#StaffView_Filter_Department').multiselect("deselectAll", false).multiselect("refresh");
       $('#StaffView_Filter_Campus').multiselect("deselectAll", false).multiselect("refresh");
       $('#StaffView_Filter_AtdStd').multiselect("deselectAll", false).multiselect("refresh");
       $('#StaffView_Filter_StaffStd').multiselect("deselectAll", false).multiselect("refresh");
   
       $('#StaffView_Filter_Profile').val('');
       $('#StaffView_Filter_Department').val('');
       $('#StaffView_Filter_Campus').val('');
       $('#StaffView_Filter_AtdStd').val('');
       
   
       $('#staffView_StaffList_Search').val('');
       tableRecords = $('#staffView_Table_StaffList').find('.Row');
       tableRecords.show();
   
       var totalRow =  $('#staffView_Table_StaffList tr:visible').length - 1;
       $('#staffView_StaffList_Total').text('STAFF LIST - ' + totalRow);
   });
   /***** END - Cancel filter searching *****/
   
   
   
   
   /***** BEGIN - Apply Searching *****/
   $('#staffView_sort_btn .applySort').click(function() {
      
       //Remove mark
       removeMark();
   
       $('.toggler').show();
       $('.toggler-close').hide();
       $('.theme-panel > .theme-options').hide();
       $('#staffView_StaffList_Search').val('');
   
       $('.toggler2').show();
       $('.toggler2-close').hide();
       $('.theme-panel > .theme-options2').hide();
       $('#staffView_StaffList_Search').val('');
   
   
   
       /**********************************
       * 0: Image
       * 1: Name and Card Bottom Line
       * 2: Attendance title and score
       * 3: Name Code
       * 4: GT-ID
       * 5: TT Profile Name
       * 6: Card Bottom Line (Department)
       * 7: Campus
       * 8: Attendance Title
       * 9: Abridged Name
       **********************************/
       var sortName = $('#StaffView_Sort_Name').find(":selected").val();
       if(sortName != null){
           if(sortName === 'A to Z'){
               sortTable(1,9);
           }else if(sortName === 'Z to A'){
               sortTable(-1,9);
           }
       }
       var sortDepartment = $('#StaffView_Sort_Department').find(":selected").val();
       if(sortDepartment != null){
           if(sortDepartment === 'A to Z'){
               sortTable(1,6);
           }else if(sortDepartment === 'Z to A'){
               sortTable(-1,6);
           }
       }
       var sortAtdScore= $('#StaffView_Sort_AtdScore').find(":selected").val();
       if(sortAtdScore != null){
           if(sortAtdScore === 'L to H'){
               sortTable(1,8);
           }else if(sortAtdScore === 'H to L'){
               sortTable(-1,8);
           }
       }
       
   
       var totalRow =  $('#staffView_Table_StaffList tr:visible').length - 1;
       $('#staffView_StaffList_Total').text('STAFF LIST - ' + totalRow);
   });
   /***** END - Apply Searching *****/
   
   
   
   
   /***** BEGIN - Cancel Searching *****/
   $('#staffView_sort_btn .clearSort').click(function() {
       //Remove mark
       removeMark();
       //Sort table in Ascending order (A to Z)
       sortTable(1,9);
       
       $('#StaffView_Sort_Name').val('');
       $('#StaffView_Sort_Department').val('');
       $('#StaffView_Sort_AtdScore').val('');
   
       $('#staffView_StaffList_Search').val('');
       //tableRecords = $('#staffView_Table_StaffList').find('.Row');
       tableRecords.show();
   
       var totalRow =  $('#staffView_Table_StaffList tr:visible').length - 1;
       $('#staffView_StaffList_Total').text('STAFF LIST - ' + totalRow);
   });
   /***** END - Cancel Searching *****/
   
   
   
   
   /* */
   
   
   
   /* */
   
   
   
   /* Staff List Left Section Scroll Header */
   $('.fixed-height-NoScroll').scroll(function() {
       var y = $(this).scrollTop(); 
       if (y >= 200) {
           var totalRow =  $('#staffView_Table_StaffList tr:visible').length - 1;
           $('.headTitle').text('STAFF LIST - ' + totalRow);
           $('.headTitle').fadeIn(); 
       } else {
           $('.headTitle').fadeOut();
       }
   });
   
   /* Staff Detail Right Section Scroll Header */
   $('#staffView_StaffInfo').scroll(function() {
       var y = $(this).scrollTop(); 
       if (y >= 100) {
           //var totalRow =  $('#staffView_Table_StaffList tr:visible').length - 1;
           //$('.headTitle').text('STAFF LIST - ' + totalRow);
           $('.headRightDetails').fadeIn(); 
       } else {
           $('.headRightDetails').fadeOut();
       }
   }); 
   };
   // var changeTimeFormat = function changeTimeFormat(time){
   
   //     time = time.split(":");
   //     time = time[0]  + ':' + time[1] + ( (time[0] < 12) ? ' am' : ' pm' );
   //     return time;
   // }


   var changeTimeFormat = function changeTimeFormat(time){

      time = time.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

      if (time.length > 1) { // If time format correct
       time = time.slice (1);  // Remove full string match value
       time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
       time[0] = +time[0] % 12 || 12; // Adjust hours
      }
      return time.join (''); // return adjusted time or original string

   }
   
  
   
   
   
/*
	Following functionalities are developed by Kashif Solangi
*/   
 
var Edit_Absentia = function(Absentia_id, Staff_id ){
$("#Edit_Absentia_id_hidden").val(Absentia_id);
$("#Edit_Absentia_id_staff_id_hidden").val(Staff_id);


if( Staff_id > 0 ){

$.ajax({
   type:"POST",
   cache:true,
   url:"{{url('/masterLayout/staff/Edit_Get_Absentia')}}",
   data:{
	   "staff_id":Staff_id,
	   "Absentia_id":Absentia_id,
	   "_token": "{{ csrf_token() }}"
   },
   success:function(result){
	var data = jQuery.parseJSON(result);
	
	
	$('#Absenia_Contents').html(data["h"]);
	
	
	$('#AddAIAE').modal('toggle');
	
	
   }
});
}
	   
	   
	   
}



   
   var addAbsentiaE = function addAbsentiaE(){
	   
	   var Attendance_in_id = $("#Attendance_in_id").val();
	   var Attendance_out_id = $("#Attendance_out_id").val();
	   var Attendance_des_id = $("#Attendance_des_id").val();
	   var Edit_Absentia_id_hidden = $("#Edit_Absentia_id_hidden").val();
	   var Edit_Absentia_id_staff_id_hidden = $("#Edit_Absentia_id_staff_id_hidden").val();

	   
	   
       var date = $("#absentia_date_edit").val();
       var title = $("#absentia_title_edit").val();
       var start_time = $("#absentia_startTime_edit").val();
       var end_time = $("#absentia_endTime_edit").val();
       var description = $("#absentia_description_edit").val();
       var staffID = Edit_Absentia_id_staff_id_hidden;
	  
       if( Attendance_in_id !== '' && Attendance_out_id !== '' && Attendance_des_id !== '' && end_time !== ''){
   
           $.ajax({
               type:"POST",
               cache:true,
               url:"{{url('/masterLayout/staff/editAbsentia')}}",
               data:{
                   "staff_id":staffID,
                   "date" : date,
                   "title" : title,
                   "start_time" : start_time,
                   "end_time" : end_time,
                   "description" : description,
				   "Attendance_in_id" : Attendance_in_id,
				   "Attendance_out_id" : Attendance_out_id,
				   "Attendance_des_id" : Attendance_des_id,
				   "Edit_Absentia_id_hidden" : Edit_Absentia_id_hidden,
				   
                   "_token": "{{ csrf_token() }}"
               },
               success:function(result){
				//$("#absentia_table_row_"+Edit_Absentia_id_hidden).remove();
			    //$('#absentia_table').append('<tr class="absentia_table_row" id="absentia_table_row_'+Edit_Absentia_id_hidden+'"> <td>'+ title +'</td> <td>'+ formatDate(date) +'</td> <td>'+ changeTimeFormat(start_time) +'<br /></td> <td>'+ changeTimeFormat(end_time) +'</td> <td>'+ description +'</td><td><a onClick="Edit_Absentia('+Edit_Absentia_id_hidden+','+staffID+')"><i class="fa fa-edit"></i></a> | <a onClick="delete_Absentia('+Edit_Absentia_id_hidden+','+staffID+')"><i class="fa fa-close"></i></a></td> </tr>');
                //$('#AddAIAE').modal('toggle');
				$('#absentia_table > tbody tr').each(function(index) { 
				var $this = $(this);
				var filter = $this.attr('id');
				var id = "absentia_table_row_"+Edit_Absentia_id_hidden;
				if(filter == id){
						var leaveHTML = '';
						leaveHTML = '<tr class="absentia_table_row" id="absentia_table_row_'+Edit_Absentia_id_hidden+'"> <td>'+ title +'</td> <td>'+ formatDate(date) +'</td> <td>'+ changeTimeFormat(start_time) +'<br /></td> <td>'+ changeTimeFormat(end_time) +'</td> <td>'+ description +'</td><td><a onClick="Edit_Absentia('+Edit_Absentia_id_hidden+','+staffID+')"><i class="fa fa-edit"></i></a> | <a onClick="delete_Absentia('+Edit_Absentia_id_hidden+','+staffID+')"><i class="fa fa-close"></i></a></td> </tr>';
						$(this).replaceWith(leaveHTML);
					 }
				 });
				$('#AddAIAE').modal('toggle');	
				
                $("#absentia_date_edit").val('');
                $("#absentia_title_edit").val('');
                $("#absentia_startTime_edit").val('');
                $("#absentia_endTime_edit").val('');
                $("#absentia_description_edit").val('');
               }
           });
       }
   }
   
var delete_Absentia = function(Absentia_id, Staff_id ){
	$("#absentia_table_row_"+Absentia_id).remove();
	
	if( Absentia_id > 0){
		$.ajax({
            type:"POST",
            cache:true,
            url:"{{url('/masterLayout/staff/deleteAbsentia')}}",
            data:{ "Absentia_id":Absentia_id, "Staff_id":Staff_id, "_token": "{{ csrf_token() }}" },
            success:function(result){ }
        });
    }
}


   var ReWriteLeave = function(id){
     var update_id =  id;
     $.ajax({
         type:"POST",
         url:"{{url('/masterLayout/staff/ReWriteLeave')}}",
         data:{
            "id":id,
            "_token": "{{ csrf_token() }}"
         },
         success:function(e){

            var data = JSON.parse(e);
			
			$("#Leave_main_containter").html( data.LT );
			$('#LeaveAppForEdit').modal('toggle');
			
			var paid_percentage_edit = $("#paid_compensation_edit").val();
			
			$("#limit_edit").bootstrapSwitch();
			
			if( paid_percentage_edit == 1){ 
				$("#limit_edit").bootstrapSwitch('state', true);
			}else{
				$("#limit_edit").bootstrapSwitch('state', false);
			}	
			
			
          



         }

     });
   }
   
   
   
   
   var edit_leave = function(){


      $("#limit_edit").bootstrapSwitch();
      var  paid_compensation=$('#limit_edit').bootstrapSwitch('state');//returns true or false
      if(paid_compensation == true){
         paid_compensation = 1;
      }else{
         paid_compensation = 0;
      }
	  
	  var Leave_Application_id = $('#Leave_Application_id').val();

      var staffID = $('#tab_1_3').data('staffID');
		var leave_title = $('#leave_title_edit').val();
      var leave_type = $('#Select_Leave_Type_edit option:selected').val();
      var leave_from = $('#leave_from_edit').val();
      var leave_to = $('#leave_to_edit').val();
      var leave_comment = $('#leave_comment_edit').val();
	  
	  
	  var paid_compensation_percentage = $('#paid_percentage_edit').val();
	  var leave_approve_status_edit = $('#leave_approve_status_edit').val();
	  var approve_from = $('#leave_approve_date_from_edit').val();
	  var approve_to = $('#leave_approve_date_to_edit').val();
	  
	  

      var paid_compensation_display;
      if(paid_compensation == 1){
         paid_compensation_display = 'Yes';
      }else{
         paid_compensation_display = 'No';
      }
	  if(leave_type != '' && leave_title != '' && leave_from != '' && leave_to != ''){

      $.ajax({
            type:"POST",
            cache:true,
            url:"{{url('/masterLayout/staff/RWriteLeave')}}",
            data:{
               "staff_id":staffID,
			   "Leave_Application_id":Leave_Application_id,
               "leave_title":leave_title,
               "leave_type":leave_type,
               "leave_from":leave_from,
               "leave_to":leave_to,
               "leave_comment":leave_comment,
               "paid_compensation":paid_compensation,
                "_token": "{{ csrf_token() }}"
            },
            success:function(result){

            
				
				
		   $('#leave_table > tbody tr').each(function(index) {
            var $this = $(this);
            var filter = $this.attr('data-id');
			var id = Leave_Application_id;
            if(filter == id){
               var leaveHTML = '';

               leaveHTML = leaveHTML + '<tr  class="approvedBorder" data-id='+id+'><td>'+leave_title+'</small></td><td class=""><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested Compensation"></i> &nbsp; '+paid_compensation_display+' </td></tr>';
               if(leave_approve_status_edit==1){
                  leaveHTML = leaveHTML + '<tr><td class="font-green-jungle "><i class="fa fa-check tooltips" data-placement="bottom" data-original-title="Approved Compensation"></i> &nbsp; '+paid_compensation_percentage+'<span>% paid</span></td></tr>';
                 }

				leaveHTML = leaveHTML + '</table></td><td><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested From"></i> &nbsp;'+formatDate(leave_from)+'</td></tr>';

               if(leave_approve_status_edit==1){
                  leaveHTML = leaveHTML + '<tr><td class="font-green-jungle "><i class="fa fa-check tooltips" data-placement="bottom" data-original-title="Approved From"></i> &nbsp; '+formatDate(approve_from)+' </td></tr>';
                 }

               leaveHTML = leaveHTML + '</table></td><td><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested till"></i> &nbsp; '+formatDate(leave_to)+'</td></tr>';

               if(leave_approve_status_edit==1){
                  leaveHTML = leaveHTML + '<tr><td class="font-green-jungle "><i class="fa fa-check tooltips" data-placement="bottom" data-original-title="Approved till"></i> &nbsp;'+formatDate(approve_to)+' </td> </tr>';
                 }

               //leaveHTML = leaveHTML + '</table></td><td>'+leave_comment+'</td><td class="text-center"><a href="#" data-container="body" data-placement="bottom" data-original-title="Print Leave Application" class="tooltips" ><span aria-hidden="true" class="icon-printer"></span></a> | <a href="#LeaveApproval" data-toggle="modal" data-container="body" data-placement="bottom" data-original-title="Leave Approval" class="tooltips" onClick="updateLeave('+id+')" ><i class="fa fa-check"></i></a></td></tr>';
			   
			   leaveHTML = leaveHTML + '</table></td><td>'+leave_comment+'</td><td class="text-center"><a onClick="ReWriteLeave('+id+')"><i class="fa fa-edit"></i></a> | <a href="#" data-container="body" data-placement="bottom" data-original-title="Print Leave Application" class="tooltips" ><span aria-hidden="true" class="icon-printer"></span></a> | <a href="#LeaveApproval" data-toggle="modal" data-container="body" data-placement="bottom" data-original-title="Leave Approval" class="tooltips" onClick="updateLeave('+id+')" ><i class="fa fa-check"></i></a> | <a onClick="delectLeave('+id+')"><i class="fa fa-close"></i></a></td></tr>';
			   $(this).replaceWith(leaveHTML);
            }

         });
		 
		 
		 
				$('#LeaveAppForEdit').modal('toggle');
               
            }

         });
     }



   }
   
   
   var delectLeave = function(Action_id)
   {
	   $('#leave_table > tbody tr').each(function(index) {
            var $this = $(this);
            var filter = $this.attr('data-id');
			var id = Action_id;
            if(filter == id){ $this.remove(); }
		});
		
		if( Action_id > 0){
			$.ajax({
				type:"POST",
				cache:true,
				url:"{{url('/masterLayout/staff/deleteLeaveApp')}}",
				data:{ "Action_id":Action_id, "_token": "{{ csrf_token() }}" },
				success:function(result){ }
			});
		}
			
	   
	   
   }
   
   
   
   
   
var ReWriteLeavePenalties = function(ID){
$.ajax({
   type:"POST",
   cache:true,
   url:"{{url('/masterLayout/staff/editPenalties')}}",
   data:{
	"ID":ID,
	"_token": "{{ csrf_token() }}"
   },
   success:function(res){
	var data = jQuery.parseJSON(res);
	$("#Penalties_Contents").html('');
	$("#Penalties_Contents").html(data.h);
	$("#UnAuthLeavePenEdit").modal('toggle');
   }
});
}

   var editPenalty = function(){

      var penalty_title = $('#penalty_title_edit').val();
      var penalty_day =  $('#penalty_day_edit').val();
      var penalty_from = $('#penalty_from_edit').val();
      var penalty_to = $('#penalty_to_edit').val();
      var penalty_description = $('#penalty_description_edit').val();
	  
      var penalty_id_edit = $('#penalty_id_edit').val();
	  var Staff_id = $('#staff_id_edit').val();
	  
      // console.log(penalty_to);

      if(penalty_id_edit != '' && penalty_title != '' && penalty_from != '' && penalty_to != '' && penalty_day != ''){
         $.ajax({
            type:"POST",
            cache:true,
            url:"{{url('/masterLayout/staff/OverRightPenalties')}}",
            data:{
			   "penalty_id_edit":penalty_id_edit,
			   "Staff_id":Staff_id,
               "penalty_title":penalty_title,
               "penalty_day":penalty_day,
               "penalty_from":penalty_from,
               "penalty_to":penalty_to,
               "penalty_description":penalty_description,
               "_token":"{{ csrf_token() }}"
            },
            success:function(e){
               var curdate = new Date();
               var hours = AddZeroDate(curdate.getHours());
               var min = AddZeroDate(curdate.getMinutes());
               var time = changeTimeFormat(hours+ ":" +min);
			   
			   
			 
			   
			   
			$('#penaltyTable > tbody tr').each(function(index) {
            var $this = $(this);
            var filter = $this.attr('data-id');
			var id = penalty_id_edit;
            if(filter == id){
				var leaveHTML = '';
				leaveHTML = leaveHTML + '<tr class="penaltyRowClass" data-id="'+penalty_id_edit+'"><td>'+penalty_title+'</td><td>'+penalty_day+'</td><td>'+formatDate(penalty_from)+'-'+formatDate(penalty_to)+'</td><td>'+formatDate(curdate)+'<span> at <span>'+changeTimeFormat(time)+'</td><td>'+penalty_description+'</td> <td class="text-center"><a onClick="ReWriteLeavePenalties('+penalty_id_edit+')"><i class="fa fa-edit"></i></a> | <a onClick="delectLeavePenalties('+penalty_id_edit+')"><i class="fa fa-close"></i></a> </td> </tr>';
				$(this).replaceWith(leaveHTML);
            }
			});
			$('#penalty_title_edit').val('');
            $('#penalty_day_edit').val('');
            $('#penalty_from_edit').val('');
            $('#penalty_to_edit').val('');
            $('#penalty_description_edit').val('');
			$("#UnAuthLeavePenEdit").modal('toggle');
			}
         });
      }
   }
   
var delectLeavePenalties = function(Action_id){
	
$('#penaltyTable > tbody tr').each(function(index) {
	var $this = $(this);
	var filter = $this.attr('data-id');
	var id = Action_id;
	if(filter == id){ $this.remove(); }
});
if( Action_id > 0){
	$.ajax({
		type:"POST",
		cache:true,
		url:"{{url('/masterLayout/staff/deletePenalties')}}",
		data:{ "Action_id":Action_id, "_token": "{{ csrf_token() }}" },
		success:function(result){ }
	});
}

}
   
   
   
var ReWriteAdjustment = function(ID){
$.ajax({
   type:"POST",
   cache:true,
   url:"{{url('/masterLayout/staff/editAdjustment')}}",
   data:{
	"ID":ID,
	"_token": "{{ csrf_token() }}"
   },
   success:function(res){
	var data = jQuery.parseJSON(res);
	$("#Adjustment_Contents").html('');
	$("#Adjustment_Contents").html(data.h);
	$("#ExceptionalAdjustmentFormEdit").modal('toggle');
   }
});
}
   
   
var editAdjustment = function(){
	
	  var adjustment_title = $('#adjustment_title_edit').val();
      var adjustment_no = $('#adjustment_no_edit').val();
      var adjustment_description = $('#adjustment_description_edit').val();
	  
	  var adjustment_id = $('#adjustment_id_edit').val();
      var staff_id = $('#adjustment_staff_edit').val();
	  
	  
      if(adjustment_title != '' && adjustment_no != ''){
         $.ajax({
            type:"POST",
            cache:true,
            data:{
               "adjustment_title":adjustment_title,
               "adjustment_no":adjustment_no,
               "adjustment_description":adjustment_description,
               "staff_id":staff_id,
			   "adjustment_id":adjustment_id,
               "_token":"{{csrf_token()}}"
            },
            url:"{{url('/masterLayout/staff/OverRightAdjustment')}}",
            success:function(e){
				var data = JSON.parse(e);
				var Last_id = data.id;
				var date = new Date();
				var hours = AddZeroDate(date.getHours());
				var min = AddZeroDate(date.getMinutes());
				var time = changeTimeFormat(hours+ ":" +min);
			   
            $('#adjustment_table > tbody tr').each(function(index) {
            var $this = $(this);
            var filter = $this.attr('data-id');
			var id = Last_id;
            if(filter == id){
				var leaveHTML = '';
				leaveHTML = leaveHTML + '<tr class="AddAdjustment" data-id="'+Last_id+'"><td>'+adjustment_title+'</td><td>'+adjustment_no+'days</td><td>'+formatDate(date)+'<span> at </span>'+time+'</td><td>'+adjustment_description+'</td> <td class="text-center"><a onClick="ReWriteAdjustment('+Last_id+')"><i class="fa fa-edit"></i></a> | <a onClick="deleteAdjustment('+Last_id+')"><i class="fa fa-close"></i></a> </td> </tr>';
				$(this).replaceWith(leaveHTML);
            }
			});
			$('#adjustment_title_edit').val('');
            $('#adjustment_no_edit').val('');
            $('#adjustment_description_edit').val('');
            $('#adjustment_id_edit').val('');
            $('#adjustment_staff_edit').val('');
			$('#ExceptionalAdjustmentFormEdit').modal('toggle');
            }
         });
      }
}
   
var deleteAdjustment = function(Action_id)
{
	$('#adjustment_table > tbody tr').each(function(index) {
		var $this = $(this);
		var filter = $this.attr('data-id');
		var id = Action_id;
		if(filter == id){ $this.remove(); }
	});
	if( Action_id > 0){
		$.ajax({
			type:"POST",
			cache:true,
			url:"{{url('/masterLayout/staff/deleteAdjustment')}}",
			data:{ "Action_id":Action_id, "_token": "{{ csrf_token() }}" },
			success:function(result){ }
		});
	}
}



var editAddManual = function(ID,Missed_id,Table_name){
$.ajax({
   type:"POST",
   cache:true,
   url:"{{url('/masterLayout/staff/editAddManual')}}",
   data:{
	"ID":ID,
	"Missed_id":Missed_id,
	"Table_name":Table_name,
	"_token": "{{ csrf_token() }}"
   },
   success:function(res){
	var data = jQuery.parseJSON(res);
	$("#Manual_Form_Entry").html('');
	$("#Manual_Form_Entry").html(data.h);
	$("#ManualAttendanceFormEdit").modal('toggle');
   }
});
}






var edit_manual = function(ID){
	
var date = $("#manual_attendance_edit").val();
var missTap = $("#manual_missTap_edit").val();
var description = $("#manual_description_edit").val();
var Manual_id = $('#manual_id_edit').val();
var Tap_id = $('#tap_id_edit').val();

var Missed_id = $('#Missed_id_edit').val();
var Table_name = $('#Table_name_edit').val();

if(date != '' && missTap != '' && Tap_id != ''){
	$.ajax({
		type:"POST",
		cache:true,
		url:"{{url('/masterLayout/staff/OverRightAddManual')}}",
		data:{
		   "Manual_id":Manual_id,
		   "Tap_id":Tap_id,
		   "Missed_id":Missed_id,
		   "Table_name":Table_name,
		   "date" : date,
		   "missTap" : missTap,
		   "description" : description,
		   "_token": "{{ csrf_token() }}"
	   },
	   success:function(result){
		  var time = new Date();
		  var hours = AddZeroDate(time.getHours());
		  var min = AddZeroDate(time.getMinutes());
		  time = changeTimeFormat(hours+ ":" +min);
		  if(missTap == ''){
			 missTap = 'no tap in';
		  }else{
			 missTap = changeTimeFormat(missTap);
		  }
			var r = JSON.parse(result);
			var Last_id = r.id;
			
			var Missed_id = r.Missed_id;
			var Table_name = r.Table_name;
			
		  
			$('#manual_table > tbody tr').each(function(index) {
            var $this = $(this);
            var filter = $this.attr('data-id');
			var id = Last_id;
            if(filter == id){
				var leaveHTML = '';
				leaveHTML = leaveHTML + '<tr class="missedTapEven" data-id="'+Last_id+'"><td>'+formatDate(date)+'</td><td>'+missTap+'</td><td><strong>'+ '<small class="tooltips" data-original-title="abridged_name"> name_code </small> - '+ formatDate(date)+'</strong> at <strong>'+time+'</strong></td><td>'+description+'</td><td><a onClick="editAddManual('+Last_id+','+Missed_id+',\''+Table_name+'\')"><i class="fa fa-edit"></i></a> | <a onClick="deleteAddManual('+Last_id+','+Missed_id+',\''+Table_name+'\')"><i class="fa fa-close"></i></a></td> </tr>';
				$(this).replaceWith(leaveHTML);
            }
			});
			
			
			
			$("#manual_attendance_edit").val('');
			$("#manual_missTap_edit").val('');
			$("#manual_description_edit").val('');
			$('#ManualAttendanceFormEdit').modal('toggle');
	   }

	});
}

		
}




var deleteAddManual = function(Action_id, Missed_id, Table_name)
{
	$('#manual_table > tbody tr').each(function(index) {
		var $this = $(this);
		var filter = $this.attr('data-id');
		var id = Action_id;
		if(filter == id){ $this.remove(); }
	});
	if( Action_id > 0){
		$.ajax({
			type:"POST",
			cache:true,
			url:"{{url('/masterLayout/staff/deleteAddManual')}}",
			data:{ 
				"Action_id":Action_id, 
				"Missed_id":Missed_id, 
				"Table_name":Table_name, 
				"_token": "{{ csrf_token() }}" 
				},
			success:function(result){

			}
		});
	}
}





/* ========================= End Kashif Solangi  */


   var addAbsentia = function addAbsentia(){
       var date = $("#absentia_date").val();
       var title = $("#absentia_title").val();
       var start_time = $("#absentia_startTime").val();
       var end_time = $("#absentia_endTime").val();
       var description = $("#absentia_description").val();
       var staffID = $('#tab_1_3').data('staffID');
       if( date !== '' && title !== '' && start_time !== '' && end_time !== ''){
   
           $.ajax({
               type:"POST",
               cache:true,
               url:"{{url('/masterLayout/staff/addAbsentia')}}",
               data:{
                   "staff_id":staffID,
                   "date" : date,
                   "title" : title,
                   "start_time" : start_time,
                   "end_time" : end_time,
                   "description" : description,
                   "_token": "{{ csrf_token() }}"
               },
               success:function(result){
   
                   var data = jQuery.parseJSON(result);
				   var Edit_Absentia_id_hidden = data.Last_id;
				   $('#absentia_table').append('<tr class="absentia_table_row" id="absentia_table_row_'+Edit_Absentia_id_hidden+'"> <td>'+ title +'</td> <td>'+ formatDate(date) +'</td> <td>'+ changeTimeFormat(start_time) +'<br /></td> <td>'+ changeTimeFormat(end_time) +'</td> <td>'+ description +'</td><td><a onClick="Edit_Absentia('+Edit_Absentia_id_hidden+','+staffID+')"><i class="fa fa-edit"></i></a> | <a onClick="delete_Absentia('+Edit_Absentia_id_hidden+','+staffID+')"><i class="fa fa-close"></i></a></td> </tr>');
					
					
                   $('#AddAIA').modal('toggle');
                   $("#absentia_date").val('');
                   $("#absentia_title").val('');
                   $("#absentia_startTime").val('');
                   $("#absentia_endTime").val('');
                   $("#absentia_description").val('');
				   
               }
           });
       }
   
   
   }


   var insert_manual = function(){
       
       var date = $("#manual_attendance").val();
       var missTap = $("#manual_missTap").val();

       var description = $("#manual_description").val();
       var staffID = $('#tab_1_3').data('staffID');

        if(date != '' &&  missTap != ''  && staffID != ''){
            $.ajax({
                type:"POST",
                cache:true,
                url:"{{url('/masterLayout/staff/addManual')}}",
                data:{
                   "staff_id":staffID,
                   "date" : date,
                   "missTap" : missTap,
                   "description" : description,
                   "_token": "{{ csrf_token() }}"
               },
               success:function(result){
                  var time = new Date();
                  var hours = AddZeroDate(time.getHours());
                  var min = AddZeroDate(time.getMinutes());
                  time = changeTimeFormat(hours+ ":" +min);
                  if(missTap == ''){
                     missTap = 'no tap in';
                  }else{
                     missTap = changeTimeFormat(missTap);
                  }

             
                  //var userData = result['userInfo']['info'];
                  //$('#ManualAttendanceForm').modal('toggle');
                  //$('#manual_table').append('<tr><td>'+formatDate(date)+'</td><td>'+missTap+'</td><td><strong>'+ '<small class="tooltips" data-original-title="'+userData[0]['abridged_name']+'">'+userData[0]['name_code']+ '</small> - '+ formatDate(result['date'])+'</strong> at <strong>'+time+'</strong></td><td>'+description+'</td></tr>');      
				  
				var userData = result['userInfo']['info'];
				var Last_id = result['Last_id'];
				var Missed_id= result['Missed_id'];
				var Table_name= result['Table_name'];
				$('#manual_table').append('<tr class="missedTapEven" data-id="'+Last_id+'"><td>'+formatDate(date)+'</td><td>'+missTap+'</td><td><strong>'+ '<small class="tooltips" data-original-title="' + userData[0]['abridged_name'] + '"> ' + userData[0]['name_code'] + ' </small> - ' + formatDate(result['date']) + '</strong> at <strong>'+time+'</strong></td><td>'+description+'</td><td><a onClick="editAddManual('+Last_id+','+Missed_id+',\''+Table_name+'\')"><i class="fa fa-edit"></i></a> | <a onClick="deleteAddManual('+Last_id+','+Missed_id+',\''+Table_name+'\')"><i class="fa fa-close"></i></a></td> </tr>'); 
				$("#manual_attendance").val('');
				$("#manual_missTap").val('');
				$("#manual_description").val('');
				$('#ManualAttendanceForm').modal('toggle');
               }

            });
        }
   }



   // Get Date by AJAX

   var getAttendanceDate = function(){
      var staffID = $('#tab_1_3').data('staffID');
      var date  = document.getElementById('manual_attendance').value;
      $.ajax({
         "type":"POST",
         cache:true,
         url:"{{ url('/masterLayout/staff/getManualAttendance') }}",
         data:{
            date:date,
            staff_id:staffID,
            "_token":"{{csrf_token()}}"
         },
         
         success:function(e){
            $('#manual_tap_in').val('');
            $('#manual_tap_out').val('');
            var data = JSON.parse(e);
            var tap_in = '';
            var tap_out = '';

            data[0].manual_tap_in ? tap_in = data[0].manual_tap_in : tap_in = data[0].tap_in;
            data[0].manual_tap_out ? tap_out = data[0].manual_tap_out : tap_out = data[0].tap_out;

            $('#manual_tap_in').val(tap_in);
            $('#manual_tap_out').val(tap_out);
            $('#manual_tap_in').attr('data-id','1');
            $('#manual_tap_out').attr('data-id','1');


            // TAP IN FLAG
            if(!tap_in){
               $('#manual_tap_in').attr('data-id','1');
            }else{
               $('#manual_tap_in').attr('data-id','0');
            }

            // TAP OUT FLAG
            if(!tap_out){
               $('#manual_tap_out').attr('data-id','1');
            }else{
               $('#manual_tap_out').attr('data-id','0');
            }

         }
      });

   }
   

   // Leave Inserttion 

   var add_leave = function(){


   

	  
	  

			   
			   
			   
     $("#limit").bootstrapSwitch();
	  
      var  paid_compensation=$('#limit').bootstrapSwitch('state');//returns true or false
      if(paid_compensation == true){
         paid_compensation = 1;
      }else{
         paid_compensation = 0;
      }

      var staffID = $('#tab_1_3').data('staffID');

      var leave_title = $('#leave_title').val();
      var leave_type = $('.leave_type option:selected').val();
      var leave_from = $('#leave_from').val();
      var leave_to = $('#leave_to').val();
      var leave_comment = $('#leave_comment').val();

      var paid_compensation_display;
      if(paid_compensation == 1){
         paid_compensation_display = 'Yes';
      }else{
         paid_compensation_display = 'No';
      }


     if(leave_type != '' && leave_title != '' && leave_from != '' && leave_to != ''){

      $.ajax({
            type:"POST",
            cache:true,
            url:"{{url('/masterLayout/staff/addLeave')}}",
            data:{
               "staff_id":staffID,
               "leave_title":leave_title,
               "leave_type":leave_type,
               "leave_from":leave_from,
               "leave_to":leave_to,
               "leave_comment":leave_comment,
               "paid_compensation":paid_compensation,
                "_token": "{{ csrf_token() }}"
            },
            success:function(result){

             //  $('#leave_table').append('<tr class="PendingapprovedBorder" data-id='+result+'><td>'+leave_title+'</td><td><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested Compensation"></i> &nbsp; '+paid_compensation_display+'</td></tr></table></td><td><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested From"></i> &nbsp; '+formatDate(leave_from)+' </td></tr></table></td><td><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested till"></i> &nbsp; '+formatDate(leave_to)+'</td></tr></table></td><td>'+leave_comment+'</td><td class="text-center"><a href="#" data-container="body" data-placement="bottom" data-original-title="Print Leave Application" class="tooltips" ><span aria-hidden="true" class="icon-printer"></span></a> | <a href="#LeaveApproval"  data-toggle="modal" data-container="body" data-placement="bottom" data-original-title="Leave Approval" class="tooltips" onClick="updateLeave('+result+')"><i class="fa fa-check"></i></a></td></tr>');
				$('#leave_table').append('<tr class="PendingapprovedBorder" data-id='+result+'><td>'+leave_title+'</td><td><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested Compensation"></i> &nbsp; '+paid_compensation_display+'</td></tr></table></td><td><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested From"></i> &nbsp; '+formatDate(leave_from)+' </td></tr></table></td><td><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested till"></i> &nbsp; '+formatDate(leave_to)+'</td></tr></table></td><td>'+leave_comment+'</td><td class="text-center"><a onClick="ReWriteLeave('+result+')"><i class="fa fa-edit"></i></a> | <a href="#" data-container="body" data-placement="bottom" data-original-title="Print Leave Application" class="tooltips" ><span aria-hidden="true" class="icon-printer"></span></a> | <a href="#LeaveApproval"  data-toggle="modal" data-container="body" data-placement="bottom" data-original-title="Leave Approval" class="tooltips" onClick="updateLeave('+result+')"><i class="fa fa-check"></i> | <a onClick="delectLeave('+result+')"><i class="fa fa-close"></i></a></td></tr>');
               $('#LeaveApp').modal('toggle'); 
            }

         });
     }



   }

   var updateLeave = function(id){
     var update_id =  id;
     $.ajax({
         type:"POST",
         url:"{{url('/masterLayout/staff/get_updateLeave')}}",
         data:{
            "id":id,
            "_token": "{{ csrf_token() }}"
         },
         success:function(e){

            var data = JSON.parse(e);
            $('#leave_title_id').val(data[0].id);
            $('#leave_title_update').val(data[0].leave_title);

            $('#leave_type_update').prop('disabled',true);
            $("#leave_type_update option[value='"+data[0].leave_type+"']").prop('selected', true);

            $('#leave_type_update').val(data[0].leave_type);
            $('#leave_from_update').val(data[0].leave_from);
            $('#leave_to_update').val(data[0].leave_to);
            $('#leave_comment_update').val(data[0].leave_description);
            $('#approve_from').val(data[0].leave_approve_date_from);
            $('#approve_to').val(data[0].leave_approve_date_to);
            $('#paid_compensation_percentage').val(data[0].paid_percentage);


            $("#changeSwitch").bootstrapSwitch();
            if(data[0].paid_compensation == 1){
               $("#changeSwitch").bootstrapSwitch('state', true);
            }else{
               $("#changeSwitch").bootstrapSwitch('state', false);
            }


           $("#change-color-switch").bootstrapSwitch();
            if(data[0].leave_approve_status == 1){
               $("#change-color-switch").bootstrapSwitch('state', true);
            }else{
               $("#change-color-switch").bootstrapSwitch('state', false);
            }



         }

     });
   }

   var LeaveUpdateById = function(){
      
      var id =  $('#leave_title_id').val();
      var leave_title = $('#leave_title_update').val();
      var leave_type = $('#leave_type_update option:selected').val();
      var leave_from = $('#leave_from_update').val();
      var leave_to = $('#leave_to_update').val();
      var leave_comment =  $('#leave_comment_update').val();
      var approve_from = $('#approve_from').val();
      var approve_to = $('#approve_to').val();
      var paid_compensation_percentage = $('#paid_compensation_percentage').val();

      // For Approval
      $("#change-color-switch").bootstrapSwitch();
      var  LeaveApproval =$('#change-color-switch').bootstrapSwitch('state');//returns true or false
      if(LeaveApproval == true){
         LeaveApproval = 1;
      }else{
         LeaveApproval = 0;
      }


      // For Paid Compensation

      $("#changeSwitch").bootstrapSwitch();
      var  paid_compensation =$('#changeSwitch').bootstrapSwitch('state');//returns true or false
      if(paid_compensation == true){
         paid_compensation = 1;
      }else{
         paid_compensation = 0;

      }


      if(leave_type != '' && leave_title != '' && leave_from != '' && leave_to != ''){

      /***** Further Requests of AJAX *****/
      var me = $(this);
      if (me.data('staffView_staffInfo_requestLeave')){
         return;
      }
      me.data('staffView_staffInfo_requestLeave', true);
        /***** Stop Further Request of AJAX *****/
      $.ajax({
         type:"POST",
         cache:true,
         url:"{{url('/masterLayout/staff/LeaveUpdate')}}",
         data:{
            "id":id,
            "leave_title":leave_title,
            "leave_type":leave_type,
            "leave_from":leave_from,
            "leave_to":leave_to,
            "leave_comment":leave_comment,
            "approve_from":approve_from,
            "approve_to":approve_to,
            "paid_compensation":paid_compensation,
            "paid_compensation_percentage" :paid_compensation_percentage,
            "LeaveApproval":LeaveApproval,
            "_token" : "{{ csrf_token() }}"

         },
        
         success:function(e){
            //clearLeave();
             $('#LeaveApproval').modal('toggle');

            if(paid_compensation == 1){
               paid_compensation = 'Yes';
            }else{
               paid_compensation = 'No';
            }

         $('#leave_table > tbody tr').each(function(index) {
            var $this = $(this);
            var filter = $this.attr('data-id');
            if(filter == id){
               var leaveHTML = '';
			   
			     if(LeaveApproval==1){ 
			   var tr1 = 'approvedBorder';
			   }else{
				   var tr1 = 'PendingapprovedBorder';
			   }
			   

               leaveHTML = leaveHTML + '<tr  class="'+tr1+'" data-id='+id+'><td>'+leave_title+'</small></td><td class=""><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested Compensation"></i> &nbsp; '+paid_compensation+' </td></tr>';
               if(LeaveApproval==1){
                  leaveHTML = leaveHTML + '<tr><td class="font-green-jungle "><i class="fa fa-check tooltips" data-placement="bottom" data-original-title="Approved Compensation"></i> &nbsp; '+paid_compensation_percentage+'<span>% paid</span></td></tr>';
                 }

               leaveHTML = leaveHTML + '</table></td><td><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested From"></i> &nbsp;'+formatDate(leave_from)+'</td></tr>';

               if(approve_from){
                  leaveHTML = leaveHTML + '<tr><td class="font-green-jungle "><i class="fa fa-check tooltips" data-placement="bottom" data-original-title="Approved From"></i> &nbsp; '+formatDate(approve_from)+' </td></tr>';
                 }

               leaveHTML = leaveHTML + '</table></td><td><table width="100%" border="0" class="" style="margin:0;"><tr><td><i class="fa fa-file-text-o tooltips" data-placement="bottom" data-original-title="Requested till"></i> &nbsp; '+formatDate(leave_to)+'</td></tr>';

               if(approve_to){
                  leaveHTML = leaveHTML + '<tr><td class="font-green-jungle "><i class="fa fa-check tooltips" data-placement="bottom" data-original-title="Approved till"></i> &nbsp;'+formatDate(approve_to)+' </td> </tr>';
                 }

              // leaveHTML = leaveHTML + '</table></td><td>'+leave_comment+'</td><td class="text-center"><a href="#" data-container="body" data-placement="bottom" data-original-title="Print Leave Application" class="tooltips" ><span aria-hidden="true" class="icon-printer"></span></a> | <a href="#LeaveApproval" data-toggle="modal" data-container="body" data-placement="bottom" data-original-title="Leave Approval" class="tooltips" onClick="updateLeave('+id+')" ><i class="fa fa-check"></i></a></td></tr>';
			  leaveHTML = leaveHTML + '</table></td><td>'+leave_comment+'</td><td class="text-center"> <a onClick="ReWriteLeave('+id+')"><i class="fa fa-edit"></i></a> | <a href="#" data-container="body" data-placement="bottom" data-original-title="Print Leave Application" class="tooltips" ><span aria-hidden="true" class="icon-printer"></span></a> | <a href="#LeaveApproval" data-toggle="modal" data-container="body" data-placement="bottom" data-original-title="Leave Approval" class="tooltips" onClick="updateLeave('+id+')" ><i class="fa fa-check"></i> | <a onClick="delectLeave('+id+')"><i class="fa fa-close"> </a></td></tr>';

                $(this).replaceWith(leaveHTML);
            }

         });  

         },
         complete: function() {
            me.data('staffView_staffInfo_requestLeave', false);
         }
      });

      }
   }


   var clearLeave = function(){


      // Update Clear Fields
      var id =  $('#leave_title_id').val('');
      var leave_title = $('#leave_title_update').val('');
      //var leave_type = $('#leave_type_update option:selected').val(0);
      var leave_from = $('#leave_from_update').val('');
      var leave_to = $('#leave_to_update').val('');
      var leave_comment =  $('#leave_comment_update').val('');
      var approve_from = $('#approve_from').val('');
      var approve_to = $('#approve_to').val('');
      var paid_compensation_percentage = $('#paid_compensation_percentage').val('');
      $("#change-color-switch").bootstrapSwitch();
      $("#changeSwitch").bootstrapSwitch();
      $("#change-color-switch").bootstrapSwitch('state', false);
      $("#changeSwitch").bootstrapSwitch('state', false);

      // Update Insert Fields
      var id =  $('#leave_title').val('');
      var leave_title = $('#leave_title').val('');
      //var leave_type = $('#leave_type option:selected').val(0);
      var leave_from = $('#leave_from').val('');
      var leave_to = $('#leave_to').val('');
      var leave_comment =  $('#leave_comment').val('');
      $("#change-color-switch").bootstrapSwitch();
      $("#changeSwitch").bootstrapSwitch();
      $("#change-color-switch").bootstrapSwitch('state', false);
      $("#changeSwitch").bootstrapSwitch('state', false);

   }


   var addPenalty = function(){

      var penalty_title = $('#penalty_title').val();
      var penalty_day =  $('#penalty_day').val();
      var penalty_from = $('#penalty_from').val();
      var penalty_to = $('#penalty_to').val();
      var penalty_description = $('#penalty_description').val();
      var staff_id = $('#tab_1_3').data('staffID');
      // console.log(penalty_to);

      if(staff_id != '' && penalty_title != '' && penalty_from != '' && penalty_to != '' && penalty_day != ''){
         $.ajax({
            type:"POST",
            cache:true,
            url:"{{url('/masterLayout/addPenalty')}}",
            data:{
               "penalty_title":penalty_title,
               "penalty_day":penalty_day,
               "penalty_from":penalty_from,
               "penalty_to":penalty_to,
               "penalty_description":penalty_description,
               "staff_id":staff_id,
               "_token":"{{ csrf_token() }}"
            },
            success:function(res){
               var curdate = new Date();
               var hours = AddZeroDate(curdate.getHours());
               var min = AddZeroDate(curdate.getMinutes());
               var time = changeTimeFormat(hours+ ":" +min);
			   
               /*$('#penaltyTable').append('<tr><td>'+penalty_title+'</td><td>'+penalty_day+'</td><td>'+formatDate(penalty_from)+'-'+formatDate(penalty_to)+'</td><td>'+formatDate(curdate)+'<span> at <span>'+changeTimeFormat(time)+'</td><td>'+penalty_description+'</td></tr>'); 
               $('#penalty_title').val('');
               $('#penalty_day').val('');
               $('#penalty_from').val('');
               $('#penalty_to').val('');
               $('#penalty_description').val(''); */
			   
			   
			   var data = JSON.parse(res);
			   var Last_id = data.id;
               $('#penaltyTable').append('<tr class="penaltyRowClass" data-id="'+Last_id+'"><td>'+penalty_title+'</td><td>'+penalty_day+'</td><td>'+formatDate(penalty_from)+'-'+formatDate(penalty_to)+'</td><td>'+formatDate(curdate)+'<span> at <span>'+changeTimeFormat(time)+'</td><td>'+penalty_description+'</td> <td class="text-center"><a onClick="ReWriteLeavePenalties('+Last_id+')"><i class="fa fa-edit"></i></a> | <a onClick="delectLeavePenalties('+Last_id+')"><i class="fa fa-close"></i></a> </td> </tr>'); 
               $('#penalty_title').val('');
               $('#penalty_day').val('');
               $('#penalty_from').val('');
               $('#penalty_to').val('');
               $('#penalty_description').val('');
			   $("#UnAuthLeavePen").modal("toggle");
			   
			   
            }
         });
      }
   }

   var addAdjustment = function(){

      var adjustment_title = $('#adjustment_title').val();
      var adjustment_no = $('#adjustment_no').val();
      var adjustment_description = $('#adjustment_description').val();
      var staff_id = $('#tab_1_3').data('staffID');
      if(adjustment_title != '' && adjustment_no != ''){
         $.ajax({
            type:"POST",
            cache:true,
            data:{
               "adjustment_title":adjustment_title,
               "adjustment_no":adjustment_no,
               "adjustment_description":adjustment_description,
               "staff_id":staff_id,
               "_token":"{{csrf_token()}}"
            },
            url:"{{url('/masterLayout/addAdjustment')}}",
            success:function(e){

             var data = JSON.parse(e);
				var Last_id = data.id;
               var date = new Date();
               var hours = AddZeroDate(date.getHours());
               var min = AddZeroDate(date.getMinutes());
               var time = changeTimeFormat(hours+ ":" +min);
			   
               var adjustmentHTML = '';
               adjustmentHTML = '<tr class="AddAdjustment" data-id="'+Last_id+'"><td>'+adjustment_title+'</td><td>'+adjustment_no+'days</td><td>'+formatDate(date)+'<span> at </span>'+time+'</td><td>'+adjustment_description+'</td> <td class="text-center"><a onClick="ReWriteAdjustment('+Last_id+')"><i class="fa fa-edit"></i></a> | <a onClick="deleteAdjustment('+Last_id+')"><i class="fa fa-close"></i></a> </td> </tr>';
               $('#ExceptionalAdjustmentForm').modal('toggle');
               $('#adjustment_table tbody').append(adjustmentHTML);
			   
            }

         });
      }
   }

   // var getWeeklySheet = function(date,staffID){
   //    $.ajax({
   //       type:"POST",
   //       cache:true,
   //       data:{
   //          'date':date,
   //          'staff_id':staffID,
   //          "_token":"{{csrf_token()}}"
   //       },
   //       url:"{{ url('/masterLayout/getWeeklySheetTap')}}",
   //       success:function(e){
   //          var weekly = JSON.parse(e);
   //          if(weekly.length != 0){
   //             // Weekly Time Sheet
   //             if(weekly[0].time_in && weekly[0].time_out){
   //                sliderWeekly(timeToMinute(weekly[0].time_in),timeToMinute(weekly[0].time_out));
   //             }
   //          }
   //       }
   //    })
   // }


   var dailyReport = function(date,staffID){
      $.ajax({
         type:"POST",
         cache:true,
         data:{ 
          "date":date,
          "staff_id":staffID,
          "_token":"{{csrf_token()}}" 
         },
         url:"{{ url('/masterLayout/getDailyReport')}}",
         success:function(e){
         var data = JSON.parse(e);
         if(data.length != 0){
               
            console.log(data);

             // Weekly Time Sheet
                  var weekly_time_sheet_in = timeToMinute(data[0].day_time_in);
                  var weekly_time_sheet_out = timeToMinute(data[0].day_time_out);

                  var compliance_in = data[0].compliance_in;
                  var compliance_out = data[0].compliance_out;
                  var compliance_duration = data[0].compliance_duration;

                  var buffer_used = data[0].buffer_minutes_in;
                  var buffer_used_out = data[0].buffer_minutes_out;

                  if(buffer_used_out == ''){
                    buffer_used_out = 0
                  }

                  if(buffer_used == ''){
                    buffer_used = 0;
                  }

                  var factor = data[0].fuctor;
                  var factor_deduction = data[0].fuctor_nod;
                  var previous_leave = data[0].prv_rem_leaves;
                  var current_leave = data[0].rem_leaves;




                  // Actual Tap In And Tapout
                  var time = data[0].tap_time;
                  console.log('time ------'+time);
                  var time_flag = data[0].tap_io;
                  if(time){
                     time = time.split(',');
                     var timeMinute = timeToMinuteForArray(time);
                  }
                  if(time_flag){
                     time_flag = time_flag.split(',');
                  }

                  // // Compilance Calculation
                  

                  // for(var i =0 ; i < time_flag.length ; i++){

                  //    if( (time_flag[i] == '1' || time_flag[i] == '8') && (timeMinute[i] <= weekly_time_sheet_in || buffer_used)){
                  //       compilance_in = 1;

                  //    }

                  //   if( (time_flag[i] == '0' || time_flag[i] == '9') && timeMinute[i] >= weekly_time_sheet_out ){
                  //       compilance_out = 1;
                  //    }

                  // }



                                    // Absentia Allocated

                  var absentia_allocated_time = data[0].ab_rec_time;
                  var absentia_flag = data[0].ab_rec_io;

                  if(absentia_allocated_time){
                       absentia_allocated_time = absentia_allocated_time.split(',');
                       var absentia_allocated = timeToMinuteForArray(absentia_allocated_time);
                  }else{
                     absentia_allocated_time = '';
                  }

                  if(absentia_flag){
                     absentia_flag = absentia_flag.split(',');
                  }


                  // Buffer Utilization
                  
                  if(buffer_used != 0 || buffer_used_out != 0){
                    console.log('Buffer used ========='+buffer_used);
                    console.log('buffer_used_out ========='+buffer_used_out);
                     var buffer_array = [];
                     var buffer_connect = [false];
                     var buffer_tooltip = [];
                     var buffer_in = parseInt(buffer_used);
                     var buffer_out = parseInt(buffer_used_out);
                     console.log("buffer_out"+buffer_out);
                     var buffer_tooltip_diplay = [];
                     if(buffer_in != 0){
                        console.log('at buffer in');
                        buffer_tooltip_diplay.push(buffer_used);
                        buffer_array.push(weekly_time_sheet_in);
                        buffer_in = parseInt(weekly_time_sheet_in)+parseInt(buffer_used);
                        buffer_array.push(buffer_in);
                        buffer_connect.push(true,false);
                        buffer_tooltip.push(false,true);
                        
                     }

                     if(buffer_out != 0){
                        console.log('at buffer out');
                        buffer_tooltip_diplay.push(buffer_used_out);
                        buffer_array.push(weekly_time_sheet_out);
                        buffer_out = parseInt(weekly_time_sheet_out)+parseInt(buffer_out);
                        buffer_array.push(buffer_out);
                        buffer_connect.push(true,false);
                        buffer_tooltip.push(false,true);
                        
                     }
                     
                     
                     bufferInOut(buffer_array,buffer_connect,buffer_tooltip,buffer_tooltip_diplay);
                     
                  }else{
                     buffer_used = 0;
                     buffer_used_out = 0;
                     bufferInOut([0,0],false,false,false);
                  }


                   // PayRoll Attendace


                  if(time.length > 0 ){

                     var connectPayRoll = [false];
                     var classPayRoll = [];
                     var payRollAttendance = data[0].payroll_time_slot;
                     payRollAttendance = payRollAttendance.split(',')
                     var  payRollAttendanceArray = timeToMinuteForArray(payRollAttendance);
                     console.log("payRollAttendanceArrayBefore"+payRollAttendanceArray);

                     var payRollFlag = data[0].payroll_time_code;
                     payRollFlag = payRollFlag.split(',');

                     // Arranging PayRoll Flag if Actual Time is Greater Then Expected Time
                    // var buffer_flag = 0;
                     for(var i = 0 ; i< payRollFlag.length ; i++){
                        if(payRollFlag[i] == 'Ei' &&  payRollAttendanceArray[i+1] < payRollAttendanceArray[i]){
                           payRollAttendanceArray[i+1] = payRollAttendanceArray[i];
                        }

                        if(payRollFlag[i] == 'Eo' && payRollAttendanceArray[i-1] > payRollAttendanceArray[i]){

                           for(j = payRollFlag.length ; j > 0 ; j--){
                              if(payRollAttendanceArray[j-1] > payRollAttendanceArray[j])
                              payRollAttendanceArray[j-1] = payRollAttendanceArray[j];
                           }
                           
                        }

                        if(payRollFlag[i] == 'Ei' && buffer_used != 0){
                           payRollAttendanceArray[i+1] = parseInt(payRollAttendanceArray[i+1])-parseInt(buffer_used);
                        }


                        if(payRollFlag[i] == 'Eo' && buffer_used_out != 0){
                           payRollAttendanceArray[i-1] = parseInt(payRollAttendanceArray[i-1])+parseInt(buffer_used_out);
                        }

                        if(payRollFlag[i]){
                           var addMinute = parseInt(payRollAttendanceArray[i]) + parseInt(1);
                           if(addMinute == payRollAttendanceArray[i+1]){
                              payRollFlag.splice(i,2);
                              payRollAttendanceArray.splice(i,2);
                           }
                        }


                        

                     }

                     console.log("payRollAttendanceArrayAfter"+payRollAttendanceArray);


                     if(payRollFlag.length > 0){

                        for(var i = 0 ; i < payRollFlag.length ; i++){

                           if(payRollFlag[i] == 'Ei'){
                              connectPayRoll.push(true);
                              classPayRoll.push('red-color');

                           }

                           if(payRollFlag[i] == '1' || payRollFlag[i] == '8'){
                              connectPayRoll.push(true);
                              classPayRoll.push('green-color');

                           }

                           if(payRollFlag[i] == '0' ||  payRollFlag[i] == '9'){
                              connectPayRoll.push(true);
                              classPayRoll.push('red-color');

                           }

                           if(payRollFlag[i] == 'Eo'){
                              connectPayRoll.push(false);
                              classPayRoll.push('grey-color');

                           }

                           if(payRollFlag[i] == 'Ao'){

                              connectPayRoll.push(true);
                              classPayRoll.push('red-color');

                           }

                           if(payRollFlag[i] == 'ARo'){

                              connectPayRoll.push(true);
                              classPayRoll.push('green-color');


                           }

                           if(payRollFlag[i] == 'ARi'){

                              if(payRollFlag[i+1] == 'Ai'){
                                 classPayRoll.push('red-color');
                              }else{
                                 classPayRoll.push('green-color');
                              }
                              connectPayRoll.push(true);
                           }

                           if(payRollFlag[i] == 'Ai'){


                              connectPayRoll.push(true);
                              classPayRoll.push('green-color');


                           }
                        }

                     }


                     console.log("connectPayRoll"+connectPayRoll);
                     console.log("classPayRoll"+classPayRoll);

                     PayRollAttendanceSlider(payRollAttendanceArray,connectPayRoll,classPayRoll);


                  

               }else{

                  PayRollAttendanceSlider([weekly_time_sheet_in,weekly_time_sheet_out],[false,true,false],['red-color']);

               }
                  
               //// ================ Weekly Tap in ==============//
               ////================================================//

                  if(weekly_time_sheet_in && weekly_time_sheet_out ){
                     var tap = [weekly_time_sheet_in,weekly_time_sheet_out];
                     var connect = [false,true,false];
                     weeklyTapInTapOut(tap,connect);
                  }else{
                     weeklyTapInTapOut([0,0],false);
                  }




               //// ================ Actual Tap In And Tapout ==============//
               ////==============================================================//




                  if(time_flag){
                  var miss_tap_index = time_flag.indexOf('9');
                  var connect1 = [false];
                  var classes = [];
                  var uihandle = [];
                  var noUitooltip =[];
                  for(var i = 0 ; i < time_flag.length;i++){
                     if(time_flag[i] == '8'){
                           connect1.push(true);
                           classes.push('green-color');
                           uihandle.push('red-bar');
                           noUitooltip.push('In');
                     }

                     if(time_flag[i] == '1'){
                           connect1.push(true);
                           classes.push('green-color');
                           uihandle.push('normal-bar');
                           noUitooltip.push('In');
                     }



                  if(time_flag[i] == '0'){         
                        connect1.push(true);
                        classes.push('grey-color');
                        uihandle.push('normal-bar');
                        noUitooltip.push('Out');              
                     }

                  if(time_flag[i] == '9'){
                           connect1.push(true);

                           var class_push_flag = 0;
                            
                           for(var j = i+1 ; j < time_flag.length;j++){
                              if(time_flag[j] == '1' || time_flag[j] == '8'){
                                 class_push_flag =1;
                              }
                           }
                           if(class_push_flag == 1){
                               classes.push('grey-color');
                           }else{
                               classes.push('green-color');
                           }

                          
                           uihandle.push('red-bar');
                           noUitooltip.push('Out');  
                     }

                  }

                  console.log('connnect1'+connect1);
                  connect1.splice(connect1.length-1);
                  connect1.push(false)

                  if(miss_tap_index !== -1){
                     console.log(miss_tap_index);
                     classes[miss_tap_index-1] = 'green-color';
                     console.log(classes);
                  }

                  console.log('noUitooltip'+noUitooltip);
                  actualTapInTapOut(timeMinute,connect1,classes,uihandle,noUitooltip)  

               }else{
                  actualTapInTapOut([0,0,0,0],false,'','','');
               }

               // ================= ABSENTIA ALLOCATED TIME =====================//
               //===============================================================//

               // if(absentia_allocated_in != 0 && absentia_allocated_out != 0){
               //    var absentia_allocated = [absentia_allocated_out,absentia_allocated_in];
               //    var connect_absentia = [false,true,true];
               //    absentiaAllocatedTap(absentia_allocated,connect_absentia);
               // }else{
               //    absentiaAllocatedTap([0,0],[false,false]);
               // }


                if(absentia_flag){

                     var connect_abasentia = [false];
                     //var classes_absentia = [];

                     for(var i = 0 ; i < absentia_flag.length ; i++){
                        if(absentia_flag[i] == '7'){
                             connect_abasentia.push(true);
                        }

                        if(absentia_flag[i] == '6'){
                           connect_abasentia.push(false);
                           
                        }
                     }

                     absentiaAllocatedTap(absentia_allocated,connect_abasentia);


                  }else{
                     absentiaAllocatedTap([0,0,0,0],false);
                  }


                                               // Daily Buffer And Monthly Buffer

               var daily_relax_in = data[0].daily_relax_in;
               var monthly_relax_in = data[0].monthly_relax_in;
               var buffer_minutes_in = data[0].buffer_minutes_in;
               var rem_buffer_in = data[0].rem_buffer_in;

               if(buffer_minutes_in == ''){
                  buffer_minutes_in = 0
               }

               $('.daily_buffer_used').text(buffer_minutes_in+"min / "+daily_relax_in+"min");
               $('.monthly_buffer_used').text(rem_buffer_in+"min / "+monthly_relax_in+"min");
               $('.daily_buffer_assign').text(daily_relax_in+"min");
               $('.monthly_buffer_assign').text(rem_buffer_in+"min");

                

               // Compilance_in

               if(compliance_in == 1){
                  $('.compliance_one_img').attr("src", "<?php echo url('/img/complaint.png'); ?>");
               }else if(compliance_in == 0){
                  $('.compliance_one_img').attr("src", "<?php echo url('/img/noncomplaint.png'); ?>");
               }

               // Compilance_out

               if(compliance_out == 1){
                  $('.compliance_two_img').attr("src", "<?php echo url('/img/complaint.png'); ?>");
               }else if(compliance_out == 0){
                  $('.compliance_two_img').attr("src", "<?php echo url('/img/noncomplaint.png'); ?>");
               }

              // Compilance_duration 

              if(compliance_duration == 1){
                  $('.compliance_duration_img').attr("src", "<?php echo url('/img/complaint.png'); ?>");
              }else if(compliance_duration == 0){
                  $('.compliance_duration_img').attr("src", "<?php echo url('/img/noncomplaint.png'); ?>");
              }

                            // Factor Mapping

              if(factor){
               $('.factor_remaining_deduction').text(factor);
              }else{
               $('.factor_remaining_deduction').text('0');
              }

              if(factor_deduction){
               $('.factor_deduction_from').text(factor_deduction);
              }else{
               $('.factor_deduction_from').text('0');
              }

              // Leave Mapping

              $('.previous_el_balance').text(previous_leave);
              $('.current_el_balance').text(current_leave);
         




               // console.log('At YesterDay Report');
               // $.ajax({
               //    type:"POST",
               //    cache:true,
               //    data:{ 
               //     "date":date,
               //     "staff_id":staffID,
               //     "_token":"{{csrf_token()}}" 
               //    },
               //    url:"{{ url('/masterLayout/getYesterdayReport')}}",
               //    success:function(e){
               //       var yesterday_day = JSON.parse(e);
               //       console.log('Yesterday Day'+yesterday_day);
               //       if(yesterday_day.length != 0){


               //          $('.daily_buffer_used').text('0mins/'+yesterday_day[0].daily_relax_in+'mins');
               //          $('.monthly_buffer_used').text('0mins/'+yesterday_day[0].monthly_relax_in+'mins');
                        
                     




               //          // Daily Factor Calculated
               //          var daily_factor = yesterday_day[0].daily_factor;
               //          var deduction = yesterday_day[0].deduction;


               //          if(daily_factor != 1){
               //             var factor_deducted = (1 + daily_factor);
               //             $('.factor_remaining_deduction').text(factor_deducted.toFixed(1));
               //             $('.factor_deduction_from').text(deduction);

               //          }else{
               //             $('.factor_remaining_deduction').text(daily_factor);
               //             $('.factor_deduction_from').text("0");
               //          }


               //          // Calculate Monthly Buffer and Daily Buffer
               //          var daily_relax_in = yesterday_day[0].daily_relax_in;
               //          var monthly_relax_in = yesterday_day[0].monthly_relax_in;
               //          if(data[0].remaining_buffer != 0){
               //             $('.daily_buffer_used').text(yesterday_day[0].utlilize_buffer+"mins / "+daily_relax_in+"mins");
               //          }else{
               //             $('.daily_buffer_used').text(daily_relax_in+"min / "+daily_relax_in+"mins");
               //          }

               //          if(data[0].remaining_buffer != 0){
               //             $('.monthly_buffer_used').text(yesterday_day[0].remaining_buffer+"mins / "+monthly_relax_in+"mins");
               //          }else{
               //            $('.monthly_buffer_used').text(monthly_relax_in+"mins / "+monthly_relax_in+"mins")
               //          }


               //          // Previous  And Current Leave Calculated

               //          var current_leave  =  yesterday_day[0].remaining_leave;
                       
               //          if(deduction != 1){
                           
               //             var previous_leave = yesterday_day[0].remaining_leave - (deduction);
                         
               //          } else{
               //               var previous_leave = yesterday_day[0].remaining_leave;
               //          }

               //             $('.current_el_balance').text(current_leave);
               //             $('.previous_el_balance').text(previous_leave.toFixed(1));      


               //       }
               //     }

               // });

            }

         }
      });
   
  
      // Asim Daily Report

   }
   

    // ================ Weekly Slider ========================//
   //=====================================================//

   var weeklyTapInTapOut = function(tap,connect1){
         
         var slider = document.getElementById('weeklySlider');
         slider.noUiSlider.updateOptions({
         start: tap,
         connect:connect1,
         range: {
           'min': 360,
           'max': 1000
         },
         tooltips: [true, true]

         });

            var connect = slider.querySelectorAll('.noUi-connect');
            var classes = ['green-color'];

            for ( var i = 0; i < connect.length; i++ ) {
                connect[i].classList.add(classes[i]);
            }


   }

   //====================== Actual TapIn And Actual TapOut ==============//
   //===============================================================//

   

      var actualTapInTapOut = function(time,connect1,classes,uihandle,tooltip){
           console.log('time_actual_tap'+time);
           console.log('connect1_actual_tap'+connect1)
           console.log('classes_actual_tap'+classes) 
           console.log('uihandle_actual_tap'+uihandle) 

          tapSlider.noUiSlider.destroy();
          var slider = document.getElementById('tapSlider');
          noUiSlider.create(slider,{
            start: time,
            connect: connect1,
            range: {
              'min': 360,
              'max': 1000
            },
            tooltips:true,
            pips: {
              mode: 'steps',
              //values: [0, 720, 1439],
              filter: function filter(value, type) {
              //  console.log(type, value, value % 60);
                return value % (60 * 2) === 0 ? 1 : value % 60 === 0 ? 2 : 0;
              },
              //density: 2,
              format: {
                to: function to(value) {
                  if (value % (60 * 2) === 0) {
                    return moment().startOf('day').add(value, 'minutes').format('HH:mm');
                  }
                  return '';
                },
                from: function from(value) {
                  return value;
                }
              }
            },
            format: {
              to: function to(value) {
                //return value + ',-';
                return moment().startOf('day').add(value, 'minutes').format('HH:mm');
              },
              from: function from(value) {
                return value;
              }
            }

          });
   
            var connect = slider.querySelectorAll('.noUi-connect');
            var anchorhandle = slider.querySelectorAll('.noUi-handle');
            var tool = slider.querySelectorAll('.noUi-tooltip');


         for ( var i = 0; i < connect.length; i++ ) {
             connect[i].classList.add(classes[i]);
         }

         for ( var i = 0; i < anchorhandle.length; i++ ) {
             anchorhandle[i].classList.add(uihandle[i]);
         }

         for ( var i = 0; i < tool.length; i++ ) {
             tool[i].classList.add(tooltip[i]);
         }
      }




            //=============== Absentia Allocated =======================//
      //=======================================================//

      var absentiaAllocatedTap = function(tap,connect){

         AiAabsentia.noUiSlider.destroy();
         var  aiAabsentia = document.getElementById('AiAabsentia');

         noUiSlider.create(AiAabsentia, {
         start: tap,
         connect:connect,
         tooltips:true,
         range: {
           'min': 360,
           'max': 1000
         },
         format: {
               to: function to(value) {
                //return value + ',-';
                return moment().startOf('day').add(value, 'minutes').format('HH:mm');
               },
               from: function from(value) {
                return value;
               }
         }
         });

      }


      //====================== Buffer In Buffer Out ======================//
      //=================================================================//
      

      var bufferInOut = function(tap,connect1,tooltip1,bufferUsed){
         console.log('buffer Tap'+tap);
         console.log('buffer connect1'+connect1);
         console.log('buffer tooltip1'+tooltip1);
         bufferTime.noUiSlider.destroy();
         var buffer = document.getElementById('bufferTime');
            noUiSlider.create(buffer, {
            start: tap,
            tooltips: tooltip1,
            connect:connect1,
            range: {
              'min': 360,
              'max': 1000,
            },
            format: {
               to: function to(value) {
                //return value + ',-';
                return moment().startOf('day').add(value, 'minutes').format('HH:mm');
               },
               from: function from(value) {
                return value;
               }
            }
         });

         var connect = bufferTime.querySelectorAll('.noUi-handle');
         for ( var i = 0; i < connect.length; i++ ) {
             connect[i].classList.add('no-anchor');
         }

                  // Minutes Show In ToolTips
         var tool = bufferTime.querySelectorAll('.noUi-tooltip');
         for(var i = 0 ; i < tool.length;i++){
            tool[i].innerHTML = bufferUsed[i]+' min';
         }


      }

      //================= PayRoll Attendance ========================//
      //=============================================================//

      function PayRollAttendanceSlider(payRollAttendanceArray,connectPayRoll,classPayRoll){
            console.log("payRollAttendanceArray"+payRollAttendanceArray);
            console.log("connectPayRoll"+connectPayRoll);
            console.log("classPayRoll"+classPayRoll);
            console.log(typeof payrollSlider);
             if(typeof payrollSlider != undefined){
               console.log('at undefined');
                  payrollSlider.noUiSlider.destroy();
             }
            
            var PayrollSliderCreate1 = document.getElementById('PayrollAttendance');
            noUiSlider.create(PayrollSliderCreate1, {
            start: payRollAttendanceArray,
            tooltips: true,
            connect:connectPayRoll,
            range: {
              'min': 360,
              'max': 1000,
            },
            format: {
               to: function to(value) {
                //return value + ',-';
                return moment().startOf('day').add(value, 'minutes').format('HH:mm');
               },
               from: function from(value) {
                return value;
               }
            }
         });

         var connect = PayrollSliderCreate1.querySelectorAll('.noUi-connect');

         for ( var i = 0; i < connect.length; i++ ) {
             connect[i].classList.add(classPayRoll[i]);
         }
      }

   




   var timeToMinute = function(hms){
      var a = hms.split(':'); // split it at the colons

      var minutes = (+a[0]) * 60 + (+a[1]);

      var convert = minutes;

      return convert;
   }


   function timeToMinuteForArray(time){


      //var hms = time;   // your input string
      var min = [];
      console.log(time);
      console.log(time.length);
      for(var i =0 ; i < time.length;i++){
      var a = time[i].split(':'); // split it at the colons

      // Hours are worth 60 minutes.
      var minutes = (+a[0]) * 60 + (+a[1]);

      min.push(minutes);

      }

      console.log(min);

      return min;

   }

   var clearManual = function(){
      $('#manual_attendance').val('');
      $('#manual_missTap').val('');
      $('#manual_description').val('');
   }


   var clearAdjustment = function(){

      $('#adjustment_title').val('');
      $('#adjustment_no').val('');
      $('#adjustment_description').val('');
   }

   
   var pagedestroy = function(){
   }
   
   var show_dropdown = function(){
   "use strict";
   var dropdown = document.getElementsByClassName('dropdown-menuu');
   
   if(dropdown[0].style.display == 'none'){
       dropdown[0].style.display = '';
   }else{
      dropdown[0].style.display = 'none';
   }
   
   }
   
   var insertComment = function(){
   "use strict";
   var commentText = document.getElementById('commentText');
   var checkBox = document.getElementsByClassName('CheckBox_Category');
   var staff_id = $("a[href='#tab_1_1']").attr('data-staff');
   var flag = 0;
   var data;
   var url;
   url = "{{url('/masterLayout/staff/addComments')}}";
   var selectedCategory = [];
   var  selectedCategoryName = [];
   for(var i = 0; i<checkBox.length; i++){
       if(checkBox[i].checked && commentText.value != ''){
           flag =  1;
   
           selectedCategory.push(checkBox[i].value);
           selectedCategoryName.push(checkBox[i].getAttribute('data-name'));
          
   
       }
   }
   
   
   
   
   if(flag == 1){
                   /***** Further Requests of AJAX *****/
           var me = $(this);
           if (me.data('staffView_staffInfo_requestComment')){
               return;
           }
           me.data('staffView_staffInfo_requestComment', true);
           /***** Stop Further Request of AJAX *****/
   
           var date = new Date();
           var hour = date.getHours();
           var min = date.getMinutes();
           var time=hour+":"+min;
   
           $.ajax({
               type:"POST",
               cache:false,
               data:{
                   'comment' : commentText.value,
                   'category_id':selectedCategory,
                   'staff_id':staff_id,
                   'time':time,
                   "_token": "{{ csrf_token() }}"
               },
               url:url,
               success:function(e){
                   if(e != 0){
                       var html;
                       var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "June",
                                         "July", "Aug", "Sep", "Oct", "Nov", "Dec"];
   
                       var day_show = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
   
                       var date = new Date();
                       var curdate = date.getDate();
                       var month = monthNames[date.getMonth()];
                       var day_name = day_show[date.getDay()];
                       var year = date.getFullYear();
                       var hour = date.getHours();
                       var min = date.getMinutes();
   
                       var getTime = GetTime(date);
   
   
                       html = '<li class="out commentsLI"><img class="avatar" alt="" src="{{ STAFF_PIC_150 . $user['info'][0]->photo_id . STAFF_PIC150_TYPE}}" /><div class="message"><span class="arrow"> </span><a href="javascript:;" class="name"><strong></strong> <strong>{{$user["info"][0]->abridged_name}}</strong> </a><span class="datetime"> at <strong>'+getTime+'</strong> on <strong>'+day_name+","+month+" "+curdate+" "+year+'</strong> </span><span class="body">'+commentText.value+' </span><span class="commentCat"></span><span class="commentCat">'+selectedCategoryName.join()+'</span><input type="hidden" class="dateSearch" value='+year+"-"+parseInt(date.getMonth()+1)+"-"+curdate+' /></div></li>';
                       $('.chats').prepend(html);
   
                       clearComments();
                   }
               },
               complete: function() {
                   me.data('staffView_staffInfo_requestComment', false);
               }
           });
   }
   
   if(flag == 0){
       var html;
       html = '';
       html += "<div class='alert alert-warning alert-dismissable' id='Error_Commenting'><strong id='Error_Commenting_1'>Warning!  Please fill comments box <br>Warning!  Please select at least one category <br></strong></div>";
   
      $('.chats').prepend(html);
       $('#Error_Commenting').fadeOut(5000);
   
   }
   
   }
   
   
   // var search_filter = function search_filter (){
   
   
   //         var select =  $('#Sort_By_Source option:selected').val();
   // }
   
   $('.applySearch').click(function(){
      var select_user =  $('#filter_user option:selected').val();
      var from_date = $('#from_date').val();
      var to_date = $('#to_date').val();
   
      if(select_user == 'user'){
       $('ul .in').css('display','none');
       $('ul .out').css('display','');
   
      }else if(select_user == 'system'){
           $('ul  .out').css('display','none');
           $('ul  .in').css('display','');
      }
   
      if(from_date != '' && to_date != ''){
           
           dateFilter(from_date,to_date)
      } 
   });
   
   
   var dateFilter = function(from_date,to_date){
   
   var dates = document.getElementsByClassName("dateSearch");
   
   from_date = new Date(from_date);
   to_date = new Date(to_date);
   
   
   for (var  i = 0; i < dates.length; i++) {
      var temp_date = dates[i].value.split('-');
      var date = new Date(parseInt(temp_date[0]),parseInt(temp_date[1]-1),parseInt(temp_date[2]));
      
       
      if( date >= from_date && date <= to_date ){
           
           var a = document.getElementsByClassName('commentsLI')[i];
           if(a.style.display == 'none'){
   
           }else{
               a.style.display = '';
           }
      } else {
           var a = document.getElementsByClassName('commentsLI')[i];
           a.style.display = 'none';
      
      }
   }
   
   }
   
   
   var formatDate = function formatDate(date) {
   
      var date = new Date(date);
      var month = '';
      var days_alpha = ["Sun","Mon","Tues","Wed","Thu","Fri","Sat"];
      var numberDay = date.getDate();
      var day = date.getDay();
      day = days_alpha[day];
      var monthNames = [ "Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec" ];
      month = date.getMonth();
      month = monthNames[month];
      var year = date.getFullYear();
      
      return day +" "+ month  + " "+numberDay +',' + year;
   }

   var AddZeroDate = function(date){
      date = date.toString();
      if(date.length == 1){
         date = '0'+date;
      }
      return date;
   }
   
   var GetTime =  function GetTime(date) {
      var date = new Date(date);
      var hours = date.getHours() > 12 ? date.getHours() - 12 : date.getHours();
      var am_pm = date.getHours() >= 12 ? "PM" : "AM";
      hours = hours < 10 ? "0" + hours : hours;
      var minutes = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
      var seconds = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
      time = hours + ":" + minutes + ":" + seconds + " " + am_pm;
      return time;
   }
   
   
   var clearSearch = function(){
      $('#from_date').val('');
      $('#to_date').val('');
      $('#filter_user  option:eq(0)').prop('selected', true)
      $('.commentsLI').css('display','');
   }
   
   var clearComments = function(){
      $('#commentText').val('');
      $('.CheckBox_Category').attr('checked',false);
   }
   
   
   
   
   
   
loadScript("{{ URL::to('metronic') }}/global/scripts/datatable.js", function(){
   loadScript("{{ URL::to('metronic') }}/global/plugins/datatables/datatables.min.js", function(){
      loadScript("{{ URL::to('metronic') }}/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js", function(){
         loadScript("{{ URL::to('metronic') }}/pages/scripts/profile.js", function(){
               loadScript("{{ URL::to('metronic') }}/pages/scripts/table-datatables-managed.js", function(){
                   loadScript("{{ URL::to('metronic') }}/global/plugins/jquery.sparkline.min.js", function(){
                       loadScript("{{ URL::to('metronic') }}/global/plugins/jqvmap/jqvmap/jquery.vmap.js", function(){
                           loadScript("{{ URL::to('metronic') }}/global/plugins/moment.js", function(){
                               loadScript("{{ URL::to('metronic') }}/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js", function(){
                                   loadScript("{{ URL::to('metronic') }}/global/plugins/bootstrap-datepaginator/bootstrap-datepaginator.min.js", function(){
                                      // loadScript("{{ URL::to('metronic') }}/pages/scripts/ui-datepaginator.min.js", function(){
                                           loadScript("{{ URL::to('metronic') }}/layouts/layout/scripts/demo.min.js", function(){ 
                                               loadScript("{{ URL::to('metronic') }}/global/plugins/ion.rangeslider/js/ion.rangeSlider.min.js", function(){
                                                   loadScript("{{ URL::to('metronic') }}/global/plugins/bootstrap-markdown/lib/markdown.js", function(){
                                                       loadScript("{{ URL::to('metronic') }}/global/plugins/bootstrap-markdown/js/bootstrap-markdown.js", function(){
                                                           loadScript("{{ URL::to('metronic') }}/global/plugins/bootstrap-summernote/summernote.min.js", function(){
                                                               loadScript("{{ URL::to('metronic') }}/pages/scripts/components-ion-sliders.js", function(){
                                                    loadScript("{{ URL::to('metronic') }}/global/plugins/time-range/js/vue.min.js", function(){
                                                loadScript("{{ URL::to('metronic') }}/global/plugins/select2/js/select2.full.min.js", function(){
                                                loadScript("{{ URL::to('metronic') }}/pages/scripts/components-select2.min.js", function(){
                                                        loadScript("{{ URL::to('metronic') }}/global/plugins/time-range/js/flatpickr.min.js", function(){

                                                            loadScript("{{ URL::to('metronic') }}/global/plugins/time-range/js/nouislider.min.js", function(){
                                                               loadScript("{{ URL::to('metronic') }}/global/plugins/time-range/js/moment.min.js", function(){
                                                                   //loadScript("{{ URL::to('metronic') }}/global/plugins/time-range/js/index.js", function(){

                                                                    loadScript("{{URL::to('metronic')}}/global/plugins/jquery-validation/js/jquery.validate.js",function(){
                                                                                    loadScript("{{ URL::to('') }}/js/jquery.filtertable.min.js", function(){
                                                                                        loadScript("{{ URL::to('metronic') }}/global/scripts/app.min.js", pagefunction);
                                                                                    });
                                                                        });
                                                                                });
                                                                            //});
                                                            });
                                                                    });
                                                        });});
                                                    });
                                                });
                                            });
                                                       });
                                                   });
                                               });
                                           });
                                       //});
                                   });
                               });
                           });
                       });
                   });
               });
           });
       });
   });
   });



</script>
<!--<script src="assets/global/plugins/ion.rangeslider/js/ion.rangeSlider.min.js" type="text/javascript"></script>
   <script src="assets/global/plugins/bootstrap-markdown/lib/markdown.js" type="text/javascript"></script>
   <script src="./assets/global/plugins/bootstrap-markdown/js/bootstrap-markdown.js" type="text/javascript"></script>
   <script src="assets/global/plugins/bootstrap-summernote/summernote.min.js" type="text/javascript"></script>
   -->
<!-- END PAGE LEVEL PLUGINS