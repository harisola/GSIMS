<?php /***** ***** ***** Observation - JS ***** ***** *****/ ?>
<script type="text/javascript">

</script>